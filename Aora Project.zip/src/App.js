import './App.css';
// import Login from './Component/Useradmin/Login';
import Loginwechat from './Component/Useradmin/Loginwechat';
import Signupwechat from './Component/Useradmin/Signupwechat'
import {BrowserRouter as Router,Switch,Route} from "react-router-dom";
import HomePage from './Component/Useradmin/Dashboard/Home';
import Signup from './Component/Useradmin/Signup';
import PrivateRoute from './api/Components/PrivateRoute';
import Pricingcard from './Component/Pricingcard';
import Formdetails from './Component/Useradmin/Dashboard/Brandprofile/Formdetails';
import Datapassa from './Component/Useradmin/Dashboard/Brandprofile/Datapassa';
import Cardformdata from './Component/Useradmin/Dashboard/Brandprofile/Cardformdata';
import GenerateContach from './Component/Useradmin/Dashboard/GenerateContach/GenerateContach';
import Formchat from './Component/Formchat';
import Marketplace from './Component/Useradmin/Dashboard/Marketplace/Marketplace';
import Aboutservices from './Component/Useradmin/Dashboard/Marketplace/MarketPlaceServiceDetails';
import Setting from './Component/Useradmin/Dashboard/Setting/Setting';
import CreateFashion from './Component/Useradmin/Dashboard/CreateFashion/CreateFashion';
import Industry from './Component/Useradmin/Dashboard/Industry/Industry';
import Brandprofile from './Component/Useradmin/Dashboard/Brandprofile/Brandprofile';
import BrandUserform from './Component/Useradmin/Dashboard/Brandprofile/BrandUserform';
import Login from './Component/Useradmin/Login';






  

function App() {


  return (
      <div className="App">
        <Router>
          <Switch>
         

          <Route exact path="/" component={Login} />
                    <Route exact path="/loginwechat" component={Loginwechat} />
                    <Route exact path="/signup" component={Signup} />
                    <Route exact path="/Signupwechat" component={Signupwechat} />
                    <Route exact path="/industry"  >
                     <Industry />
                    </Route>
                    <Route exact path="/brandprofile"  >
                   <Brandprofile /> 
                    </Route>
                    <Route exact path="/pricingcard"  >
                      <Pricingcard />
                    </Route>
                  

                    <PrivateRoute exact path="/dashboard" component={HomePage}  />
                    <Route exact path="/BrandUserform"  >
                  <BrandUserform />
                    </Route>
                    <Route exact path="/formdatails"  >
                   <Formdetails />
                    </Route>
                    <Route exact path="/datapassa"  >
                   <Datapassa />
                    </Route>
                    <Route exact path="/cardformdata"  >
                  <Cardformdata />
                    </Route>
                    <Route exact path="/generateContach"  >
                 <GenerateContach />
                    </Route>
                    <Route exact path="/formchat"  >
                 <Formchat />
                    </Route>
                    <Route exact path="/setting"  >
               <Setting />
                    </Route>
                    <Route exact path="/marketplace"  >
             <Marketplace />
                    </Route>
                    <Route exact path="/CreateFashion"  >
            <CreateFashion />
                    </Route>

                    
                   
           
          </Switch>
        </Router>

      </div>
  );
}

export default App;
