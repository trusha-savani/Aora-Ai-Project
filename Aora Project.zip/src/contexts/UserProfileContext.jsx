// src/contexts/UserProfileContext.js

import React, { createContext, useContext, useState, useEffect } from 'react';
import {getUserData} from '../../src/api/apiRequests';
 
// Create a Context for the user profile
const UserProfileContext = createContext();

// Create a provider component
export const UserProfileProvider = ({ children }) => {
    const [profileData, setProfileData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchUserProfile = async () => {
            try {
                const data = await getUserData();
                setProfileData(data);
            } catch (error) {
                setError('Failed to load user profile');
                console.error('Error fetching user profile:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchUserProfile();
    }, []);

    return (
        <UserProfileContext.Provider value={{ profileData, loading, error }}>
            {children}
        </UserProfileContext.Provider>
    );
};

// Custom hook to use the UserProfileContext
export const useUserProfile = () => {
    return useContext(UserProfileContext);
};
