// import React, { useState } from 'react';
// import { Box, TextField, Button, Typography } from '@mui/material';

// const WhatsAppChat = () => {
//   // Initial messages with both user and friend
//   const [messages, setMessages] = useState([
//     { text: 'Hello!', senderId: '1', time: '10:00 AM' },
//     { text: 'Hi! How are you?', senderId: '2', time: '10:01 AM' },
//     { text: 'I am working on a project.', senderId: '1', time: '10:02 AM' },
//     { text: 'That sounds interesting!', senderId: '2', time: '10:03 AM' },
//     { text: 'Need any help?', senderId: '1', time: '10:04 AM' },
//   ]);

//   const [newMessage, setNewMessage] = useState('');
//   const [senderId, setSenderId] = useState('1'); // Default sender ID

//   // Function to handle sending a message
//   const handleSendMessage = () => {
//     if (newMessage.trim()) {
//       setMessages([...messages, { text: newMessage, senderId: senderId, time: new Date().toLocaleTimeString() }]);
//       setNewMessage(''); // Clear the input field after sending the message
//     }
//   };

//   return (
//     <Box sx={{ width: '300px', margin: '0 auto', padding: '20px', backgroundColor: '#f0f0f0', borderRadius: '10px' }}>
//       <Box sx={{ height: '400px', overflowY: 'auto', marginBottom: '10px' }}>
//         {messages.map((message, index) => (
//           <Box
//             key={index}
//             sx={{
//               marginBottom: '10px',
//               display: 'flex',
//               justifyContent: message.senderId === '1' ? 'flex-end' : 'flex-start', // Align based on senderId
//             }}
//           >
//             <Box
//               sx={{
//                 backgroundColor: message.senderId === '1' ? '#dcf8c6' : '#ffffff',
//                 borderRadius: '5px',
//                 padding: '10px',
//                 maxWidth: '70%',
//               }}
//             >
//               <Typography variant="body2" sx={{ color: '#555' }}>
//                 {message.senderId === '1' ? 'You' : 'Friend'}{' '}
//                 <span style={{ fontSize: '10px', color: '#aaa' }}>{message.time}</span>
//               </Typography>
//               <Typography>{message.text}</Typography>
//             </Box>
//           </Box>
//         ))}
//       </Box>
//       <Box sx={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
//         <TextField
//           variant="outlined"
//           fullWidth
//           value={newMessage}
//           onChange={(e) => setNewMessage(e.target.value)}
//           placeholder="Type a message"
//           sx={{ marginRight: '10px' }}
//         />
//         <Button variant="contained" onClick={handleSendMessage} sx={{ backgroundColor: '#25D366' }}>
//           Send
//         </Button>
//       </Box>
//       <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
//         <Button
//           variant="outlined"
//           onClick={() => setSenderId('1')}
//           sx={{
//             backgroundColor: senderId === '1' ? '#25D366' : '#f0f0f0',
//             color: senderId === '1' ? '#fff' : '#000',
//           }}
//         >
//           You
//         </Button>
//         <Button
//           variant="outlined"
//           onClick={() => setSenderId('2')}
//           sx={{
//             backgroundColor: senderId === '2' ? '#25D366' : '#f0f0f0',
//             color: senderId === '2' ? '#fff' : '#000',
//           }}
//         >
//           Friend
//         </Button>
//       </Box>
//     </Box>
//   );
// };

// export default WhatsAppChat;
import React, { useState } from 'react';
import { Box, TextField, Button, Typography } from '@mui/material';

const WhatsAppChat = () => {
  const [messages, setMessages] = useState([
    { text: 'Hello!', senderId: '1', time: '10:00 AM' },
    { text: 'Hi! How are you?', senderId: '2', time: '10:01 AM' },
    { text: 'I am working on a project.', senderId: '1', time: '10:02 AM' },
    { text: 'That sounds interesting!', senderId: '2', time: '10:03 AM' },
    { text: 'Need any help?', senderId: '1', time: '10:04 AM' },
  ]);

  const [newMessage, setNewMessage] = useState('');

  // Function to handle sending a message
  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // You (senderId: '1') always sends the message
      setMessages([...messages, { text: newMessage, senderId: '1', time: new Date().toLocaleTimeString() }]);
      setNewMessage(''); // Clear the input field after sending the message
    }
  };

  return (
    <Box sx={{ width: '300px', margin: '0 auto', padding: '20px', backgroundColor: '#f0f0f0', borderRadius: '10px' }}>
      <Box sx={{ height: '400px', overflowY: 'auto', marginBottom: '10px' }}>
        {messages.map((message, index) => (
          <Box
            key={index}
            sx={{
              marginBottom: '10px',
              display: 'flex',
              justifyContent: message.senderId === '1' ? 'flex-end' : 'flex-start', // Align based on senderId
            }}
          >
            <Box
              sx={{
                backgroundColor: message.senderId === '1' ? '#dcf8c6' : '#ffffff',
                borderRadius: '5px',
                padding: '10px',
                maxWidth: '70%',
              }}
            >
              <Typography variant="body2" sx={{ color: '#555' }}>
                {message.senderId === '1' ? 'You' : 'Friend'}{' '}
                <span style={{ fontSize: '10px', color: '#aaa' }}>{message.time}</span>
              </Typography>
              <Typography>{message.text}</Typography>
            </Box>
          </Box>
        ))}
      </Box>
      <Box sx={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
        <TextField
          variant="outlined"
          fullWidth
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message"
          sx={{ marginRight: '10px' }}
        />
        <Button variant="contained" onClick={handleSendMessage} sx={{ backgroundColor: '#25D366' }}>
          Send
        </Button>
      </Box>
    </Box>
  );
};

export default WhatsAppChat;




