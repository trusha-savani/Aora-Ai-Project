import React from 'react'
import Grid from '@mui/material/Grid';
import {  Typography } from '@mui/material';
import Rating from '@mui/material/Rating';
import Avatar from '@mui/material/Avatar';
import AvatarGroup from '@mui/material/AvatarGroup';
import QRCode from "react-qr-code";
import {  Box } from '@mui/material';

function Signuppage() {
  const qrValue = "https://your-url-or-value-here";
  return (
        <div >
          <Box sx={{ flexGrow: 1 }}>
                    <Grid container sx={{ backgroundColor: 'black' }}>
                        <Grid item xs={12}  xl={5} lg={5} md={12} sm={12}   sx={{ backgroundColor: 'black', height: '100vh' }}>
                            <Box sx={{ padding: '60px',height:'100%',width:'100%',overflowY:'scroll' }}>
                                <Box>
                                    <img src="/assets/image/loginlogo1.png" alt="" />
                                </Box>

                                <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', color: '#ffffff', mt: 11 }}>
                                    <Typography sx={{ fontWeight: '500', fontSize: '28px', lineHeight: '44px', alignItems: 'center' }} >Sign up with WeChat</Typography>

                                 </Box>
             <div style={{ height: "300px", margin: "0 auto", maxWidth: 256, width: "100%", marginTop: '80px' }}>
                <QRCode
                  size={256}
                  style={{ height: "auto", maxWidth: "100%", width: "100%" }}
                  value={qrValue}
                  viewBox={`0 0 256 256`}
              />
              </div>
              <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', mt: 4 }}>
                <Typography sx={{ fontWeight: '500', fontSize: '16px', lineHeight: '28px', alignItems: 'center',letter:'0.15px',color:'#9B9C9E' }} >Scan the QR code to Sign up with WeChat</Typography>

              </Box>
              </Box>

                        </Grid>
                        <Grid item xs={8} xl={7} lg={7} md={12}  sm={12}  className='Loginpage_mobile_view'>
                            <Box>
                                <Box sx={{ position: 'relative' }}>
                                    <img src="/assets/image/signupimage.png" style={{ height: '100vh', width: '100%' }} alt="" />
                                    <Box sx={{ position: 'absolute', bottom: '-0px', padding: '90px', color: '#FFFFFF' }}>
                                        <img src="/assets/image/loginstar.png" alt="...." />
                                        <Box sx={{ mt: 5 }}>

                                            <Typography sx={{ fontSize: '45px', lineHeight: '56.7px', fontWeight: '600' }}>Start turning your</Typography>
                                            <Typography sx={{ fontSize: '45px', lineHeight: '56.7px', fontWeight: '600' }}>    ideas into reality.</Typography>
                                        </Box>

                                        <Box sx={{ mt: 2 }}>
                                            <Typography sx={{ fontSize: '16px', lineHeight: '28px', fontWeight: '500', letter: '0.15px' }}> Create a free account and get full access to all features for 14-days.</Typography>
                                            <Typography sx={{ fontSize: '16px', lineHeight: '28px', fontWeight: '500', letter: '0.15px' }}> No credit card needed. Trusted by over 2,000 professionals.</Typography>
                                        </Box>
                                        <Box sx={{ display: 'flex', mt: 3 }}>
                                            <Box sx={{ display: 'flex', justifyContent: 'start' }}>
                                                <AvatarGroup max={3}>
                                                    <Avatar alt="Remy Sharp" src="/assets/image/avtar1.png" />
                                                    <Avatar alt="Travis Howard" src="/assets/image/avtar2.png" />
                                                    <Avatar alt="Cindy Baker" src="/assets/image/avtar3.png" />

                                                </AvatarGroup>

                                            </Box>
                                            <Box sx={{ display: 'flex', flexDirection: 'column', ml: 2 }}>
                                                <Box>

                                                    <Typography sx={{ fontSize: '14px', fontWeight: '700', lineHeight: '16.94px', textAlign: 'start' }}>Our Happy Users</Typography>
                                                </Box>
                                                <Box sx={{ display: 'flex', mt: 1 }}>
                                                    <Rating name="half-rating" defaultValue={4.5} precision={0.5} sx={{ fontSize: '16px' }} />
                                                    <Typography sx={{ fontSize: '14px', lineHeight: '16.94px', fontWeight: '700' }}>4.5</Typography>
                                                    <Typography sx={{ fontSize: '14px', lineHeight: '14.52px', fontWeight: '400', color: '#FAFAFA' }}>(200+ reviews)</Typography>
                                                </Box>
                                            </Box>

                                        </Box>
                                    </Box>
                                </Box>
                            </Box>
                        </Grid>
                    </Grid>
                </Box>

            
        </div>
    )
}

export default Signuppage
