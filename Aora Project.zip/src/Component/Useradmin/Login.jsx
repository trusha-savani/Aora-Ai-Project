import React, { useEffect } from 'react'
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import { TextField, Typography, InputAdornment, Checkbox, FormControlLabel } from '@mui/material';
import Rating from '@mui/material/Rating';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import Avatar from '@mui/material/Avatar';
import AvatarGroup from '@mui/material/AvatarGroup';
import { useHistory} from 'react-router-dom';
import { useState } from 'react';
import IconButton from '@mui/material/IconButton';
import { userlogin } from '../../api/apiRequests';
import CreateButton from '../../api/Components/CreateButton';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import FrogatePassword from '../../dialogs/FrogatePassword';
import VerifyCode from '../../dialogs/VerifyCode';
import NewPassword from '../../dialogs/NewPassword'

function Login() {
    const [open, setOpen] = useState(false);
    let [verify, setverify] = useState(false);
    let [password, setpassword] = useState(false);
    const [email, setEmail] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [emailError, setEmailError] = useState(false);
    const [passwordError, setPasswordError] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const handleClickShowPassword = () => setShowPassword(!showPassword);
    const handleMouseDownPassword = (event) => event.preventDefault();

    const validateEmail = (emailValue) => {
       return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue);
    };
    const handleEmailChange = (e) => {
        setEmail(e.target.value);
        setEmailError(false); 
    };
    const handlePasswordChange = (event) => {
        setNewPassword(event.target.value);
    };
    const history = useHistory();
    const handleSignIn = async () => {
        const isValidEmail = validateEmail(email);
        const isPasswordNotEmpty = newPassword !== '';

        if (!isValidEmail) {
            setEmailError(true);
        }
        if (!isPasswordNotEmpty) {
            setPasswordError(true);
        }
        if (isValidEmail && isPasswordNotEmpty) {
            setIsSubmitting(true);
            const data = {
                loginField: email,
                password: newPassword,
        };
            localStorage.setItem('signupData', JSON.stringify(data));
            console.log(data);
            setTimeout(() => {
                const token = "sampleToken";
                localStorage.setItem('authToken', token);
                console.log("Login successful!");
                history.push('/dashboard');
                setIsSubmitting(false);
            }, 1000);
        }
    };
    const isAuthenticated = !!localStorage.getItem('authToken');
    // useEffect(() => {
    //     // if (isAuthenticated) {
    //         history.push('/dashboard'); 
    //     // }
    // }, [isAuthenticated, history]);
  
    const handleSignUpNavigation = () => {
        history.push('/signup')
    };
    let handlewechatenavigation = () => {
        history.push('/loginwechat')
    }
    const handlephoneclickopen = () => {
        setOpen(true);
    };

    const handleCloseDialog = () => {
        setOpen(false);
        console.log(open);
    };
    let handlevarifyopen = () => {
        setverify(true)
    };
    let handlevarifyclose = () => {
        setverify(false)
    }
    let handlepasswordopen = () => {
        setpassword(true)
    };
    let handlepasswordclose = () => {
        setpassword(false)
    }
    return (
       <Box>
           <Box sx={{ height: '100vh' }}>
                <Grid container sx={{ height: '100%' }}>
                    <Grid item xs={12} xl={5} lg={5} md={12} sm={12} className='Loginpage_mobile_left' sx={{ backgroundColor: 'black', height: '100%'}}>
                        <Box sx={{ padding: { xl: '50px', lg: '50px', sm: '40px', xs: '40px' }, height: '100%', width: '100%',overflow: 'scroll', scrollbarWidth:'none' }}>
                            <Box><img src="/assets/image/loginlogo1.png" alt="" />
                            </Box>
                            <Box >
                                <Typography className='login-first' sx={{fontSize: '36px', fontWeight: '500', lineHeight: '44px', color: '#ffffff', marginTop: '130px'}}>
                                    Welcome back
                                </Typography>
                               <Typography variant='subtitle1' sx={{ lineHeight: '28px', letterSpacing: '0.15px', color: '#9B9C9E', mt: 3, fontSize: '16px' }}>
                                    Log in to Aora to start creating magic.
                                </Typography>
                           </Box>
                            <Box >
                                <Typography variant='body2' sx={{mt: 7, color: '#686B6E'}} >
                                    Email / Phone number*
                                </Typography>
                                <TextField onChange={handleEmailChange} type='text' value={email} error={emailError} name='Enter your full name' helperText={emailError ? "Please enter a full name." : ""}
                                    placeholder='Enter your email or phone number' fullWidth  sx={{ 
                                        mt: 1, 
                                        borderRadius: '30px', 
                                        '& label': { color: 'red',borderRadius:'20px', backgroundColor:'transparent'}, 
                                        '& .MuiOutlinedInput-root': {
                                            backgroundColor: 'transparent',  // Set background color to white
                                            '& fieldset': { 
                                                borderColor: '#363A3D', 
                                                // borderRadius: '10px' 
                                            }, 
                                            '&:hover fieldset': { 
                                                borderColor: '#363A3D' 
                                            },
                                           '&.Mui-focused': {
                backgroundColor:  email ? 'transparent' : 'transparent', 
                '& fieldset': { 
                    borderColor: '#A217A3', 
                 
                },
            },
                                        },
                                    }}
                                />
                            </Box>
                            <Box>
                              <TextField
                                    onChange={handlePasswordChange} type={showPassword ? 'text' : 'password'} value={newPassword} error={passwordError}
                                    name='Password' helperText={emailError ? "Please enter a full name." : ""} placeholder='Password' fullWidth
                                    sx={{ mt: 2, borderRadius: '10px', '& label': { color: '#ffffff' }, '& .MuiOutlinedInput-root': {
                                            '& fieldset': { borderColor: '#363A3D', borderRadius: '10px' },'&:hover fieldset': { borderColor: '#363A3D' },
                                            '&.Mui-focused fieldset': { borderColor: '#A217A3', borderRadius: '10px' },'& .MuiInputBase-input': { color: '#ffffff' },
                                        },
                                    }}
                                    InputProps={{
                                        startAdornment: (
                                            <InputAdornment position="start">
                                                <LockOutlinedIcon sx={{ color: '#ffffff' }} />
                                            </InputAdornment>
                                        ),
                                        endAdornment: (
                                            <InputAdornment position="end">
                                                <IconButton aria-label="toggle password visibility" onClick={handleClickShowPassword} 
                                                onMouseDown={handleMouseDownPassword} edge="end" sx={{ color: '#ffffff' }}>
                                                    {showPassword ? <VisibilityOff /> : <Visibility />}
                                                </IconButton>
                                            </InputAdornment>
                                        ),
                                    }}
                                />
                            </Box>
                           <Box sx={{ display: 'flex', justifyContent: 'space-between', marginTop: { xl: '10px', xs: '20px' } }}>
                                <Box sx={{}}>
                                    <FormControlLabel control={<Checkbox name="rememberMe" sx={{ color: 'grey' }} />}label="Remember me"
                                        sx={{ color: '#ffffff', fontSize: '16px', lineHeight: '24px', letterSpacing: '0.15px', fontWeight: '500' }}
                                    />
                                </Box>
                                <Box sx={{ mt: 1 }}>
                                    <Typography onClick={handlephoneclickopen} sx={{ color: '#A217A3', fontSize: '16px', lineHeight: '24px', letterSpacing: '0.15px', fontWeight: '600' }}>Forgot Password?</Typography>
                                </Box>
                            </Box>

                                <CreateButton text={isSubmitting ? "Submitting..." : "Log in"}
                                disabled={false} handleCLick={handleSignIn} loading={isSubmitting} />


                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', my: 3 }}>
                                <Divider sx={{ width: { xs: '120px', sm: '150px', md: '200px', lg: '200px', xl: '300px' }, borderColor: '#363A3D' }} />
                                <Typography variant="body2" sx={{ whiteSpace: 'nowrap', fontSize: '12px', fontWeight: '500', lineHeight: '18px', color: '#686B6E' }}>or continue with</Typography>
                                <Divider sx={{ width: { xs: '120px', sm: '150px', md: '200px', lg: '200px', xl: '300px' }, borderColor: '#363A3D' }} />
                            </Box>
                            <Box sx={{ display: 'flex' }}>

                                <Button
                                    variant="contained"
                                    sx={{
                                        width: '48%',
                                        px: { xl: 2, lg: 2, md: 1, sm: 0, xs: 1 },
                                        py: { xl: 1, lg: 1, md: 1, sm: 0, xs: 1 },
                                        fontSize: { xl: '16px', lg: '16px', md: 1, sm: 0, xs: '10px' },
                                        lineHeight: '24px',
                                        fontWeight: '600',
                                        color: '#686B6E',
                                        letterSpacing: '0.15px',
                                        textTransform: 'none !important',
                                        backgroundColor: '#1A1D21',
                                        '&:hover': {
                                            backgroundColor: '#1A1D21',
                                        },
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                    }}
                                >
                                    <img
                                        src="/assets/image/goglelogo1.png"
                                        alt="WeChat Logo"
                                        style={{ width: '24px', height: '24px', marginRight: '8px' }} 
                                    />
                                    Google Account
                                </Button>
                                <Button
                                    onClick={handlewechatenavigation}
                                    variant="contained"
                                    sx={{
                                        width: '48%',
                                        px: { xl: 2, lg: 2, md: 1, sm: 0, xs: 1 },
                                        py: { xl: 1, lg: 1, md: 1, sm: 0, xs: 1 },
                                        fontSize: { xl: '16px', lg: '16px', md: 1, sm: 0, xs: '10px' },
                                        lineHeight: '24px',
                                        fontWeight: '600',
                                        color: '#686B6E',
                                        letterSpacing: '0.15px',
                                        textTransform: 'none !important',
                                        backgroundColor: '#1A1D21',
                                        '&:hover': {
                                            backgroundColor: '#1A1D21',
                                        },
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        ml: 4
                                    }}
                                >
                                    <img
                                        src="/assets/image/wechatlogo.png" 
                                        alt="WeChat Logo"
                                        style={{ width: '24px', height: '24px', marginRight: '8px' }} 
                                    />
                                    WeChat
                                </Button>
                                </Box>
                            <Box sx={{ display: 'flex', mt: { xl: 14, lg: 14, md: 14, sm: 14, xs: 14 }, alignItems: 'center' }}>
                                <Typography sx={{ color: '#686B6E', fontWeight: '600', fontSize: '16px', lineHeight: '24px', cursor: 'pointer' }}>Don’t have an account? <span class="demo" onClick={handleSignUpNavigation}>sign up</span> </Typography>

                            </Box>
                        </Box>
                </Grid>
                    <Grid item xs={8} xl={7} lg={7} md={12} sm={12} className='Loginpage_mobile_view' >


                        <Box sx={{ height: '100vh', position: 'relative' }}>
                            <img src="/assets/image/login.png" content='fit' style={{ height: '100vh', width: '100%' }} alt="" />
                            <Box sx={{ position: 'absolute', bottom: '10px', padding: '90px', color: '#FFFFFF' }}>
                                <img src="/assets/image/loginstar.png" alt="...." />
                                <Box sx={{ mt: 5 }}>

                                    <Typography sx={{ fontSize: '45px', lineHeight: '56.7px', fontWeight: '600' }}>Start turning your</Typography>
                                    <Typography sx={{ fontSize: '45px', lineHeight: '56.7px', fontWeight: '600' }}>    ideas into reality.</Typography>
                                </Box>

                                <Box sx={{ mt: 2 }}>
                                    <Typography sx={{ fontSize: '16px', lineHeight: '28px', fontWeight: '500', letter: '0.15px' }}> Create a free account and get full access to all features for 14-days.</Typography>
                                    <Typography sx={{ fontSize: '16px', lineHeight: '28px', fontWeight: '500', letter: '0.15px' }}> No credit card needed. Trusted by over 2,000 professionals.</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', mt: 3 }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'start' }}>
                                        <AvatarGroup max={3}>
                                            <Avatar alt="Remy Sharp" src="/assets/image/avtar1.png" />
                                            <Avatar alt="Travis Howard" src="/assets/image/avtar2.png" />
                                            <Avatar alt="Cindy Baker" src="/assets/image/avtar3.png" />

                                        </AvatarGroup>

                                    </Box>
                                    <Box sx={{ display: 'flex', flexDirection: 'column', ml: 2 }}>
                                        <Box>

                                            <Typography sx={{ fontSize: '14px', fontWeight: '700', lineHeight: '16.94px', textAlign: 'start' }}>Our Happy Users</Typography>
                                        </Box>
                                        <Box sx={{ display: 'flex', mt: 1 }}>
                                            <Rating name="half-rating" defaultValue={4.5} precision={0.5} sx={{ fontSize: '16px' }} />
                                            <Typography sx={{ fontSize: '14px', lineHeight: '16.94px', fontWeight: '700' }}>4.5</Typography>
                                            <Typography sx={{ fontSize: '14px', lineHeight: '14.52px', fontWeight: '400', color: '#FAFAFA' }}>(200+ reviews)</Typography>
                                        </Box>
                                    </Box>

                                </Box>
                            </Box>
                        </Box>

                      </Grid>
                </Grid>
            </Box>


            {/* verify forgate */}
            <FrogatePassword open={open} handleCloseDialog={handleCloseDialog} onClick={handlevarifyopen} />
            <VerifyCode open={verify} handlevarifyclose={handlevarifyclose} onClick={handlepasswordopen}/>
            <NewPassword open={password} handlepasswordclose={handlepasswordclose} />
           
          




        </Box>



    );
}
export default Login;
