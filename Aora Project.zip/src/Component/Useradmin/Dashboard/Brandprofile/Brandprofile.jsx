
import { Box, Typography, Tabs, Tab } from '@mui/material'
import React, { useState } from 'react';
import Button from '@mui/material/Button';
import Aside from '../../Aside';
import { useHistory } from 'react-router-dom';

function Brandprofile() {
  const [value, setValue] = useState(0);
  const history = useHistory();
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const handleButtonClick = () => {
    history.push('/BrandUserform');
  };

  return (
    <div>
         <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

<Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }} >
    <Aside />
</Box>
<Box sx={{ width: "100%" }}>
    <Box sx={{ pb:"1px" }}>
        <Box sx={{ width: {xl:'100%',md:'100%',sm:'100%'}, height: '104px', bgcolor: "#0F0D10", borderRadius: '20px 20px 0px 0px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center   ' }}>
            <Box>
                <Typography sx={{ color: 'white', fontWeight: '700',fontSize:'20px',lineHeight:'32px' }} className='Jakarta'>Brand Profile  </Typography>
                <Typography sx={{  fontWeight: "500",fontSize:'14px',lineHeight:'20px',letter:"0.15px",color:'#D5C9D5' }} className="Jakarta">Lorem Ipsum sit dolor mat neu et</Typography>
            </Box>
            <Box>
                <img src="assets/image/Actions.png" alt="" />
            </Box>
        </Box>
    </Box>
    <Box className=" w-full flex flex-col gap-[16px]">
        <Box sx={{ width: "100%", bgcolor: "#0F0D10", borderRadius: '0px 0px 20px 20px', p: "15px", display: "flex", justifyContent: 'space-between', alignItems: 'end', }}>
            <Tabs value={value} onChange={handleChange} aria-label="Industry Tabs" TabIndicatorProps={{ style: { backgroundColor: 'transparent',display: 'flex', justifyContent: 'center'},
                children: ( <span style={{ maxWidth: 112, width: '100%', backgroundColor: '#A217A3', height: '3px', borderRadius: '4px',}}
                  />
                ),
              }}
            >
              <Tab label="Create Brand Profile" sx={{ padding: '10px', color: '#fff!important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'20px',alignItems:'center',letter:'0.15px',marginBottom:'15px' }} />
              <Tab label="My Brand Profile" sx={{ padding: '10px', color: '#fff!important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'20px',alignItems:'center',letter:'0.15px',marginBottom:'10px' }}/>
            </Tabs>
        </Box>
        
                                    
    </Box>


    <Box sx={{width:'100%',height:'700px',backgroundColor:"#1C1A1E",mt:2}}>
      <Box sx={{p:4}}>
        <Typography sx={{fontWeight:'700',fontSize:'22px',lineHeight:'35px',alignItems:'center',mt:4}}>Welcome!</Typography>
        <Typography sx={{mt:1,color:'#D5C9D5',fontWeight:'400',fontSize:'16px',lineHeight:"25px",letter:'0.15px'}}>Hi there! Welcome to our Brand Creation Tool. Let's get started by gathering some information about your business. Please fill out a form by clicking the button below to help me understand your needs better.</Typography>
        <Button  variant="contained" sx={{bgcolor:'#A217A3 !important',textTransform:'capitalize',mt:5,borderRadius:'10px',py:1}} onClick={handleButtonClick}>Start Forms</Button>
      </Box>
    </Box>
</Box>
</Box>
    </div>
  )
}

export default Brandprofile