
import { Box, Typography, Tabs, Tab } from '@mui/material'
import React, { useState } from 'react';
import Button from '@mui/material/Button';
import Aside from '../../Aside';
import { useHistory } from 'react-router-dom';
import Grid from '@mui/material/Grid';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
function Cardformdata() {
  const [value, setValue] = useState(0);
  const history = useHistory();
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const handleButtonClick = () => {
    history.push('/userform'); // Replace '/your-target-route' with the path you want to navigate to
  };

  return (
    <div>
         <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

<Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }} >
    <Aside />
</Box>
<Box sx={{ width: "100%" }}>
    <Box sx={{ pb: "12px" }}>
        <Box sx={{ width: {xl:'100%',md:'100%',sm:'100%'}, height: '104px', bgcolor: "#0F0D10", borderRadius: '20px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center   ' }}>
        <Box>
                <Typography sx={{ color: 'white', fontWeight: '700',fontSize:'20px',lineHeight:'32px' }} className='Jakarta'>Brand Profile  </Typography>
                <Typography sx={{ fontWeight: "500",fontSize:'14px',lineHeight:'20px',letter:"0.15px",color:'#D5C9D5' }} className="Jakarta">Lorem Ipsum sit dolor mat neu et</Typography>
            </Box>
            <Box>
                <img src="assets/image/Actions.png" alt="" />
            </Box>
        </Box>
    </Box>
    <Box className=" w-full flex flex-col gap-[16px]">
        <Box sx={{ width: "100%", bgcolor: "#0F0D10", borderRadius: '10px', p: "20px", display: "flex", justifyContent: 'space-between', alignItems: 'end', }}>
            <Tabs value={value} onChange={handleChange} aria-label="Industry Tabs" TabIndicatorProps={{ style: { backgroundColor: 'transparent',display: 'flex', justifyContent: 'center'},
                children: ( <span style={{ maxWidth: 112, width: '100%', backgroundColor: '#A217A3', height: '4px', borderRadius: '4px',}}
                  />
                ),
              }}
            >
              <Tab label="Create Brand Profile" sx={{ padding: '20px', color: '#fff!important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'20px',alignItems:'center',letter:'0.15px',marginBottom:'5px' }} />
              <Tab label="My Brand Profile" sx={{ padding: '20px', color: '#fff!important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'20px',alignItems:'center',letter:'0.15px',marginBottom:'5px' }}/>
            </Tabs>
        </Box>
        
                                    
    </Box>


    <Box sx={{width:'100%',height:'750px',backgroundColor:"#1C1A1E",mt:2,color:'#D5C9D5'}}>
      <Box sx={{p:4}}>
        <Typography sx={{fontWeight:'400',fontSize:'16px',lineHeight:'25px',mt:4,color:'#D5C9D5'}}>To help you target the right market, I’ll create three customer personas based on your inputs, please select one persona that you would like to focus on.</Typography>
      
      </Box>
      <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2} sx={{padding:'30px'}}>
        <Grid item xs={4}>
          <Box sx={{border:'1px solid #D5C9D5',borderRadius:'10px',padding:'15px'}}>
            <Typography sx={{fontWeight:'600',fontSize:'13px',lineHeight:'16.38px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Persona 1: The Eco-Conscious Professional</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Name: Emily Green</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Age: 34</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Occupation: Marketing Manager at a Tech Firm Location: San Francisco, CA</Typography>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Background:</Typography>
                <Box sx={{display:'flex',mt:1}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Emily is a working professional in a tech-savvy city, passionate about environmental sustainability.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}} >

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>She enjoys supporting brands that align with her values, particularly those that focus on eco-friendly and ethical practices.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Emily has a well-paying job, allowing her to invest in high-quality clothing that is both stylish and sustainable.</Typography>
                    </Box>
                </Box>
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Goals:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>To maintain a professional appearance at work while adhering to her ethical values.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Challenges:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Finding fashionable clothing that is also sustainable and ethically produced.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5'}}>Balancing her budget while prioritizing eco-friendly products.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5'}}>Shopping Behavior:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Prefers shopping online and follows sustainable fashion influencers for recommendations.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Looks for brands with transparent supply chains and strong environmental commitments.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box sx={{display:'flex',justifyContent:'center',mt:2}}>
                <Button variant="outlined" sx={{py:1,px:6,borderRadius:'10px',border:'1px solid #D5C9D5',color:'#ffffff','&:hover': {
            borderColor: '#D5C9D5', 
          },}}>Select</Button>
            </Box>

          </Box>
        </Grid>
        <Grid item xs={4}>
        <Box sx={{border:'1px solid #D5C9D5',borderRadius:'10px',padding:'15px'}}>
            <Typography sx={{fontWeight:'600',fontSize:'13px',lineHeight:'16.38px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Persona 1: The Eco-Conscious Professional</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Name: Emily Green</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Age: 34</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Occupation: Marketing Manager at a Tech Firm Location: San Francisco, CA</Typography>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Background:</Typography>
                <Box sx={{display:'flex',mt:1}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Emily is a working professional in a tech-savvy city, passionate about environmental sustainability.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}} >

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>She enjoys supporting brands that align with her values, particularly those that focus on eco-friendly and ethical practices.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Emily has a well-paying job, allowing her to invest in high-quality clothing that is both stylish and sustainable.</Typography>
                    </Box>
                </Box>
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Goals:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>To maintain a professional appearance at work while adhering to her ethical values.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Challenges:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Finding fashionable clothing that is also sustainable and ethically produced.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5'}}>Balancing her budget while prioritizing eco-friendly products.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5'}}>Shopping Behavior:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Prefers shopping online and follows sustainable fashion influencers for recommendations.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Looks for brands with transparent supply chains and strong environmental commitments.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box sx={{display:'flex',justifyContent:'center',mt:2}}>
                <Button variant="outlined" sx={{py:1,px:6,borderRadius:'10px',border:'1px solid #D5C9D5',color:'#ffffff','&:hover': {
            borderColor: '#D5C9D5', 
          },}}>Select</Button>
            </Box>

          </Box>
        </Grid>
        <Grid item xs={4}>
        <Box sx={{border:'1px solid #D5C9D5',borderRadius:'10px',padding:'15px'}}>
            <Typography sx={{fontWeight:'600',fontSize:'13px',lineHeight:'16.38px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Persona 1: The Eco-Conscious Professional</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Name: Emily Green</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Age: 34</Typography>
            <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Occupation: Marketing Manager at a Tech Firm Location: San Francisco, CA</Typography>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Background:</Typography>
                <Box sx={{display:'flex',mt:1}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Emily is a working professional in a tech-savvy city, passionate about environmental sustainability.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}} >

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>She enjoys supporting brands that align with her values, particularly those that focus on eco-friendly and ethical practices.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Emily has a well-paying job, allowing her to invest in high-quality clothing that is both stylish and sustainable.</Typography>
                    </Box>
                </Box>
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Goals:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>To maintain a professional appearance at work while adhering to her ethical values.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Challenges:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Finding fashionable clothing that is also sustainable and ethically produced.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5'}}>Balancing her budget while prioritizing eco-friendly products.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box>
                <Typography sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5'}}>Shopping Behavior:</Typography>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Prefers shopping online and follows sustainable fashion influencers for recommendations.</Typography>
                    </Box>
                </Box>
                <Box sx={{display:'flex'}}>
                    <Box sx={{ml:1}}>

                    <FiberManualRecordIcon sx={{ fontSize: '8px', marginRight: '10px', color: '#D5C9D5',mt:-1}} />
                    </Box>
                    <Box>
                        <Typography  sx={{fontWeight:'400',fontSize:'11px',lineHeight:'13.86px',letter:'0.15px',color:'#D5C9D5',mt:0.2}}>Looks for brands with transparent supply chains and strong environmental commitments.</Typography>
                    </Box>
                </Box>
             
              
            </Box>
            <Box sx={{display:'flex',justifyContent:'center',mt:2}}>
                <Button variant="outlined" sx={{py:1,px:6,borderRadius:'10px',border:'1px solid #D5C9D5',color:'#ffffff','&:hover': {
            borderColor: '#D5C9D5', 
          },}}>Select</Button>
            </Box>

          </Box>
        </Grid>
        
      </Grid>
      <Box>
        <Typography sx={{fontWeight:'400',fontSize:'16px',lineHeight:'25px',letter:'0.15px',color:'#D5C9D5',ml:4}}>Here are some hot trends I found for you. If you’re in fashion, these might be particularly interesting:</Typography>
      </Box>
      <Box sx={{ml:4}}>

        <Button  variant="contained" sx={{bgcolor:'#A217A3',textTransform:'capitalize',mt:5,borderRadius:'10px',py:1.5,px:6}} onClick={handleButtonClick}>Next</Button>
      </Box>
    </Box>
      
    </Box>
</Box>
</Box>

    </div>
  )
}

export default Cardformdata
