
import { Box, Typography, Tabs, Tab } from '@mui/material'
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Aside from '../../Aside';
import { useHistory } from 'react-router-dom';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import Button from '@mui/material/Button';
function Formdetails() {
    const [value, setValue] = useState(0);
    const history = useHistory();
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const location = useLocation();
    const { formData } = location.state || {};

    const data = formData.product
    const array = data.split(',').map(item => item.trim());

    const coreValuesArray = formData.coreValues.split(',').map(item => item.trim());

    const handleButtonClick = () => {
        history.push('/datapassa'); // Replace '/your-target-route' with the path you want to navigate to
      };
    

    return (
        <div>
            <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

                <Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }} >
                    <Aside />
                </Box>
                <Box sx={{ width: "100%" }}>
                    <Box sx={{ pb: "1px" }}>
                        <Box sx={{ width: { xl: '100%', md: '100%', sm: '100%' }, height: '104px', bgcolor: "#0F0D10", borderRadius: '20px 20px 0px 0px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center   ' }}>
                            <Box>
                            <Typography sx={{ color: 'white', fontWeight: '700',fontSize:'20px',lineHeight:'32px' }} className='Jakarta'>Brand Profile  </Typography>
                            <Typography sx={{ color: "white", fontWeight: "500",fontSize:'14px',lineHeight:'20px',letter:"0.15px",color:'#D5C9D5' }} className="Jakarta">Lorem Ipsum sit dolor mat neu et</Typography>
                            </Box>
                            <Box>
                                <img src="assets/image/Actions.png" alt="" />
                            </Box>
                        </Box>
                    </Box>
                    <Box className=" w-full flex flex-col gap-[16px]">
                        <Box sx={{ width: "100%", bgcolor: "#0F0D10", borderRadius: '0px 0px 20px 20px', p: "20px", display: "flex", justifyContent: 'space-between', alignItems: 'end', }}>
                            <Tabs value={value} onChange={handleChange} aria-label="Industry Tabs" TabIndicatorProps={{
                                style: { backgroundColor: 'transparent', display: 'flex', justifyContent: 'center' },
                                children: (<span style={{ maxWidth: 112, width: '100%', backgroundColor: '#A217A3', height: '4px', borderRadius: '4px', }}
                                />
                                ),
                            }}
                            >
                                <Tab label="Create Brand Profile" sx={{ padding: '10px', color: '#fff!important', textTransform: 'capitalize', fontWeight: '600', fontSize: '14px', lineHeight: '20px', alignItems: 'center', letter: '0.15px',marginBottom:'10px' }} />
                                <Tab label="Prediction Models" sx={{ padding: '10px', color: '#fff!important', textTransform: 'capitalize', fontWeight: '600', fontSize: '14px', lineHeight: '20px', alignItems: 'center', letter: '0.15px',marginBottom:'10px' }} />
                            </Tabs>
                        </Box>


                    </Box>


                    <Box sx={{ width: '100%',height:'850px', backgroundColor: "#1C1A1E", mt: 2 }}>
                        <Box sx={{ p: 4 }}>
                            <Typography sx={{ mt: 1, color: '#FFF9FF', fontWeight: '700', fontSize: '22px', lineHeight: "35px" }}>Thank you for providing the information!</Typography>
                            <Typography sx={{ mt: 2, color: '#D5C9D5', fontWeight: '400', fontSize: '16px', lineHeight: "25px", letter: '0.15px' }}>Here’s a quick recap of what you shared:</Typography>
                        </Box>

                      
                        <Box sx={{ width: '96%', border: '1px solid #D5C9D5', mx: 4,borderRadius:'10px' }}>
                            <Box sx={{ padding: '10px 60px 10px 60px' }}>
                                {formData ? (
                                    <div>
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Company Name: {formData.companyName}</Typography>
                                        <Typography  sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5'}}>Industry: {formData.industry}</Typography>

                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Products:</Typography>
                                        {array.map((el, index) => (

                                            <li key={index}  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}> Manufactured:{el}</li>



                                        ))}
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Years in Business:{formData.yearsInBusiness}</Typography>
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Countries Sold To:{formData.countriesSoldTo}</Typography>
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Developed/Supplied Brands:{formData.brands}</Typography>
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Company Core Values:{formData.coreValues}</Typography>
                                        <ul style={{ padding: 0, listStyleType: 'none' }}>
                                            {coreValuesArray.map((value, index) => (
                                                <li key={index}>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }} ><FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} />   Sustainability</Typography>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}> <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} />Ethical Production</Typography>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}> <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} />Inclusivity</Typography>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}> <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} />Innovation</Typography>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}> <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} />Quality Craftsmanship</Typography>
                                                </li>
                                            ))}
                                        </ul>
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Target Market:{formData.targetMarket}</Typography>
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Specializations/Unique Products:{formData.specializations}</Typography>
                                        <ul style={{ padding: 0, listStyleType: 'none' }}>
                                            {coreValuesArray.map((value, index) => (
                                                <li key={index}>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}><FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} /> Organic cotton basics</Typography>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}> <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} />Recycled material outerwear</Typography>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}> <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} />Vegan leather accessories</Typography>
                                                    <Typography variant='body1'  sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}> <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '8px' }} />Limited-edition artist collaboration collections</Typography>
                                                </li> 
                                            ))}
                                        </ul>
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Target Price Range:{formData.priceRange}</Typography>
                                        <Typography sx={{ fontWeight: '700', fontSize: '16px', lineHeight: '25px', letter: '0.15px',color:'#D5C9D5' }}>Product Demographics:{formData.productDemographics}</Typography>


                                        {/* Render other form fields similarly */}
                                    </div>
                                ) : (
                                    <p>No data available.</p>
                                )}

                            </Box>

                        </Box>

                        <Box sx={{mt:3,ml:4,}}>
                            <Typography sx={{fontSize:'16px',fontWeightL:'400',lineHeight:'25px',letter:'0.15px',color:'#D5C9D5'}}>Does everything look correct?</Typography>
                            </Box>
                            <Box sx={{display:'flex',ml:4,mt:3}}>
                            <Button sx={{backgroundColor:'#A217A3',py:1,borderRadius:'10px',textTransform:'capitalize',fontWeight:'500',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#FFFFFF','&:hover': {
          backgroundColor: '#A217A3', // Set the hover color to red
        },}} variant="contained"  onClick={handleButtonClick}>Yes, continue</Button>
                            <Button sx={{ml:2,backgroundColor:'transparent',color:'#FFFFFF',border:'1px solid #D5C9D5',borderRadius:'10px',textTransform:'capitalize','&:hover': {
          border: '#D5C9D5', // Set the hover color to red
        },}} variant="outlined">Edit Information</Button>
                            </Box>
                    </Box>
                </Box>
            </Box>
        </div>
    )
}

export default Formdetails
