
import { Box, Typography, Tabs, Tab } from '@mui/material'
import React, { useState } from 'react';
import Button from '@mui/material/Button';

import Aside from '../../Aside';
import { useHistory } from 'react-router-dom';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
function Datapassa() {
    const [value, setValue] = useState(0);
    const history = useHistory();
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const handleButtonClick = () => {
        history.push('/cardformdata'); // Replace '/your-target-route' with the path you want to navigate to
    };

    return (
        <div>
            <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

                <Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }} >
                    <Aside />
                </Box>
                <Box sx={{ width: "100%" }}>
                    <Box sx={{ pb: "1px" }}>
                        <Box sx={{ width: { xl: '100%', md: '100%', sm: '100%' }, height: '104px', bgcolor: "#0F0D10", borderRadius: '20px 20px 0px 0px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center   ' }}>
                            <Box>
                                <Typography sx={{ color: 'white', fontWeight: '700' }} className='Jakarta'>Brand Profile  </Typography>
                                <Typography sx={{  fontWeight: '500', fontSize: "14px", color: '#D5C9D5', mt: 1 }} className='Jakarta'>Lorem Ipsum sit dolor mat neu et  </Typography>
                            </Box>
                            <Box>
                                <img src="assets/image/Actions.png" alt="" />
                            </Box>
                        </Box>
                    </Box>
                    <Box className=" w-full flex flex-col gap-[16px]">
                        <Box sx={{ width: "100%", bgcolor: "#0F0D10", borderRadius: '0px 0px 20px 20px', p: "10px", display: "flex", justifyContent: 'space-between', alignItems: 'end', }}>
                            <Tabs value={value} onChange={handleChange} aria-label="Industry Tabs" TabIndicatorProps={{
                                style: { backgroundColor: 'transparent', display: 'flex', justifyContent: 'center' },
                                children: (<span style={{ maxWidth: 112, width: '100%', backgroundColor: '#A217A3', height: '4px', borderRadius: '4px', }}
                                />
                                ),
                            }}
                            >
                                <Tab label="Create Brand Profile" sx={{ padding: '10px ', color: '#fff!important', textTransform: 'capitalize', fontWeight: '600', fontSize: '14px', lineHeight: '20px', alignItems: 'center', letter: '0.15px' }} />
                                <Tab label="My Brand Profile" sx={{ padding: '20px', color: '#fff!important', textTransform: 'capitalize', fontWeight: '600', fontSize: '14px', lineHeight: '20px', alignItems: 'center', letter: '0.15px' }} />
                            </Tabs>
                        </Box>


                    </Box>
                    <Box sx={{ width: '100%', height: '850px', backgroundColor: "#1C1A1E", mt: 2 }}>
                        <Box sx={{ p: 4 }}>
                            <Typography sx={{ fontWeight: '700', fontSize: '22px', lineHeight: '35px', alignItems: 'center', mt: 4 }}>Got it, Thank you very much, I will take this into account as we develop your brand.</Typography>
                            <Typography sx={{ mt: 1, color: '#D5C9D5', fontWeight: '400', fontSize: '16px', lineHeight: "25px", letter: '0.15px', mt: 4 }}>Great! Now, let’s dive into some trends in the fashion industry.</Typography>
                        </Box>


                        <Box sx={{ width: '96%', border: '1px solid #D5C9D5', mx: 4, borderRadius: '10px' }}>
                            <Box sx={{ padding: '10px 60px 10px 60px' }}>
                                <Typography sx={{ fontWeight: '700', fontSize: '20px', lineHeight: '25px', letter: '0.15px', color: '#D5C9D5' }} >Industry Trend Analysis: Fashion Industry</Typography>
                                <Typography sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px', color: '#D5C9D5', mt: 1 }} >**1. Sustainability & Ethical Fashion</Typography>
                                <Box sx={{ display: 'flex'}}>
                                    <Box>
                                        <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '10px', color: '#D5C9D5' }} />
                                    </Box>
                                    <Typography sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px' }}>Trend Overview: Sustainable fashion continues to dominate the industry as consumers become more conscious of the environmental impact of their purchases. Brands are focusing on eco-friendly materials, ethical production practices, and transparent supply chains.</Typography>
                                </Box>
                                <Box sx={{ display: 'flex' }}>
                                    <Box>
                                        <FiberManualRecordIcon sx={{ fontSize: '10px', marginRight: '10px', color: '#D5C9D5' }} />
                                    </Box>
                                    <Typography sx={{ fontWeight: '400', fontSize: '16px', lineHeight: '25px', letter: '0.15px' }}>Consumer Behavior: Shoppers, especially Millennials and Gen Z, prioritize brands that offer sustainability and ethical production as core values. This shift is pushing more brands to adopt green practices, such as using organic fabrics, reducing water usage, and ensuring fair wages for workers.</Typography>
                                </Box>
                            </Box>

                        </Box>

                        <Box sx={{ mt: 3, ml: 4, }}>
                            <Typography sx={{ fontSize: '16px', fontWeightL: '400', lineHeight: '25px', letter: '0.15px', color: '#D5C9D5' }}>Here are some hot trends I found for you. If you’re in fashion, these might be particularly interesting:</Typography>
                        </Box>
                        <Box sx={{ display: 'flex', ml: 4, mt: 3 }}>
                            <Button sx={{
                                backgroundColor: '#A217A3', py: 1.5,px:5, borderRadius: '10px', textTransform: 'capitalize', fontWeight: '500', fontSize: '16px', lineHeight: '25px', letter: '0.5px', color: '#FFFFFF', '&:hover': {
                                    backgroundColor: '#A217A3',
                                },
                            }} variant="contained" onClick={handleButtonClick}>Next</Button>

                        </Box>
                    </Box>





                </Box>
            </Box>
        </div>
    )
}

export default Datapassa

