
export const validateForm = (formData) => {
    const errors = {};
  
    const requiredFields = [
      { name: 'companyName', message: 'Enter company name' },
      { name: 'product', message: 'Enter product name' },
      { name: 'countriesSoldTo', message: 'Enter countries sold to' },
      { name: 'coreValues', message: 'Enter company core values' },
      { name: 'specializations', message: 'Enter specializations' },
      { name: 'industry', message: 'Select industry' },
      { name: 'yearsInBusiness', message: 'Enter years in business' },
      { name: 'brands', message: 'Enter brands' },
      { name: 'targetMarket', message: 'Select target market' },
      { name: 'priceRange', message: 'Select price range' },
      { name: 'productDemographics', message: 'Enter product demographics' },
    ];
  
    requiredFields.forEach((field) => {
      if (!formData[field.name]) {
        errors[field.name] = field.message;
      }
    });
  
    return errors;
  };