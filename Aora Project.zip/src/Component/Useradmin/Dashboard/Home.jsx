import { Box, Button, Typography, } from '@mui/material'
import React from 'react'
import Aside from '../Aside'
import { useHistory } from 'react-router-dom';
import NotificationDiolog from '../../../dialogs/NotificationDiolog';

const HomePage = () => {
    const history = useHistory();
    const [Notification, setNotification] = React.useState(false);

    const handleNotification = () => {
        setNotification(!Notification);
    };
const handleAddTokenClick = () => {
  history.push('/pricingcard'); 
};
    
const QuickTools = ["Create Fashion", "My Designs", "My Brands", "Marketplace"]
    return (
        <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

            <Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }} >
                <Aside />
            </Box>
            <Box sx={{ width: "100%"}}>
                <Box sx={{ pb: "12px" }}>
                    <Box sx={{ width: {xl:'100%',md:'100%',sm:'100%'}, height: '104px', bgcolor: "#0F0D10", borderRadius: '20px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center   ' }}>
                        <Box>
                            <Typography sx={{ color: 'white', fontWeight: '700' ,fontSize:"20px",lineHeight:'32px'}} className='Jakarta'>Welcome back, Aora </Typography>
                            <Typography sx={{ color: '#D5C9D5', fontWeight: '500',fontSize:"14px",lineHeight:'20px',letter:'0.15px' }} className='Jakarta'>Bring your fashion ideas to life with Aora </Typography>
                        </Box>
                        <Box>
                            <img src="assets/image/Actions.png" alt="" onClick={handleNotification}/>
                        </Box>
                    </Box>
                </Box>
                <Box className=" w-full flex flex-col gap-[16px]">
                    <Box sx={{ width: "396px", bgcolor: "#1C1A1E", borderRadius: '20px', p: "20px", display: "flex", justifyContent: 'space-between', alignItems: 'end' }}>
                        <Box>
                            <Typography sx={{ color: 'white', fontWeight: '400', fontSize: '16PX', lineHeight: "20px", pb: "11px" }} className='Jakarta '>Token Balance</Typography>
                            <Typography className='Jakarta' sx={{ color: '#D5C9D5', fontWeight: '400', fontSize: "40PX", lineHeight: "50px" }}>0</Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: "end" }}>
                            <Button sx={{ bgcolor: "#A217A3 !important", borderRadius: '10px' }}  onClick={handleAddTokenClick} >
                                <Typography sx={{ color: "white", textTransform: 'capitalize', px: "8px", fontSize: "14px",py:0.5 }} className='Jakarta'> Add Token</Typography>
                                <img src="assets/icons/plus.png" alt="" class="w-[14px] h-[14px]" />
                            </Button>
                        </Box>
                    </Box>
                    <Box sx={{ width:{xl:'100%',md:'100%',sm:'100%'}, bgcolor: "#1C1A1E", borderRadius: '20px', p: "20px", pb: "25px", display: "flex", justifyContent: 'space-between', alignItems: 'end' }}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: "19px", }}>
                            <Typography sx={{ color: 'white', fontWeight: '700', fontSize: '16px' }} className='Jakarta'>Quick Tools</Typography>
                            <Box sx={{ display: "flex", gap: "15px" }}>
                                {QuickTools.map((el) => (
                                    <Button sx={{ padding: {xl:"10px 20px",sm:'5px 15px'}, bgcolor: "#29272C",textTransform:'capitalize', border: "1px solid #686B6E", lineHeight: "20px", color: "#E8E9E9", borderRadius: "10px", fontSize: {xl:'12px',md:'10px',sm:'9px'} }}>{el}</Button>
                                ))}
                            </Box>
                        </Box>
                    </Box>
                    <Box sx={{ display: 'flex', gap: "18px" }} >
                        <Box sx={{ width: "50%" , color: "white", borderRadius: "20px", display: "flex", flexDirection: "column", gap: "18px" }}>
                            <Box sx={{ width: '100%', height: "322px", bgcolor: "#1C1A1E", borderRadius: "20px", position: "relative" }}>
                                <Box sx={{ position: "absolute",top:"42%" ,left:"40%", display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center" }} >
                                    <img src="assets/icons/folder.svg" alt="" width="50px" height="50px" />
                                    <Typography sx={{color:"#989494",fontSize:"12px",pt:2,pb:1,lineHeight:"16px"}} className="Inter">No Recent Activity</Typography>
                                    <Typography sx={{color:"#989494",fontSize:"10px",lineHeight:"13px"}} >No recent Activity detected.</Typography>
                                </Box>
                                <Typography sx={{ fontSize: "16px", fontWeight: "700", p: "20px " }} className='Jakarta'>Recent Activities</Typography>
                            </Box>
                            <Box sx={{ width: '100%', bgcolor: "#1C1A1E", height: "257px", borderRadius: "10px", p: "20px" }}>
                                <Typography sx={{ fontSize: "16px", fontWeight: "700", pb: "25px" }} className='Jakarta'>Marketplace Order</Typography>
                                <Box sx={{ display: "flex", flexDirection: "column", gap: "17px" }}>

                                    <Box sx={{ display: "flex", justifyContent: "space-between", p: "10px", bgcolor: "#29272C", border: "1px solid #686B6E", borderRadius: "6px" }}>
                                        <Typography sx={{ fontSize: "14px", lineHeight: "20px", fontWeight: "600" }}>Visit Marketplace</Typography><img src="assets/icons/nextArrow.svg" alt="" />
                                    </Box>
                                    <Box sx={{ display: "flex", justifyContent: "space-between", p: "10px", bgcolor: "#29272C", border: "1px solid #686B6E", borderRadius: "6px" }}>
                                        <Typography sx={{ fontSize: "14px", lineHeight: "20px", fontWeight: "600" }}>Visit Marketplace</Typography><img src="assets/icons/nextArrow.svg" alt="" />
                                    </Box>
                                    <Box sx={{ display: "flex", justifyContent: "space-between", p: "10px", bgcolor: "#29272C", border: "1px solid #686B6E", borderRadius: "6px" }}>
                                        <Typography sx={{ fontSize: "14px", lineHeight: "20px", fontWeight: "600" }}>Visit Marketplace</Typography><img src="assets/icons/nextArrow.svg" alt="" />
                                    </Box>
                                </Box>
                            </Box>


                        </Box>
                        <Box sx={{ width: "50%", bgcolor: "#1C1A1E", borderRadius: "10px", p: "20px 13px 20px 20px" }}>
                            <Typography sx={{ fontSize: "16px", fontWeight: "700", lineHeight: "20px" }}>Trending Styles</Typography>
                            <Typography sx={{ fontSize: "12px", fontWeight: "500", lineHeight: "20px", color: "#D5C9D5", pt: "20px", pb: "10px" }}>Women styles</Typography>
                            <Box sx={{ display: "flex", gap: "12px" }}>
                                <Box item xs={4}>
                                    <img src="assets/image/trending1.svg" alt="" class="w-[160px] h-[160px]" />
                                    <Typography sx={{ py: "3px", fontSize: "12px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "600", }}>Lorem ipsum dolor sit</Typography>
                                    <Box sx={{ borderBottom: "2px solid #A217A3", width: "27px" }}></Box>
                                    <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                                        <Typography sx={{ fontSize: "10px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "300", }}>
                                            Lifestyle
                                        </Typography> <img src="assets/icons/vertical3Dots.svg" alt="" class="pe-1" />
                                    </Box>
                                </Box>
                                <Box item xs={4}>
                                    <img src="assets/image/trending1.svg" alt="" class="w-[160px] h-[160px]" />
                                    <Typography sx={{ py: "3px", fontSize: "12px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "600", }}>Lorem ipsum dolor sit</Typography>
                                    <Box sx={{ borderBottom: "2px solid #A217A3", width: "27px" }}></Box>
                                    <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                                        <Typography sx={{ fontSize: "10px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "300", }}>
                                            Lifestyle
                                        </Typography> <img src="assets/icons/vertical3Dots.svg" alt="" class="pe-1" />
                                    </Box>
                                </Box>
                                <Box item xs={4}>
                                    <img src="assets/image/trending1.svg" alt="" class="w-[160px] h-[160px]" />
                                    <Typography sx={{ py: "3px", fontSize: "12px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "600", }}>Lorem ipsum dolor sit</Typography>
                                    <Box sx={{ borderBottom: "2px solid #A217A3", width: "27px" }}></Box>
                                    <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                                        <Typography sx={{ fontSize: "10px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "300", }}>
                                            Lifestyle
                                        </Typography> <img src="assets/icons/vertical3Dots.svg" alt="" class="pe-1" />
                                    </Box>
                                </Box>
                            </Box>
                            <Typography sx={{ fontSize: "12px", fontWeight: "500", lineHeight: "20px", color: "#D5C9D5", pt: "20px", pb: "10px" }}>Men styles</Typography>
                            <Box sx={{ display: "flex", gap: "12px" }}>
                                <Box item xs={4}>
                                    <img src="assets/image/trending1.svg" alt="" class="w-[160px] h-[160px]" />
                                    <Typography sx={{ py: "3px", fontSize: "12px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "600", }}>Lorem ipsum dolor sit</Typography>
                                    <Box sx={{ borderBottom: "2px solid #A217A3", width: "27px" }}></Box>
                                    <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                                        <Typography sx={{ fontSize: "10px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "300", }}>
                                            Lifestyle
                                        </Typography> <img src="assets/icons/vertical3Dots.svg" alt="" class="pe-1" />
                                    </Box>
                                </Box>
                                <Box item xs={4}>
                                    <img src="assets/image/trending1.svg" alt="" class="w-[160px] h-[160px]" />
                                    <Typography sx={{ py: "3px", fontSize: "12px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "600", }}>Lorem ipsum dolor sit</Typography>
                                    <Box sx={{ borderBottom: "2px solid #A217A3", width: "27px" }}></Box>
                                    <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                                        <Typography sx={{ fontSize: "10px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "300", }}>
                                            Lifestyle
                                        </Typography> <img src="assets/icons/vertical3Dots.svg" alt="" class="pe-1" />
                                    </Box>
                                </Box>
                                <Box item xs={4}>
                                    <img src="assets/image/trending1.svg" alt="" class="w-[160px] h-[160px]" />
                                    <Typography sx={{ py: "3px", fontSize: "12px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "600", }}>Lorem ipsum dolor sit</Typography>
                                    <Box sx={{ borderBottom: "2px solid #A217A3", width: "27px" }}></Box>
                                    <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                                        <Typography sx={{ fontSize: "10px", color: "#D5C9D5", lineHeight: "25px", fontWeight: "300", }}>
                                            Lifestyle
                                        </Typography> <img src="assets/icons/vertical3Dots.svg" alt="" class="pe-1" />
                                    </Box>
                                </Box>
                            </Box>
                        </Box>
                    </Box>
                </Box>
            </Box>

           <NotificationDiolog  isOpen={Notification} handleClick={handleNotification}/>

        </Box>
    )
}

export default HomePage