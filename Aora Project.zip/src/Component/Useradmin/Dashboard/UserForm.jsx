import { Box, Typography } from '@mui/material'
// import Aside from './Useradmin/Aside';
import Aside from '../Aside';
import CloseIcon from '@mui/icons-material/Close';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import { useHistory } from 'react-router-dom';
import  { useState } from 'react';

function UserForm() {
  const [formData, setFormData] = useState({
    companyName: '',
    product: '',
    countriesSoldTo: '',
    coreValues: '',
    specializations: '',
    industry: '',
    yearsInBusiness: '',
    brands: '',
    targetMarket: '',
    priceRange: '',
    productDemographics:'',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    // Action path: log or send data to an API endpoint, etc.
    console.log('Form Submitted:', formData);
    // Example: Redirect or perform other actions
  };
 
    const history = useHistory();
    const handleButtonClick = () => {
      history.push('/formdatails', { formData });
      };
    
      
  return (
    <div>
         <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

<Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }} >
    <Aside />
</Box>
<Box sx={{ width: "100%" }}>
    <Box sx={{ pb: "12px" }}>
        <Box sx={{ width: {xl:'100%',md:'100%',sm:'100%'}, height: '104px', bgcolor: "#0F0D10", borderRadius: '20px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center   ' }}>
            <Box>
                <Typography sx={{ color: 'white', fontWeight: '700' }} className='Jakarta'>Brand Profile  </Typography>
            </Box>
            <Box>
                <img src="assets/image/Actions.png" alt="" />
            </Box>
        </Box>
    </Box>
    <Box className=" w-full flex flex-col gap-[16px]">
        <Box sx={{ width: "100%", bgcolor: "#1C1A1E", borderRadius: '10px',padding:'10px 10px 10px 10px', display: "flex", justifyContent: 'space-between', alignItems: 'end', }}>
     <Box sx={{width:'100%',bgcolor:'#29272C',margin:"55px 50px 55px 50px",borderRadius:'10px'}}>
    <Box sx={{display:'flex',justifyContent:'space-between',m:4}}>
      <Typography sx={{color:'#D5C9D5',fontWeight:'700',fontSize:'32px',lineHeight:'32px'}}>User Form</Typography>
      <CloseIcon sx={{color:'#D5C9D5'}} />


    
    </Box>
      <Box sx={{ flexGrow: 1,m:4}}>
        <form  onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        
        <Grid item xs={6}>
          <Box >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Company name*</Typography>
            <input name="companyName"
              value={formData.companyName}
              onChange={handleChange} style={{width:'100%',borderRadius:'5px',height:'35px', backgroundColor: '#1C1A1E',border:'1px solid #989494'}} />
          </Box>
          <Box sx={{mt:2}} >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Product (Manufactured or Sold)*</Typography>
            <input name="product"
              value={formData.product}
              onChange={handleChange} style={{width:'100%',borderRadius:'5px',height:'35px', backgroundColor: '#1C1A1E',border:'1px solid #989494' }} />
          </Box>
          <Box sx={{mt:2}} >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Countries sold to</Typography>
            <input  name="countriesSoldTo"
              value={formData.countriesSoldTo}
              onChange={handleChange} style={{width:'100%',borderRadius:'5px',height:'35px', backgroundColor: '#1C1A1E',border:'1px solid #989494' }} />
          </Box>
          <Box sx={{mt:2}} >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Company core values*</Typography>
            <input name="companycorevalues" onChange={handleChange} value={formData.coreValues} style={{width:'100%',borderRadius:'5px',height:'35px', backgroundColor: '#1C1A1E',border:'1px solid #989494' }} />
          </Box>
          <Box sx={{mt:2}} >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Specializations/ Unique Products</Typography>
            <input  name="companycorevalues" onChange={handleChange} value={formData.specializations} style={{width:'100%',borderRadius:'5px',height:'35px', backgroundColor: '#1C1A1E',border:'1px solid #989494' }} />
          </Box>
       
        </Grid>

        <Grid item xs={6}>
        <Box >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Industry*</Typography>
            {/* <input style={{width:'100%',borderRadius:'5px',height:'30px', backgroundColor: '#1C1A1E'}} /> */}
            
            <select  name="industry"
              value={formData.industry}
              onChange={handleChange}
            
    style={{
      width: '100%',
      borderRadius: '5px',
      height: '35px', 
      backgroundColor: '#1C1A1E',
      color: '#ffffff', 
      border:'1px solid #989494',
      padding: '5px 20px',
      
    }}
  >
    <option value="">Fashion</option>
    <option value="technology">T-Shirt</option>
    <option value="finance">Shirt</option>
    <option value="healthcare">Polo</option>
    <option value="education">Denim</option>
    <option value="manufacturing">Jacket</option>
    <option value="retail">Bottoms</option>
  </select>
          </Box>
          <Box sx={{mt:2}}  >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Years in Business*</Typography>
            <input name="yearsInBusiness"
              value={formData.yearsInBusiness}
              onChange={handleChange} style={{width:'100%',borderRadius:'5px',height:'35px', backgroundColor: '#1C1A1E',border:'1px solid #989494'}} />
          </Box>
          <Box  sx={{mt:2}} >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Developed/Supplied Brands</Typography>
            <input name="brands"
              value={formData.brands}
              onChange={handleChange} style={{width:'100%',borderRadius:'5px',height:'35px', backgroundColor: '#1C1A1E',border:'1px solid #989494'}} />
          </Box>
          <Box sx={{mt:2}}  >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Target Market to sell*</Typography>
            {/* <input style={{width:'100%',borderRadius:'5px',height:'30px', backgroundColor: '#1C1A1E',border:'1px solid #989494'}} /> */}
            <select
            name="targetMarket"
            value={formData.targetMarket}
            onChange={handleChange}
    style={{
      width: '100%',
      fontWeight:600,
      fontSize:'16px',
lineHeight:'20.16',     
borderRadius: '5px',
      height: '35px',
      backgroundColor: '#1C1A1E',
      border: '1px solid #989494',
      color: '#F1EDED', // Set text color to contrast with background
      paddingLeft: '20px', // Add padding inside the select
    }}
  >
    <option value="" disabled selected>Sell to Businesses</option>
    <option value="technology">Technology</option>
    <option value="finance">Finance</option>
    <option value="healthcare">Healthcare</option>
    <option value="education">Education</option>
    <option value="manufacturing">Manufacturing</option>
    <option value="retail">Retail</option>
  </select>
          </Box>
          <Box sx={{mt:2}} >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Target Price Range</Typography>
            {/* <input style={{width:'100%',borderRadius:'5px',height:'30px', backgroundColor: '#1C1A1E',border:'1px solid #989494'}} /> */}
            <select name="priceRange"
              value={formData.priceRange}
              onChange={handleChange}
    style={{
      width: '100%',
      borderRadius: '5px',
      height: '35px',
      backgroundColor: '#1C1A1E',
      border: '1px solid #989494',
      color: '#ffffff',
      paddingLeft: '20px', // Padding inside the select field
    }}
  >
    <option value="" disabled selected>Select a price range</option>
    <option value="low">Below $100</option>
    <option value="medium">$100 - $500</option>
    <option value="high">$500 - $1000</option>
    <option value="premium">Above $1000</option>
  </select>
          </Box>
        </Grid>
       
      </Grid>
      <Box sx={{mt:2}} >
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'25px',letter:'0.5px',color:'#D5C9D5',mb:1}}>Product Demographics*</Typography>
            <Box sx={{width:'100%',display:'flex'}}>

            <input name="productDemographics"
              value={formData.productDemographics}
              onChange={handleChange} style={{width:'30%',borderRadius:'5px',height:'35px', backgroundColor: '#1C1A1E',border:'1px solid #989494' }} />
            <Box sx={{display:'flex',alignItems:'center',flexDirection:'row',gap:1,ml:2}}>

             <input  checked   type="radio" name="a" />Men
             <input checked  type="radio" name="a" />Women
             <input checked  type="radio" name="a" />Children
             <input checked  type="radio" name="a" />Pets
             <input checked  type="radio" name="a" />Elderly
            </Box>
            
            </Box>
          </Box>
          </form>
          <Box sx={{mt:3}}>
            <Button sx={{bgcolor:'#A217A3',borderRadius:'20px',py:1,px:2,color:'#D9D9D9',textTransform:'capitalize'}} onClick={handleButtonClick}>Save & Continue</Button>
            <Button sx={{bgcolor:'transparent',borderRadius:'20px',px:2,color:'#D9D9D9',textTransform:'capitalize',border:'1px solid #D5C9D5',ml:3}}>Cancel</Button>
          </Box>
   
      </Box>
     </Box>
        </Box>
        
   
    </Box>


   
</Box>
</Box>
    </div>
  )
}

export default UserForm