import { Divider, Typography } from '@mui/material'
import React from 'react'
import Box from '@mui/material/Box';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useState } from 'react';
import SearchIcon from '@mui/icons-material/Search';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';

import Button from '@mui/material/Button';
import { Description } from '@mui/icons-material';


const tabData = [
  { label: "Women Styles", content: "Content for Women Styles" },
  { label: "Men Styles", content: "Content for Men Styles" },
  { label: "Fabric", content: "Content for Fabric" },
  { label: "Colors", content: "Content for Colors" },
  { label: "Models", content: "Content for Models" },
];

function SampleNextArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{ ...style, display: "block" ,fontSize:'40px' }}
      onClick={onClick}
    />
  );
}

function SamplePrevArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{ ...style, display: "block", }}
      onClick={onClick}
    />
  );
}

const settings = {
  dots: false,
  infinite: false,
  speed: 500,
  slidesToShow: 8,
  slidesToScroll: 8,
  arrows: true,
  variableWidth: true,
  nextArrow: <SampleNextArrow />,
  prevArrow: <SamplePrevArrow />
};

let ALL_CATEGORY = [
  {
    id: 1,
    image: "/assets/image/trading1.svg",
    lorem:"Lorem ipsum dolor sit amet, consectetur adipiscing elit,",
    category: "Trending Styles",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 2,
    image: "/assets/image/trading2.svg",
    category: "Trending Styles",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 3,
    image: "/assets/image/trading3.svg",
    category: "Trending Styles",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 4,
    image: "/assets/image/trading4.svg",
    category: "Trending Styles",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 3,
    image: "https://www.desktopbackground.org/p/2010/08/01/57529_2015-dodge-challenger-car-wallpapers-hd-wallpapers_1280x904_h.jpg",
    category: "Dress",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 4,
    image: "https://c4.wallpaperflare.com/wallpaper/596/611/685/best-car-toyota-supra-mk4-wallpaper-preview.jpg",
    category: "Sweater",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 5,
    image: "https://c.wallhere.com/photos/2f/b6/1280x853_px_car_JDM_Lowered_Stance_Toyota_Supra_MK4_Tuning-543447.jpg!d",
    category: "T-Shirt",Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle',
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'


  },
  {
    id: 6,
    image: "https://e1.pxfuel.com/desktop-wallpaper/859/700/desktop-wallpaper-awesome-toyota-supra-back-angle-1998-toyota-supra.jpg",
    category: "Crop Top",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle',
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'


  },

  {
    id: 8,
    image: "https://w0.peakpx.com/wallpaper/240/580/HD-wallpaper-porsche-porsche-911-gt3-car-porsche-911-sport-car-black-car.jpg",
    category: "Gown",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle',
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'


  },
  {
    id: 9,
    image: "https://c4.wallpaperflare.com/wallpaper/71/419/679/porsche-porsche-911-gt3-black-car-car-coupe-hd-wallpaper-preview.jpg",
    category: "Dress",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

    
  

  },
  {
    id: 10,
    image: "https://wallpapersmug.com/download/3840x2400/11010b/Bentley-Continental-luxurious-car.jpg",
    category: "Sweater",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 11,
    image: "https://i.pinimg.com/736x/10/04/f5/1004f5a41fa5a5c576c4bbdcb5a5997a.jpg",
    category: "T-Shirt",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 12,
    image: "https://w.forfun.com/fetch/22/223576bc337f698dbf60be02f9eafa0d.jpeg",
    category: "Crop Top",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },
  {
    id: 13,
    image: "https://www.hdcarwallpapers.com/walls/mini_cooper_s_2018_4k-HD.jpg",
    category: "Blouse",
    Description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit,',
    fashion:'Lifestyle'

  },


]
function Trading() {
  const [value, setValue] = useState(0);
  const [List, SetList] = useState(ALL_CATEGORY);
  
const [currentIndex, setCurrentIndex] = useState(0);


const handleClick = (index, onClick) => {
  setCurrentIndex(index);
  onClick();
};

  const CATEGORY_HANDLER = (DATA) => {
    if (DATA === 'All') {
      SetList(ALL_CATEGORY);
    } else {
      let SELECT = ALL_CATEGORY.filter((el) => el.category === DATA);
      SetList(SELECT);
    }
  };
  const [selectedTab, setSelectedTab] = useState(tabData[0].label);

  const handleChange = (event, newValue) => {
    setValue(newValue);
    setSelectedTab(tabData[newValue].label);
  };




  const buttons = [
    { text: 'Trending Styles', onClick: () => CATEGORY_HANDLER('Trending Styles') },
    { text: 'Blouse', onClick: () => CATEGORY_HANDLER('Blouse') },
    { text: 'Crop Top', onClick: () => CATEGORY_HANDLER('Crop Top') },
    { text: 'T-Shirt', onClick: () => CATEGORY_HANDLER('T-Shirt') },
    { text: 'Sweater', onClick: () => CATEGORY_HANDLER('Sweater') },
    { text: 'Dress', onClick: () => CATEGORY_HANDLER('Dress') },
    { text: 'Gown', onClick: () => CATEGORY_HANDLER('Gown') },
    { text: 'Suit', onClick: () => CATEGORY_HANDLER('Suit') },
    { text: 'Jacket', onClick: () => CATEGORY_HANDLER('Jacket') },
    { text: 'Shirt', onClick: () => CATEGORY_HANDLER('Shirt') },
    { text: 'Pants', onClick: () => CATEGORY_HANDLER('Pants') },
    { text: 'Shorts', onClick: () => CATEGORY_HANDLER('Shorts') },
    { text: 'Skirt', onClick: () => CATEGORY_HANDLER('Skirt') },
    { text: 'Jumpsuit', onClick: () => CATEGORY_HANDLER('Jumpsuit')},
    { text: 'Jacket', onClick: () => CATEGORY_HANDLER('Jacket')},
    { text: 'Sweater', onClick: () => CATEGORY_HANDLER('Sweater')},
    { text: 'Dress', onClick: () => CATEGORY_HANDLER('Dress')},
    { text: 'Gown', onClick: () => CATEGORY_HANDLER('Gown')},
    { text: 'Suit', onClick: () => CATEGORY_HANDLER('Suit')},
    { text: 'Shirt', onClick: () => CATEGORY_HANDLER('Shirt')},
  ];



  return (
    <Box >
      <Box sx={{}}>
        <Typography sx={{ fontWeight: '500', fontSize: '40px', lineHeight: '32px', color: 'black', textAlign: 'center', padding: '30px' }}  className='Jakarta'>Trending  Now</Typography>
      </Box>

      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Grid container maxWidth="xl" sx={{ justifyContent: 'center' }} spacing={2}>
          <Grid item xs={9}>
            <Box >
              <Tabs
                value={value}
                onChange={handleChange}
                aria-label="Industry Tabs"
                TabIndicatorProps={{
                  style: {
                    backgroundColor: 'transparent',
                    display: 'flex',
                    justifyContent: 'center',
                  },
                  children: (
                    <span
                      style={{
                        maxWidth: 112,
                        width: '100%',
                        backgroundColor: '#A217A3',
                        height: '4px',
                        borderRadius: '4px',
                      }}
                    />
                  ),
                }}
              >

                {tabData.map((tab, index) => (
                  <Tab
                    key={index}
                    label={tab.label}
                    sx={{ padding: '20px',textTransform:'none', color: '#160816!important', ml: index === 0 ? -1 : 0, fontWeight: '500', fontSize: '14px', lineHeight: '17.64px',marginBottom:'-10px' }}
                  />
                ))}
              </Tabs>
            </Box>

          </Grid>
          <Grid item xs={2}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-center', alignItems: 'center', height: '50px', backgroundColor: '#BEBCBC', borderRadius: '50px', padding: '20px' }}>
              {/* <SearchIcon sx={{ color: 'black !important' }} /> */}
              <img src="/assets/image/search.svg" alt="" />
              <input
                type="text"
                name="search"
                placeholder="Search"
                style={{
                  border: 'none',
                  outline: 'none',
                  marginLeft: '8px',
                  width: '100%',
                  fontSize: '14px',
                  backgroundColor: 'transparent',
                  color: 'black',
                }}
              />
            </Box>
          </Grid>

        </Grid>
      </Box>


      <Box sx={{ mt: 5, width: 'full',borderTop:'1px solid grey'}}>
        <Container sx={{width:"100%"}}>

<Box >
      <Slider {...settings}>
        {buttons.map((button, index) => (
          <div key={index} style={{ padding: '0px' }}>
            <Button
              onClick={() => handleClick(index, button.onClick)}
              sx={{
                margin: '5px',
                borderRadius: '20px',
                border: '1px solid grey',
                textTransform:'none',
                transition: 'border 0.3s',
                mt:4,
                px: 5,
                backgroundColor: currentIndex === index ? 'purple' : 'transparent',
                color: currentIndex === index ? 'white' : 'black',
                '&:hover': {
                  borderColor: 'pink',
                },
              }}
            >
              {button.text}
            </Button>
          </div>
        ))}
      </Slider>
    </Box>
    </Container>



    
          <Box sx={{ mt: 4, borderTop: '1px solid grey', display: 'flex', alignItems: 'center' }}>
  <Grid container justifyContent="start" spacing={2}>
    {List.map(item => (
      <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={item.id} display="flex" justifyContent="center">
        <Card sx={{ width: 200, mt: 5 }}>
          <Box
            sx={{
              backgroundImage: `url(${item.image})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              height: '220px',
              width: '100%',
            }}
          /> 
          <CardContent>
            <Typography sx={{ color: '#1C1C1C', fontSize: '14px', fontWeight: '600', lineHeight: '25px' }} gutterBottom variant="h5" component="div">
              {item.Description}
            </Typography>
            <Divider sx={{ borderColor: '#A217A3', fontWeight: '700', borderWidth: 2, width: '40px' }} />
            <Box>
              <Typography sx={{ color: '#1C1C1C', fontWeight: '400', fontSize: '12px', lineHeight: '25px' }}>{item.fashion}</Typography>
            </Box>
          </CardContent>
        </Card>
      </Grid>
    ))}
  </Grid>
</Box>

      
      
      </Box>
    </Box>
  )
}

export default Trading
