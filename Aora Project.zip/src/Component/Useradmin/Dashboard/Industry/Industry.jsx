import { Box, Typography, Tabs, Tab } from '@mui/material';
import React, { useState } from 'react';
import Aside from '../../Aside';
import Trading from './Trading';



function Industry() {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <>
      <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px" }}>
        <Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }}>
          <Aside />
        </Box>
        <Box sx={{ width: "100%" }}>
          <Box sx={{ pb: "12px" }}>
            <Box sx={{ width: '100%', height: '104px', bgcolor: "#pink", borderRadius: '20px 20px 0px 0px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#0F0D10' }}>
              <Box>
                <Typography sx={{ color: 'white', fontWeight: '700',fontSize:"20px",lineHeight:'32px' }}  className='Jakarta'>Industry Trends</Typography>
                <Typography sx={{ color: '#D5C9D5', fontWeight: '500',fontSize:"14px",lineHeight:'20px',letter:'0.15px' }}  className='Jakarta'>Lorem Ipsum sit dolor mat neu et</Typography>
              </Box>
              <Box>
                <img src="assets/image/Actions.png" alt="" />
              </Box>
            </Box>
          </Box>

          <Box sx={{ width: '100%', height: '80px', backgroundColor: '#0F0D10', borderRadius: '0px 0px 20px 20px', mt: '-10px' }}>
            <Tabs
              value={value}
              onChange={handleChange}
              aria-label="Industry Tabs"
              TabIndicatorProps={{
                style: {
                  backgroundColor: 'transparent',
                  display: 'flex',
                  justifyContent: 'center',
                },
                children: (
                  <span
                    style={{
                      maxWidth: 112,
                      width: '100%',
                      backgroundColor: '#A217A3',
                      height: '10px', // Set the height of the indicator line to 10px
          borderRadius: '4px',
          marginBottom: '5px', 
                      
                     
                    }}
                  />
                ),
              }}
            >
              <Tab label="Trending Now" sx={{ padding: '20px', color: '#fff!important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'20px',alignItems:'center',letter:'0.15px',marginBottom:'5px' }}  className='Jakarta' />
              <Tab label="Prediction Models" sx={{ padding: '20px', color: '#fff!important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'20px',alignItems:'center',letter:'0.15px',marginBottom:'5px'  }}  className='Jakarta'/>
            </Tabs>
          </Box>

          <Box sx={{ p: "24px", bgcolor: "white", borderRadius: '10px', mt: 0.5 }}>
            {value === 0 &&  <Trading /> }
            
          </Box>
        </Box>
      </Box>
    </>
  );
}

export default Industry;