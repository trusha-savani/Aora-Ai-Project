import {  Typography } from "@mui/material";
import Box from "@mui/material/Box";
import React from "react";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import { useState } from "react";
import ImageUploader from './Components/ImageUploader';

import DownloadButton from './Components/DownloadButton';



function Createfashionliveserver({handleOpenDialog }) {
  const [imageSrc, setImageSrc] = useState(null);
  



  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Check out this awesome content!",
          text: "Here is some content that I wanted to share with you.",
          url: "https://example.com",
        });
        console.log("Content shared successfully");
      } catch (error) {
        console.error("Error sharing content:", error);
      }
    } else {
      alert("Web Share API is not supported in your browser.");
    }
  };

 

 

  return (
    <Box
      sx={{
        width: "100%",
        height: "750px",
        backgroundColor: "#1C1A1E",
        display: "flex",
        justifyContent: "center",
      }}
    >
      <Box
        sx={{
          width: "100%",
          backgroundColor: "#29272C",
          justifyContent: "center",
          margin: "80px",
          borderRadius: "20px",
          padding: "100px 150px 100px 150px",
        }}
      >
        <Typography
          sx={{
            textAlign: "center",
            fontWeight: "600",
            fontSize: "32px",
            lineHeight: "18px",
            letter: "0.15px",
            color: "#D5C9D5",
          }}
        >
          Select Style
        </Typography>

        <Box sx={{ flexGrow: 1 }}>
          <Grid container spacing={1}>
            <Grid
              item
              xs={7}
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
             

              <ImageUploader imageSrc={imageSrc}  setImageSrc={setImageSrc}
               
               />

            </Grid>
            <Grid
              item
              xs={5}
              sx={{
                padding: "40px 50px 0px 20px",
                mt: 4,
                borderRadius: "10px",
              }}
            >
              <Box
                sx={{
                  width: "100%",
                  height: "210px",
                  bgcolor: "#989494",
                  margin: "50px 50px 50px 50px",
                  borderRadius: "20px",
                  flexDirection: "column",
                  p: 2,
                }}
              >
                <Box>
                  <Button
                    sx={{
                      bgcolor: "#29272C !important",
                      color: "#989494",
                      borderRadius: "10px",
                      fontWeight: "500",
                      fontSize: "9.8px",
                      lineHeight: "14px",
                      letter: "0.11px",
                      textTransform: "capitalize",
                    }}
                    startIcon={
                      <Box
                        component="img"
                        src="/assets/image/createclose.svg"
                        alt="icon"
                        sx={{ width: "20px", height: "20px" }}
                      />
                    }
                    
                  >
                    Remove Background
                  </Button>
                </Box>
                <Box sx={{ mt: 2 }}>
                  <Button
                    sx={{
                      bgcolor: "#29272C !important",
                      color: "#989494",
                      borderRadius: "10px",
                      fontWeight: "500",
                      fontSize: "9.8px",
                      lineHeight: "14px",
                      letter: "0.11px",
                      textTransform: "capitalize",
                    }}
                    startIcon={
                      <Box
                      component="img"
                      src="/assets/image/createchange.svg"
                      alt="icon"
                      sx={{ width: "20px", height: "20px" }}
                      />
                    }
                    onClick={handleOpenDialog}
                  >
                  Change Background
                  </Button>
                 
                  {/* {showSliders && (
                    <ImageSliders filterValues={customFilter} handleSliderChange={handleSliderChange} />
                  )} */}

                  <Button
                    sx={{
                      bgcolor: "#29272C !important",
                      color: "#989494",
                      borderRadius: "10px",
                      fontWeight: "500",
                      fontSize: "9.8px",
                      lineHeight: "14px",
                      letter: "0.11px",
                      ml: 2,
                      textTransform: "capitalize",
                      py: 1,
                    }}
                    startIcon={
                      <Box
                        component="img"
                        src="/assets/image/createmagic.svg"
                        alt="icon"
                        sx={{ width: "12px", height: "12px", ml: 1 }}
                      />
                    }
                  >
                    Magic Wand Tool
                  </Button>
                </Box>
                <Box sx={{ mt: 2 }}>
                  <Button
                    sx={{
                      bgcolor: "#29272C !important",
                      color: "#989494",
                      borderRadius: "10px",
                      fontWeight: "500",
                      fontSize: "9.8px",
                      lineHeight: "14px",
                      letter: "0.11px",
                      textTransform: "capitalize",
                      py: 1,
                    }}
                    startIcon={
                      <Box
                        component="img"
                        src="/assets/image/createimage.svg"
                        alt="icon"
                        sx={{ width: "12px", height: "12px", ml: 1 }}
                      />
                    }
                  >
                    Image Enhancer
                  </Button>
                  <Button
                    onClick={handleShare}
                    sx={{
                      bgcolor: "#29272C !important",
                      color: "#989494",
                      borderRadius: "10px",
                      fontWeight: "500",
                      fontSize: "9.8px",
                      lineHeight: "14px",
                      letter: "0.11px",
                      ml: 2,
                      textTransform: "capitalize",
                      py: 1,
                    }}
                    startIcon={
                      <Box
                        component="img"
                        src="/assets/image/createshare.svg"
                        alt="icon"
                        sx={{ width: "12px", height: "12px", ml: 0.5 }}
                      />
                    }
                  >
                    Share
                  </Button>
                </Box>
                <Box sx={{ mt: 2 }}>
                <DownloadButton imageSrc={imageSrc} />
                </Box>
              </Box>
            </Grid>
          </Grid>
          <Box sx={{ mt: 6, ml: 15 }}>
            <Button
              variant="outlined"
              sx={{
                borderRadius: "20px",
                textTransform: "capitalize",
                backgroundColor: "transparent !important",
                color: "#D5C9D5",
                border: "1px solid #D5C9D5!important",
              }}
            >
              Choose from library
            </Button>
            <Button
              variant="contained"
              sx={{
                borderRadius: "20px",
                textTransform: "capitalize",
                backgroundColor: "#A217A3 !important",
                color: "#D5C9D5",
                ml: 2,
                px: 10,
              }}
            >
              Next
            </Button>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

export default Createfashionliveserver;
