import React from 'react';
import { Box, Typography, Slider } from '@mui/material';

const FilterSliders = ({ filterValues, handleFilterChange }) => {
  return (
    <Box sx={{ mt: 2 }}>
      <Typography sx={{ color: 'red' }}>Grayscale</Typography>
      <Slider
        value={filterValues.grayscale}
        min={0}
        max={100}
        onChange={(e, newValue) => handleFilterChange('grayscale', newValue)}
      />

      <Typography sx={{ color: 'red' }}>Sepia</Typography>
      <Slider
        value={filterValues.sepia}
        min={0}
        max={100}
        onChange={(e, newValue) => handleFilterChange('sepia', newValue)}
      />

      <Typography sx={{ color: 'red' }}>Brightness</Typography>
      <Slider
        value={filterValues.brightness}
        min={0}
        max={200}
        onChange={(e, newValue) => handleFilterChange('brightness', newValue)}
      />

      <Typography sx={{ color: 'red' }}>Contrast</Typography>
      <Slider
        value={filterValues.contrast}
        min={0}
        max={200}
        onChange={(e, newValue) => handleFilterChange('contrast', newValue)}
      />
    </Box>
  );
};

export default FilterSliders;
