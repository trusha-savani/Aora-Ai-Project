import React from 'react';
import { Button, Box } from '@mui/material';
import handleDownloadImage from '../Utils/handleDownloadImage';

const DownloadButton = ({ imageSrc }) => {
  return (
    <Button 
      onClick={() => handleDownloadImage(imageSrc)}
      sx={{ 
        bgcolor: '#29272C !important',
        color: '#989494',
        borderRadius: "10px",
        fontWeight: '500',
        fontSize: '9.8px',
        lineHeight: "14px",
        textTransform: 'capitalize',
        py: 1 
      }}
      startIcon={
        <Box 
          component="img"  
          src="/assets/image/createdownload.svg" 
          alt="icon"  
          sx={{ width: '12px', height: '12px', ml: 1 }} 
        />
      }
    >
      Download image
    </Button>
  );
};

export default DownloadButton;
