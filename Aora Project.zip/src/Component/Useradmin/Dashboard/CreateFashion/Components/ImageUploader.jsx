import React ,{ useState } from 'react';
import { Box, Typography, Slider, Button, Dialog, DialogContent, DialogTitle, IconButton } from '@mui/material';
import handleImageUpload from '../Utils/handleImageUpload';
import CloseIcon from '@mui/icons-material/Close';

const ImageUploader = ({ imageSrc, setImageSrc, isBackgroundRemoved }) => {
  const [filterValues, setFilterValues] = useState({
    grayscale: 0,
    sepia: 0,
    brightness: 100,
    contrast: 100,
  });
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleFilterChange = (filter, value) => {
    setFilterValues((prev) => ({
      ...prev,
      [filter]: value,
    }));
  };

  const handleOpenDialog = () => {
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
  };

  return (
    <Box>
      <Box sx={{ 
        width: '468px', 
        height: '300px', 
        border: '1px solid #D5C9D5', 
        backgroundColor: '#0F0D10', 
        borderRadius: '20px', 
        mt: 5, 
        display: 'flex', 
        justifyContent: 'center',
        alignItems: 'center', 
        gap: '10px', 
        cursor: 'pointer'
      }} 
      onClick={() => document.getElementById('imageUploadInput').click()}
      >
        {imageSrc ? (
          <img 
            src={imageSrc} 
            alt="Uploaded" 
            style={{ 
              maxHeight: '100%', 
              borderRadius: '20px',
              filter: `grayscale(${filterValues.grayscale}%) sepia(${filterValues.sepia}%) brightness(${filterValues.brightness}%) contrast(${filterValues.contrast}%)`, 
              backgroundImage: isBackgroundRemoved ? 'none' : 'inherit',
            }} 
          />
        ) : (
          <>
            <img 
              src="/assets/image/creategalley2.svg" 
              alt="" 
              style={{ 
                width: '20px',
                mixBlendMode: isBackgroundRemoved ? 'multiply' : 'none',
              }} 
            />
            <Typography 
              sx={{ 
                fontWeight: '600', 
                fontSize: '20px', 
                lineHeight: '18px',
                letterSpacing: '0.15px', 
                color: '#D5C9D5' 
              }}
            >
              Click to upload a photo
            </Typography>
          </>
        )}
        <input 
          id="imageUploadInput" 
          type="file" 
          accept="image/*" 
          style={{ display: 'none' }} 
          onChange={(event) => handleImageUpload(event, setImageSrc)}
        />
      </Box>

      <Button
        sx={{
          bgcolor: "#29272C !important",
          color: "#989494",
          borderRadius: "10px",
          fontWeight: "500",
          fontSize: "9.8px",
          lineHeight: "14px",
          textTransform: "capitalize",
          mt: 2,
        }}
        startIcon={
          <Box
            component="img"
            src="/assets/image/createchange.svg"
            alt="icon"
            sx={{ width: "20px", height: "20px"  }}
          />
        }
        onClick={handleOpenDialog}
      >
         Image Enhancer
      </Button>

      {/* Dialog positioned on the side */}
      <Dialog
        open={isDialogOpen}
        onClose={handleCloseDialog}
        PaperProps={{
          sx: {
            position: 'absolute',
            right: 0, 
            top: 400, 
            width: '300px', 
            height: '40%', 
            borderRadius: '10px', 
          },
        }}
      >
        <DialogTitle>
          Adjust Image Filters
          <IconButton
            aria-label="close"
            onClick={handleCloseDialog}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <Typography sx={{color:'black'}}>Grayscale</Typography>
            <Slider
              value={filterValues.grayscale}
              min={0}
              max={100}
             
              onChange={(e, newValue) => handleFilterChange('grayscale', newValue)}
              sx={{
                color: 'blue', 
                '& .MuiSlider-thumb': {
                  backgroundColor: 'blue', 
                },
                '& .MuiSlider-track': {
                  backgroundColor: 'blue', 
                },
                '& .MuiSlider-rail': {
                  backgroundColor: 'lightblue',
                }
              }}
            />

            <Typography sx={{color:'black'}}>Sepia</Typography>
            <Slider
              value={filterValues.sepia}
              min={0}
              max={100}
              onChange={(e, newValue) => handleFilterChange('sepia', newValue)}
              sx={{
                color: 'blue', 
                '& .MuiSlider-thumb': {
                  backgroundColor: 'blue',
                },
                '& .MuiSlider-track': {
                  backgroundColor: 'blue', 
                },
                '& .MuiSlider-rail': {
                  backgroundColor: 'lightblue', 
                }
              }}
            />

            <Typography sx={{color:'black'}}>Brightness</Typography>
            <Slider
              value={filterValues.brightness}
              min={0}
              max={200}
              onChange={(e, newValue) => handleFilterChange('brightness', newValue)}
              sx={{
                color: 'blue', 
                '& .MuiSlider-thumb': {
                  backgroundColor: 'blue', 
                },
                '& .MuiSlider-track': {
                  backgroundColor: 'blue', 
                },
                '& .MuiSlider-rail': {
                  backgroundColor: 'lightblue', 
                }
              }}
            />

            <Typography sx={{color:'black'}}>Contrast</Typography>
            <Slider
              value={filterValues.contrast}
              min={0}
              max={200}
              onChange={(e, newValue) => handleFilterChange('contrast', newValue)}
              sx={{
                color: 'blue', 
                '& .MuiSlider-thumb': {
                  backgroundColor: 'blue', 
                },
                '& .MuiSlider-track': {
                  backgroundColor: 'blue', 
                },
                '& .MuiSlider-rail': {
                  backgroundColor: 'lightblue', 
                }
              }}
            />
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default ImageUploader;


