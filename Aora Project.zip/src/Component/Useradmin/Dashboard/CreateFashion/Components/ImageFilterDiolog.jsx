import React from 'react';
import { Dialog, DialogContent, DialogTitle, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import FilterSliders from './FilterSlider';


const ImageFiltersDialog = ({ isDialogOpen, handleCloseDialog, filterValues, handleFilterChange }) => {
  return (
    <Dialog open={isDialogOpen} onClose={handleCloseDialog}>
      <DialogTitle>
        Adjust Image Filters
        <IconButton
          aria-label="close"
          onClick={handleCloseDialog}
          sx={{
            position: 'absolute',
            right: 150,
            top: 100,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        {/* Use the FilterSliders component here */}
        <FilterSliders
          filterValues={filterValues} 
          handleFilterChange={handleFilterChange} 
        />
      </DialogContent>
    </Dialog>
  );
};

export default ImageFiltersDialog;
