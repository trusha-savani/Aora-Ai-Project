import {Box,Typography,Tabs} from "@mui/material";
import React, { useState } from "react";
import Aside from "../../Aside";
import Tab from "@mui/material/Tab";
import Createfashionliveserver from "./Createfashionliveserver";

function Marketplace() {
  const [value, setValue] = useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

return (
    <Box>
      <Box sx={{ bgcolor: "#171319", width: "100%", display: "flex", gap: "12px",p: "12px "}}>
        <Box sx={{ position: "sticky", top: "12px", height: `calc(100vh - 24px)` }}>
          <Aside />
        </Box>
        <Box sx={{ width: "100%" }}>
          
            <Box sx={{ width: { xl: "100%", md: "100%", sm: "100%" }, height: "104px", bgcolor: "#0F0D10", borderRadius: "20px 20px 0px 0px", p: "24px", display: "flex",
                justifyContent: "space-between", alignItems: "center   "}} >
              <Box>
                <Typography sx={{ color: "white", fontWeight: "700",fontSize:'20px',lineHeight:'32px' }} className="Jakarta"> Create Fashion </Typography>
                <Typography sx={{ color: "#D5C9D5", fontWeight: "500" }} className="Jakarta"> Lorem Ipsum set dolor. cavet nun pils</Typography>
              </Box>
              <Box>
               <img src="assets/image/Actions.png" alt="" />
              </Box>
            </Box>
        <Box className=" w-full flex flex-col gap-[16px]">
            <Box sx={{ width: "100%", bgcolor: "#0F0D10",borderRadius: "0px 0px 20px 20px", p:"8px",display: "flex",justifyContent: "space-between", alignItems: "end"}}>
              <Tabs value={value} onChange={handleChange} aria-label="Industry Tabs" TabIndicatorProps={{
                  style: { backgroundColor: "transparent", display: "flex",justifyContent: "center"},
                  children: (
                    <span style={{ maxWidth: 112, width: "100%", backgroundColor: "#A217A3", height: "4px", borderRadius: "4px"}}/> ),}}
              >
                <Tab label={
                    <div style={{ display: "flex", alignItems: "center" }}>
                      <img src="/assets/image/creategalley.svg" alt="icon" style={{ marginRight: "15px" }}/>
                      Live services
                    </div>
                  }
                  sx={{ padding: "20px", color: "#fff!important",textTransform: "capitalize", fontWeight: "600",fontSize: "14px",lineHeight: "20px", alignItems: "center",
                    letterSpacing: "0.15px"}}
                    />
                     <Tab label={
                    <div style={{ display: "flex", alignItems: "center" }}>
                      <img src="/assets/image/createfile.svg" alt="icon" style={{ marginRight: "15px" }}/>
                      Custom Library
                    </div>
                  }
                  sx={{ padding: "20px", color: "#fff!important",textTransform: "capitalize", fontWeight: "600",fontSize: "14px",lineHeight: "20px", alignItems: "center",
                    letterSpacing: "0.15px"}}
                    />
                     <Tab label={
                    <div style={{ display: "flex", alignItems: "center" }}>
                      <img src="/assets/image/createfile.svg" alt="icon" style={{ marginRight: "15px" }}/>
                      Design Book
                    </div>
                  }
                  sx={{ padding: "20px", color: "#fff!important",textTransform: "capitalize", fontWeight: "600",fontSize: "14px",lineHeight: "20px", alignItems: "center",
                    letterSpacing: "0.15px"}}
                    />
              </Tabs>
            </Box>
            <Box sx={{ p: "2px", borderRadius: '10px', }}>
            {value === 0 &&  <Createfashionliveserver /> }
            {value === 1 && <div>Prediction Models Content</div>}
          </Box>
          </Box>

          
     

     


      
        </Box>
      </Box>
    </Box>
  );
}

export default Marketplace;

