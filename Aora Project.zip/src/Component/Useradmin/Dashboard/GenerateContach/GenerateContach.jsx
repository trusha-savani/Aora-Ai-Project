
import { Box, Typography, Tabs, Tab } from '@mui/material'
import React, { useState } from 'react';
import Button from '@mui/material/Button';
import Aside from '../../Aside';



function GenerateContach() {
  const [value, setValue] = useState(0);
  const [newMessage, setNewMessage] = useState('');

 
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const [messages, setMessages] = useState([
    { text: 'Hello!', senderId: '1', time: '10:00 AM' },
    { text: 'Hi! How are you?', senderId: '2', time: '10:01 AM' },
    { text: 'I am working on a project.', senderId: '1', time: '10:02 AM' },
    { text: 'That sounds interesting!', senderId: '2', time: '10:03 AM' },
    { text: 'Need any help?', senderId: '1', time: '10:04 AM' },
  ]);
  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // You (senderId: '1') always sends the message
      setMessages([...messages, { text: newMessage, senderId: '1', time: new Date().toLocaleTimeString() }]);
      setNewMessage(''); // Clear the input field after sending the message
    }
  };
  return (
    <div>
         <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

<Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }} >
    <Aside />
</Box>
<Box sx={{ width: "100%" }}>
    <Box sx={{ pb: "12px" }}>
        <Box sx={{ width: {xl:'100%',md:'100%',sm:'100%'}, height: '104px', bgcolor: "#0F0D10", borderRadius: '20px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center   ' }}>
        <Box>
                <Typography sx={{ color: 'white', fontWeight: '700',fontSize:'20px',lineHeight:'32px' }} className='Jakarta'>Brand Profile  </Typography>
                <Typography sx={{  fontWeight: "500",fontSize:'14px',lineHeight:'20px',letter:"0.15px",color:'#D5C9D5' }} className="Jakarta">Lorem Ipsum sit dolor mat neu et</Typography>
            </Box>
            <Box>
                <img src="assets/image/Actions.png" alt="" />
            </Box>
        </Box>
    </Box>
    <Box className=" w-full flex flex-col gap-[16px]">
        <Box sx={{ width: "100%", bgcolor: "#0F0D10", borderRadius: '10px', p: "20px", display: "flex", justifyContent: 'space-between', alignItems: 'end', }}>
            <Tabs value={value} onChange={handleChange} aria-label="Industry Tabs" TabIndicatorProps={{ style: { backgroundColor: 'transparent',display: 'flex', justifyContent: 'center'},
                children: ( <span style={{ maxWidth: 112, width: '100%', backgroundColor: '#A217A3', height: '4px', borderRadius: '4px',}}
                  />
                ),
              }}
            >
              <Tab  label="Image Generation" sx={{ padding: '20px', color: '#fff!important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'20px',alignItems:'center',letter:'0.15px' }} />
              <Tab label="Text Generation" sx={{ padding: '20px', color: '#fff!important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'20px',alignItems:'center',letter:'0.15px' }}/>
            </Tabs>
        </Box>
        
                                    
    </Box>


    <Box sx={{width:'100%',height:'700px',backgroundColor:"#1C1A1E",mt:2}}>
      <Box sx={{display:'flex',justifyContent:'center',alignItems:'center',gap:4,padding:'260px 30px 264px 30px'  }}>
        <Box sx={{width:'181px',height:'113px',border:'1px solid #D5C9D5',borderRadius:'10px',ml:2}}>
          <Button sx={{width:'400',fontSize:'14px',lineHeight:'22px',letter:'0.15px',color:'#D5C9D5',padding:'20px ',mt:2,textTransform:'none' }}>
          Generate images with AI prompts
          </Button>
            {/* <Typography sx={{width:'400',fontSize:'14px',lineHeight:'22px',letter:'0.15px',color:'#D5C9D5',padding:'20px ',mt:2 }}>Generate images with AI prompts</Typography> */}
        </Box>
         <Box sx={{width:'181px',height:'113px',border:'1px solid #D5C9D5',borderRadius:'10px'}}>
         <Typography sx={{width:'400',fontSize:'14px',lineHeight:'22px',letter:'0.15px',color:'#D5C9D5',padding:'20px',mt:2}}>Generate Instagram 
contents for brand</Typography>
         </Box>
          <Box sx={{width:'181px',height:'113px',border:'1px solid #D5C9D5',borderRadius:'10px'}}>
          <Typography sx={{width:'400',fontSize:'14px',lineHeight:'22px',letter:'0.15px',color:'#D5C9D5',padding:'20px',mt:2}}>Generate Facebook 
contents for brand</Typography>
          </Box>
          <Box sx={{width:'181px',height:'113px',border:'1px solid #D5C9D5',borderRadius:'10px'}}>
          <Typography sx={{width:'400',fontSize:'14px',lineHeight:'22px',letter:'0.15px',color:'#D5C9D5',padding:'20px',mt:2}}>Generate images with
AI prompts</Typography>
          </Box>
            
        
      </Box>
    


        <Box sx={{width:'100%',bgcolor:'#0D0F10',borderRadius:'10px'}}>
     
            <Box sx={{width:'100%',display:'flex',justifyContent:'center',padding:'0px 10px'}}>

             
             <input type="text" sx={{width:'100% !important'}}   style={{
          width: '100%', 
          padding: '20px', 
          backgroundColor: '#0D0F10', 
          paddingRight: '40px' // Space for the image
        }}  placeholder='You can ask me anything! I am here to help.'className="full-width-input"  /> 
             <Box sx={{display:'flex'}}>
                <img src='/assets/image/attechment.svg' alt='...' />
                <Button onClick={handleSendMessage}><img src='/assets/image/sendicon.svg' style={{width:'30px',color:'red',marginRight:"20px"}}  alt='...' /></Button>
            </Box> 
           </Box> 
             </Box> 

            
      </Box>    
    
    </Box>

</Box>

    </div>
  )
}

export default GenerateContach
