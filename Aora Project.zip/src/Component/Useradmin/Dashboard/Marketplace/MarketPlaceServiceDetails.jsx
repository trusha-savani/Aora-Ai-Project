import { Typography,Box, Divider } from '@mui/material'
import React, { useState } from 'react';
import Tab from '@mui/material/Tab';
import Grid from '@mui/material/Grid';
import Tabs from '@mui/material/Tabs';
import Button from '@mui/material/Button';
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import Marketdiolog from '../../../../dialogs/Marketdiolog';
function MarketPlaceServiceDetails() {
  const [value, setValue] = useState(0);
  const [order, setOrder] = useState(false);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleOrderOption = () => {
    setOrder(!order);
    console.log("Option Is ",order);
    
  };

  return (
    <div>
       <Box sx={{  width: '100%', display: 'flex', gap: "12px", p: "12px " }} >
       <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={9}>
          <Box>
            <Typography sx={{fontWeight:'800',fontSize:'24px',lineHeight:'30.24px',color:'#1C1C1C'}}>You will get a modern design or professional edit of Pitch Deck slide</Typography>
            <Box sx={{width:'95%',height:'287px',background:'#D9D9D9',mt:2}}>

            </Box>
            <Typography sx={{fontWeight:'600',fontSize:'20px',lineHeight:"25.2px",mt:2,color:'#1C1C1C'}}>About this service</Typography>
            

            <Typography sx={{mt:3,fontWeight:'400',fontSize:'16px',lineHeight:'25px',color:'#1C1C1C'}}>Hi,</Typography>
            <Typography sx={{mt:3,fontWeight:'400',fontSize:'16px',lineHeight:'25px',color:'#1C1C1C'}}>In today's world, an online presence is  indispensable for business survival. It widens market reach, boosts  brand visibility, enables customer interaction, and empowers businesses  to stay competitive and relevant.</Typography>
            <Typography sx={{mt:3,fontWeight:'400',fontSize:'16px',lineHeight:'25px',color:'#1C1C1C'}}>With years of  experience in Wix web design and a passion for creativity, I </Typography>
            
      
          </Box>
        </Grid>
        <Grid item xs={3}>
          <Box sx={{border:'1px solid #D9D9D9',width:"90%"}}>
          <Box sx={{ width: '100%', height: '70px', mt: '-10px',backgroundColor:'#F6F4F4' }}>
            <Tabs
              value={value}
              onChange={handleChange}
              aria-label="Industry Tabs"
              sx={{backgroundColor:'#F6F4F4',mt:1.2,ml:2}}
              TabIndicatorProps={{
                style: {
                  backgroundColor: 'transparent',
                  display: 'flex',
                  ml:4,
                  justifyContent: 'center',
                },
                children: (
                  <span
                    style={{
                      maxWidth: 112,
                      width: '100%',
                      backgroundColor: '#1C1C1C',
                      height: '4px',
                     
                      borderRadius: '4px',
                    }}
                  />
                ),
              }}
            >
            

              <Tab label="Basic" sx={{ padding: '10px', color: '#1C1C1C !important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'17.64px',alignItems:'center',letter:'0.15px' ,mt:1.2         }} />
              <Divider orientation="vertical" flexItem  sx={{mt:1}}/>
              <Tab label="Standard" sx={{ padding: '20px', color: '#1C1C1C !important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'17.64px',alignItems:'center',letter:'0.15px' ,mt:1.2  }} />
              <Divider orientation="vertical" flexItem  sx={{mt:1}}/>
              <Tab label="Premium" sx={{ padding: '20px', color: '#1C1C1C !important',textTransform:'capitalize',fontWeight:'600',fontSize:'14px',lineHeight:'17.64px',alignItems:'center',letter:'0.15px' ,mt:1.2  }}/>
           

            </Tabs>
          </Box>
          <Box sx={{display:'flex',justifyContent:'space-between',p:2}}>
            <Typography sx={{fontWeight:'600',fontSize:'14px',lineHeight:'17.64px',color:'#1C1C1C'}}>Professional Wix Website</Typography>
            <Typography sx={{fontWeight:'500',fontSize:'18px',lineHeight:'22.68px',color:'#1C1C1C'}}>280CR</Typography>
          </Box>
          <Box sx={{padding:"0px 15px 15px 15px"}}>
            <Typography sx={{fontWeight:'400',fontSize:'14px',lineHeight:'17.64px',color:'#1C1C1C'}}>Upto 4 Pages Wix Website Design / Redesign -Mobile Responsive + Stock Images + SEO</Typography>
          </Box>
          <Box sx={{display:'flex',alignItems:'center',padding:"0px 15px 15px 15px"}}>
            <img src="/assets/image/clock.svg" alt="" />
            <Typography sx={{fontWeight:'600',fontSize:'14px',lineHeight:'17.64px',color:'#1C1C1C'}}>X day delivery</Typography>
            <Typography  sx={{fontWeight:'600',fontSize:'14px',lineHeight:'17.64px',color:'#1C1C1C',ml:4}}>X no. of revisions</Typography>
          </Box>
          <Box sx={{display:'flex',padding:'0px 15px 0px 15px'}}>
       <img src="/assets/image/true.svg" alt="" />
       <Typography sx={{ml:1,fontWeight:'400',fontSize:'14px',lineHeight:'20px',color:'#1C1C1C'}}>20 pages</Typography>
          </Box>
          <Box sx={{display:'flex',padding:'0px 0px 0px 15px'}}>
       <img src="/assets/image/true.svg" alt="" />
       <Typography sx={{ml:1,fontWeight:'400',fontSize:'14px',lineHeight:'20px',color:'#1C1C1C'}}>1 custom asset</Typography>
          </Box>
          <Box sx={{display:'flex',padding:'0px 0px 0px 15px'}}>
       <img src="/assets/image/true.svg" alt="" />
       <Typography sx={{ml:1,fontWeight:'400',fontSize:'14px',lineHeight:'20px',color:'#1C1C1C'}}>Responsive design</Typography>
          </Box>
          <Box sx={{display:'flex',padding:'0px 0px 0px 15px'}}>
       <img src="/assets/image/true.svg" alt="" />
       <Typography sx={{ml:1,fontWeight:'400',fontSize:'14px',lineHeight:'20px',color:'#1C1C1C'}}>Content upload</Typography>
          </Box>
          <Box sx={{display:'flex',justifyContent:'center',mt:5}}>
          <Button
  sx={{
    backgroundColor: '#989494 !important',
    pl: 10,
    pr: 10, 
    borderRadius: '20px',
    color: '#fff !important',
    textTransform: 'capitalize',
    textAlign: 'center',
    m:2.5,
    width: "100%",
    position: 'relative', 
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  }}
  onClick={handleOrderOption}
>
  Continue
  <ArrowRightAltIcon
    sx={{
      position: 'absolute',
      right: 27,
    }}
  />
</Button>


          </Box>
          <Typography sx={{fontWeight:'600',fontSize:'14px',lineHeight:'18px',color:'#989494',textAlign:'center',letter:'0.15px',m:2}}>Compare Tiers</Typography>
          
          </Box>
        </Grid>
        
      </Grid>
    </Box>

<Marketdiolog isOpen={order} handleClick={handleOrderOption}  />
    
         </Box>
    </div>
  )
}

export default MarketPlaceServiceDetails

