import {
  Box,
  Typography,
  Stack,
  Tabs,
  CircularProgress,
  LinearProgress,
} from "@mui/material";
import React, { useState, useEffect } from "react";
import Aside from "../../Aside";
import { useHistory } from "react-router-dom";
import Skeleton from "@mui/material/Skeleton";
import SearchIcon from "@mui/icons-material/Search";
import Tab from "@mui/material/Tab";
import Grid from "@mui/material/Grid";
import MarketPlaceServiceDetails from "./MarketPlaceServiceDetails";
import MarketplaceCardView from "./MarketplaceCardView";


const menu = [
  "All Services",
  "Power Point",
  "Social Media Management",
  "Unique Fabric Design",
  "Trademark Registration",
  "Custom Product Design",
];

function Marketplace() {
  const [value, setValue] = useState(0);
  const [loaded, setLoaded] = React.useState(false);
  const [items, setItems] = useState([]);
  const [fetchData, setFetchData] = useState(true);
  const [menuId, setMenuId] = useState(0);
  const [isServiceVisible, setIsServiceVisible] = useState(false);

  const handleToggle = () => {
    
    setIsServiceVisible(!isServiceVisible);
  };

  const handleMenu = (index) => {
    setMenuId(index);
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  let history = useHistory()

  useEffect(() => {
    setTimeout(() => {
      setItems([
        {
          img: "/assets/image/login.png",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "$10.00",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        {
          img: "path/to/image2.jpg",
          title: "Title of service",
          description: "Lorem Ipsum description of service",
          price: "From $20",
        },
        
        
        
      ]);
      setFetchData(false);
      setLoaded(true);
    }, 2000);
  }, []);

  

  return (
    <Box>
      <Box
        sx={{
          bgcolor: "#ffffff",
          width: "100%",
          display: "flex",
          gap: "12px",
          p: "12px ",
        }}
      >
        <Box
          sx={{ position: "sticky", top: "12px", height: `calc(100vh - 24px)` }}
        >
          <Aside />
        </Box>
        <Box sx={{ width: "100%" }}>
          <Box>
            <Box
              sx={{
                width: { xl: "100%", md: "100%", sm: "100%" },
                height: "104px",
                bgcolor: "#0F0D10",
                borderRadius: "20px 20px 0px 0px",
                p: "24px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center   ",
              }}
            >
              <Box>
                <Typography
                  sx={{ color: "white", fontWeight: "700" }}
                  className="Jakarta"
                >
                  Marketplace{" "}
                </Typography>
                <Typography
                  sx={{ color: "#D5C9D5", fontWeight: "500" }}
                  className="Jakarta"
                >
                  Lorem Ipsum set dolor. cavet nun pils{" "}
                </Typography>
              </Box>
              <Box>
                <img src="assets/image/Actions.png" alt="" />
              </Box>
            </Box>
          </Box>

          <Box className=" w-full flex flex-col gap-[16px]">
            <Box
              sx={{
                width: "100%",
                bgcolor: "#0F0D10",
                borderRadius: "0px 0px 20px 20px",
                p: "8px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "end",
              }}
            >
              <Tabs
                value={value}
                onChange={handleChange}
                aria-label="Industry Tabs"
                TabIndicatorProps={{
                  style: {
                    backgroundColor: "transparent",
                    display: "flex",
                    justifyContent: "center",
                  },
                  children: (
                    <span
                      style={{
                        maxWidth: 112,
                        width: "100%",
                        backgroundColor: "#A217A3",
                        height: "4px",
                        borderRadius: "4px",
                      }}
                    />
                  ),
                }}
              >
                <Tab
                  label={
                    <div style={{ display: "flex", alignItems: "center" }}>
                      <img
                        src="/assets/image/liveserver.svg"
                        alt="icon"
                        style={{ marginRight: "15px" }}
                      />
                      Live services
                    </div>
                  }
                  sx={{
                    padding: "20px",
                    color: "#fff!important",
                    textTransform: "capitalize",
                    fontWeight: "600",
                    fontSize: "14px",
                    lineHeight: "20px",
                    alignItems: "center",
                    letterSpacing: "0.15px",
                  }}
                />
              </Tabs>
            </Box>
          </Box>

          <Box sx={{ width: "100%", mt: 2 }}>
            <Box>
              <SearchIcon
                style={{ position: "absolute", left: "30%", color: "black" }}
              />
              <input
                type="text"
                style={{
                  width: "50%",
                  display: "flex",
                  marginLeft: "400px",
                  borderRadius: "20px",
                  height: "50px",
                  padding: "20px",
                  border: "1px solid #3A3A43",
                  fontSize: "16px",
                }}
                placeholder="What service are you looking for today?"
              />
            </Box>
          </Box>
          <Box>
            <Box className="p-6 "></Box>

            {/* <h1 color='red'>gjkldfjbndlk</h1> */}
            <Box sx={{ display: "flex", gap: "30px", ml: "20px" }}>
              {menu.map((item, index) => (
                <div onClick={() => handleMenu(index)}>
                  <Typography
                    key={index}
                    sx={{
                      fontSize: "16px",
                      fontWeight: "700",
                      lineHeight: "20px",
                      color: menuId === index ? "#A217A3" : "black",
                      "&:hover": {
                        color: "#A217A3",
                      },
                      marginBottom: "10px",
                    }}
                    onClick={handleToggle}
                  >
                    {item}
                  </Typography>
                </div>
              ))}
            </Box>
          </Box>

          <Box sx={{ display: "flex", alignItems: "center" }}>
  <img
    src="/assets/image/home.svg"
    alt=""
    style={{ marginRight: "10px" }}
  />
  {menuId !== 0 && (  // Conditionally render Typography only when menuId is not 0
    <Typography
      sx={{
        color: "#686B6E",
        fontWeight: "400",
        fontSize: "14px",
        letterSpacing: "0.15px",
      }}
      className="Jakarta"
      onClick={handleToggle}
    >
      /{menu[menuId]}
    </Typography>
  )}
</Box>


          <Box>
            {fetchData ? (
              <LinearProgress color="secondary" />
            ) : (
              <Box>
                <Typography
                  sx={{ fontWeight: "600", fontSize: "24px", color: "#989494",mt:4 }}
                >
                  Recent
                </Typography>
                {
                  isServiceVisible ? (
                    <MarketPlaceServiceDetails />
                  ) : (
                    <Grid container spacing={2}>
                      {items.map((item, index) => (
                        <Grid item key={index}>
                          <MarketplaceCardView
                            img={item.img}
                            title={item.title}
                            description={item.description}
                            price={item.price}
                            onClick={() => handleToggle()}
                          />
                        </Grid>
                      ))}
                    </Grid>
                  )
                }
                {/* <Typography
                    sx={{
                      fontWeight: "600",
                      fontSize: "24px",
                      color: "#989494",
                    }}
                  >
                    Services you may like
                  </Typography> */}

                  {/* {
                  isServiceVisible ? (
                    <MarketPlaceServiceDetails />
                  ) : (
                    <Grid container spacing={2}>
                      {items.map((item, index) => (
                        <Grid item key={index}>
                          <MarketplaceCardView
                            img={item.img}
                            title={item.title}
                            description={item.description}
                            price={item.price}
                            onClick={() => handleToggle()}
                          />
                        </Grid>
                      ))}
                    </Grid>
                  )
                } */}
                  {/* <Typography
                    sx={{
                      fontWeight: "600",
                      fontSize: "24px",
                      color: "#989494",
                    }}
                  >
                    Most popular Services
                  </Typography> */}
                  {/* {
                  isServiceVisible ? (
                    <MarketPlaceServiceDetails />
                  ) : (
                    <Grid container spacing={2}>
                      {items.map((item, index) => (
                        <Grid item key={index}>
                          <MarketplaceCardView
                            img={item.img}
                            title={item.title}
                            description={item.description}
                            price={item.price}
                            onClick={() => handleToggle()}
                          />
                        </Grid>
                      ))}
                    </Grid>
                  )
                } */}
              </Box>
            )}
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

export default Marketplace;
