import { Box, Typography, Grid} from '@mui/material'
import React from 'react';
import Skeleton from '@mui/material/Skeleton';

function MarketplaceCardView({img,title,description,price,onClick}) {

  const [loaded, setLoaded] = React.useState(false);



  return (


    <Box>
      <Box sx={{ bgcolor: '#ffffff', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

        
        <Box sx={{ width: "100%" }}>
          <Box >

           
                  <Box>
                    <Box sx={{ padding: '5px', mt: 2 }}>
                      


                      <Box sx={{ flexGrow: 1 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={12}>
                            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
                            <Box sx={{ width: '200px', textAlign: 'center'}} onClick={() => onClick()}>
                                  <Box sx={{ width: '100%', height: '121px', borderRadius: '15px', position: 'relative', overflow: 'hidden' }} >
                                    {!loaded && (<Skeleton variant="rectangular" width="100%" height="121px" sx={{ backgroundColor: 'grey', borderRadius: '15px' }} />
                                    )}
                                    <img src={img} alt={title} style={{
                                      width: '100%', height: '121px', borderRadius: '15px', objectFit: 'cover', visibility: loaded ? 'visible' : 'hidden',
                                      position: 'absolute', top: 0, left: 0,
                                    }} onLoad={() => setLoaded(false)} /></Box>
                                  <Typography sx={{ fontWeight: '600', fontSize: '14px', textAlign: 'start', color: '#29272C', lineHeight: '17.64px', mt: 2 }}>
                                    {title}
                                  </Typography>
                                  <Typography sx={{ fontSize: '16px', color: 'gray', mt: '4px', textAlign: 'start', fontWeight: '400', lineHeight: '20.16px' }}>
                                  {description}
                                  </Typography>
                                  <Typography sx={{ fontWeight: '600', fontSize: '14px', color: '#29272C', lineHeight: '17.64px', textAlign: 'start', mt: 2 }}>
                                  {price}
                                  </Typography>
                                </Box>
                            </Box>
                          </Grid>


                        </Grid>
                      </Box>
                    </Box>

                  </Box>
             

             


              
          </Box> 
        </Box>
      </Box>
    </Box>
  )
}

export default MarketplaceCardView
