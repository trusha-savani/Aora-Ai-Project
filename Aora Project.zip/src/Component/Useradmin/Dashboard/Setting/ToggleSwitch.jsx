import React from 'react';
import { Box } from '@mui/material';

const ToggleSwitch = ({isChecked,handleChange,id}) => {
  
   
  return (
    <Box className="switch-toggle" sx={{mr:2}}>
      <input
        type="checkbox"
        checked={isChecked}
        onChange={handleChange}
        id={id}
      />
      <label htmlFor={id} className={isChecked ? 'active' : ''}>
        <span className="toggle-handle"></span>
      </label>
    </Box>
  )
}

export default ToggleSwitch
