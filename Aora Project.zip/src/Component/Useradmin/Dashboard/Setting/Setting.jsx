import { Box, Typography, Tabs, Tab} from "@mui/material";
import React, { useState } from "react";

import Aside from "../../Aside";

import SettingProfile from "./SettingProfile";
import SettingNotification from "./SettingNotification";
import SettingBilling from "./SettingBilling";
import SettingIntergration from "./SettingIntergration";

function Setting() {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  
  return (
     <Box sx={{bgcolor: "#171319",width: "100%",display: "flex",gap: "12px",p: "12px ",}}>
        <Box sx={{ position: "sticky", top: "12px", height: `calc(100vh - 24px)` }}>
          <Aside />
        </Box>
        <Box sx={{ width: "100%",height:'104px' }}>
          <Box >
            <Box sx={{width: {xl: "100%",md: "100%",sm: "100%" },height:"104px",bgcolor:"#0F0D10",borderRadius:"20px 20px 0px 0px",p:"24px",display:"flex",justifyContent:"space-between",alignItems: "center",}}>
              <Box>
                <Typography sx={{ color: "white", fontWeight: "700",fontSize:'20px',lineHeight:'32px' }} className="Jakarta">Settings</Typography>
                <Typography sx={{  fontWeight: "500",fontSize:'14px',lineHeight:'20px',letter:"0.15px",color:'#D5C9D5' }} className="Jakarta">Lorem Ipsum sit dolor mat neu et</Typography>
              </Box>
              <Box><img src="assets/image/Actions.png" alt="" /></Box>
            </Box>
          </Box>
          <Box className=" w-full flex flex-col gap-[16px]">
            <Box sx={{width: "100%",bgcolor: "#0F0D10",borderRadius: "0px 0px 20px 20px",p: "20px",display: "flex",justifyContent: "space-between",alignItems: "end",mt:0.2}}>
              <Tabs value={value} onChange={handleChange} aria-label="Industry Tabs" TabIndicatorProps={{ style: { backgroundColor: "transparent", display: "flex", justifyContent: "center",},
                  children: ( <span style={{ maxWidth: 112, width: "100%",backgroundColor: "#A217A3",height: "4px",borderRadius: "0px 0px 20px 20px"}}/> ),
                }}>
                <Tab label="Profile" sx={{ padding:"20px",color: "#fff!important",textTransform:"capitalize",fontWeight: "600",fontSize: "14px", lineHeight: "20px",
                    alignItems: "center",letter: "0.15px"}}/>
                <Tab label="Notifications" sx={{ padding:"20px",color: "#fff!important", textTransform: "capitalize",fontWeight: "600", fontSize: "14px",lineHeight: "20px",
                alignItems: "center",letter: "0.15px"}}/>
                <Tab label="Billing" sx={{ padding: "20px", color: "#fff!important", textTransform: "capitalize", fontWeight: "600", fontSize: "14px", lineHeight: "20px",
                alignItems: "center", letter: "0.15px"}}/>
                <Tab label="API Integration"sx={{ padding: "20px", color: "#fff!important", textTransform: "capitalize", fontWeight: "600", fontSize: "14px", 
                lineHeight: "20px", alignItems: "center",letter: "0.15px" }}/>
              </Tabs>
            </Box>
            <Box sx={{  borderRadius: '10px', mt: 0.5 }}>
            {value === 0 &&  <SettingProfile /> }
            {value === 1 &&  <SettingNotification />}
            {value === 2 &&  <SettingBilling />}
            {value === 3 && <SettingIntergration />}
          </Box>
          </Box>

        
        </Box>
      </Box>
    
  );
}

export default Setting;
