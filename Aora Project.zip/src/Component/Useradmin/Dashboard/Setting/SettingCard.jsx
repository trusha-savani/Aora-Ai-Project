import React, { useState } from 'react';
import { Box, Button, Typography } from '@mui/material';


function SettingCard({ name, tokens, designs, price, color,backgroundColor }) {
  // const [selectedPackage, setSelectedPackage] = useState(null);
  const [open, setOpen] = useState(false);
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };  
  return (
    <Box sx={{ backgroundColor: '#fff',boxShadow: 2, padding: 2, margin: 2, borderRadius: 5, width: 450,textAlign: 'center'}}>
   
      <Typography sx={{ color ,fontsize:'24px',fontWeight:'800',lineHeight:'20px',letter:'0.15px',textAlign:'center',}} variant="h6">
        {name}
      </Typography>
      <Typography sx={{color,fontsize:'16px',fontWeight:'600',lineHeight:'20px',letter:'0.15px',textAlign:'center',mt:1}} variant="subtitle1">+{tokens} tokens</Typography>
      <Typography sx={{ color: '#686B6E',fontsize:'16px',fontWeight:'600',lineHeight:'20px',letter:'0.15px',textAlign:'center',mt:4 }} variant="body1">
        Create {designs} designs
      </Typography>
      <Button variant="contained" sx={{color:'#fff',display:'flex',marginLeft:'140px',marginTop: 4,py:2,borderRadius:'10px',backgroundColor,'&:hover': {backgroundColor: '#00808e',},}}
        onClick={handleClickOpen}
        >
        Add for ${price}.00
      </Button>
  
      <Typography variant="caption" sx={{ color:'#686B6E',fontsize:'14px',fontWeight:'500',lineHeight:'20px',letter:'0.15px',textAlign:'center',mt:1 ,textTransform:'capitalize'}}>
        One time payment
      </Typography>

   
      
    </Box>
  );
}

export default SettingCard;
