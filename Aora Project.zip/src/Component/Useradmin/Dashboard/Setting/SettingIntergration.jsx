import React, {useState }from 'react'
import { Box,Typography } from '@mui/material'
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import ToggleSwitch from './ToggleSwitch';

function SettingIntergration() {
  const [zapierNotification, setzapierNotification] = useState(false);
    const [chatgtpNotification,setChatgtpNotification] = useState(false)
    const [mailchampNotification,setMailchampNotification] = useState(false)


    const handlezapierNotification = () => {
      setzapierNotification(!zapierNotification);
    };
    const handlechatgtpNotification = () => {
      setChatgtpNotification(!chatgtpNotification);
       
      };
      const handlemailchampNotification = () => {
        setMailchampNotification(!mailchampNotification);
      };
  return (
    <Box sx={{padding:'40px'}}>
        <Box>

<Typography  className="Jakarta" sx={{fontWeight:'700',fontSize:'20px',lineHeight:"25.2px",color:'#FFFFFF'}}>Integrations</Typography>
<Typography className="Jakarta" sx={{fontWeight:'500',fontSize:'12px',lineHeight:"20px",color:'#D5C9D5',letter:"0.15px",mt:1}}>Supercharge your workflow and connect tools you and your teams uses every day.</Typography>
</Box>

  <Box sx={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
  <Box sx={{mt:5,display:'flex',alignItems:'center'}} >
    <Box>
    <img src="assets/image/zepair.svg" alt="" />
      </Box>
      <Box sx={{ml:2}}>
        <Typography sx={{fontWeight:'700',fontSize:'16px',lineHeight:'20.16px',color:'#FFFFFF'}}>Zapier <span style={{fontWeight:'500',fontSize:'12px',lineHeight:'20px',color:'#D5C9D5',letter:'0.15px',marginLeft:4}}>zapier.com</span></Typography>
        <Typography>Build custom automation and integration with other apps. </Typography>
        </Box>
  </Box>
  <Box sx={{display:'flex'}} >
    <SettingsOutlinedIcon sx={{fontSize:'20px'}} />
    <Typography sx={{ml:1,fontWeight:'500',fontSize:'12px',lineHeight:'20px',letter:'0.15px',mr:1.5}}>Manage</Typography>
    <ToggleSwitch isChecked={zapierNotification} handleChange={handlezapierNotification} id="zapierNotification" />
  </Box>

    </Box>
    <Box sx={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
  <Box sx={{mt:5,display:'flex',alignItems:'center'}} >
    <Box>
    <img src="assets/image/chatgtp.svg" alt="" />
      </Box>
      <Box sx={{ml:2}}>
        <Typography sx={{fontWeight:'700',fontSize:'16px',lineHeight:'20.16px',color:'#FFFFFF'}}>Zapier <span style={{fontWeight:'500',fontSize:'12px',lineHeight:'20px',color:'#D5C9D5',letter:'0.15px',marginLeft:4}}>zapier.com</span></Typography>
        <Typography>Build custom automation and integration with other apps. </Typography>
        </Box>
  </Box>
  <Box sx={{display:'flex'}} >
    <SettingsOutlinedIcon sx={{fontSize:'20px'}} />
    <Typography sx={{ml:1,fontWeight:'500',fontSize:'12px',lineHeight:'20px',letter:'0.15px',mr:1.5}}>Manage</Typography>
    <ToggleSwitch isChecked={chatgtpNotification} handleChange={handlechatgtpNotification} id="chatgtpNotification" />
  </Box>

    </Box>
    <Box sx={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
  <Box sx={{mt:5,display:'flex',alignItems:'center'}} >
    <Box>
    <img src="assets/image/mailchamp.svg" alt="" />
      </Box>
      <Box sx={{ml:2}}>
        <Typography sx={{fontWeight:'700',fontSize:'16px',lineHeight:'20.16px',color:'#FFFFFF'}}>Zapier <span style={{fontWeight:'500',fontSize:'12px',lineHeight:'20px',color:'#D5C9D5',letter:'0.15px',marginLeft:4}}>zapier.com</span></Typography>
        <Typography>Build custom automation and integration with other apps. </Typography>
        </Box>
  </Box>
  <Box sx={{display:'flex'}} >
    <SettingsOutlinedIcon sx={{fontSize:'20px'}} />
    <Typography sx={{ml:1,fontWeight:'500',fontSize:'12px',lineHeight:'20px',letter:'0.15px',mr:1.5}}>Manage</Typography>
    <ToggleSwitch isChecked={mailchampNotification} handleChange={handlemailchampNotification} id="mailchampNotification" />
  </Box>

    </Box>
    </Box>
  )
}

export default SettingIntergration
