import { Typography,Box,Button,Divider } from '@mui/material'
import React from 'react'

function SettingProfile() {
  return (
    <Box>
        <Box sx={{ width: "100%",height: "700px",backgroundColor:"#1C1A1E", mt: 2 }}>
            <Box sx={{ p: 4 }}>
              <Typography sx={{ fontWeight: "700", fontSize: "20px", lineHeight: "25.2px", alignItems: "center", mt: 1}} >Profile Management</Typography>
              <Typography sx={{ mt: 1, color: "#D5C9D5",fontWeight: "500",fontSize: "12px", lineHeight: "20px",letter: "0.15px"}}>
              Personalize your email alerts to ensure you stay informed andnever miss important updates.
              </Typography>
              <Box sx={{ display: "flex",mt: 3, displayL: "flex",alignItems: "center" }}>
                <Box sx={{ display: "flex", flexDirection: "column", mt: 4 }}>
                  <Typography sx={{ fontWeight: "700", fontSize: "16px", lineHeight: "20.16px", color: "#ffffff"}}>Your photo</Typography>
                  <Typography sx={{fontWeight: "500", fontSize: "12px", lineHeight: "20px", letter: "0.15px", color: "#D5C9D5", mt: 1}} >
                    This will be displayed on your profile
                  </Typography>
                </Box>
                <Box sx={{ display: "flex", flexDirection: "row",alignItems: "center",ml: 10,mt: 4 }} >
                  <img src="/assets/image/settingprofile.svg" alt=".." />
                  <Button sx={{ textTransform: "capitalize", color: "#D5C9D5", ml: 1}}>
                    Delete
                  </Button>
                  <Button sx={{ textTransform: "capitalize", color: "#A217A3" }}>
                    Update
                  </Button>
                </Box>
              </Box>
              <Box sx={{ width: "100%", mt: 4 }}>
                <form>
                  <Box sx={{ display: "flex" }}>
                  <Typography sx={{fontWeight:'700',fontSize:"16px",lineHeight:'20.16px',color:'#fff'}}>Full Name</Typography>
                  <input type="text" placeholder="Aora Fashion" className="full-width-email"/>
                  </Box>
                  <Box sx={{ display: "flex",mt:4 }}>
                  <Typography sx={{fontWeight:'700',fontSize:"16px",lineHeight:'20.16px',color:'#fff'}}>Email</Typography>
                  <input type="text" placeholder="aorafashion@gmail.com" className="full-width-email   email-set"/>
                  </Box>
                  <Box sx={{ display: "flex",mt:4 }}>
                  <Typography sx={{fontWeight:'700',fontSize:"16px",lineHeight:'20.16px',color:'#fff'}}>Password</Typography>
                  <input type="text" placeholder="password" className="full-width-email"/>
                    <Box sx={{ml:6}}>
                      <Button variant="outlined" sx={{borderRadius:'10px',fontWeight:'600',fontSize:'12px',lineHeight:'20px',py:1,color:'#E8E9E9',border:'1px solid #686B6E'}}>Edit  password</Button>
                    </Box>

                  </Box>
                    <Typography sx={{fontSize:'12px',fontWeight:'500',lineHeight:"18px",color:'#D5C9D5',mt:10}}>This account was created on July 25, 2024, 08:45:23 Am</Typography>
                    <Divider sx={{borderColor:"#D5C9D5",width:"950px",mt:1.5}} />
                    <Box sx={{display:'flex',justifyContent:'space-between',alignItems:'center',width:'64%',mt:4}}>
                      <Box>

                      <Typography sx={{fontWeight:'700',color:'#DF3E3E',lineHeight:'22.4px',fontSize:'16px'}}>Delete Account</Typography>
                      </Box>
                      <Box>
                        <Button sx={{bgcolor:'#fff !important',textTransform:'capitalize',color:'#1E1E1E !important',fontWeight:'bold',py:1.5,px:2,borderRadius:'10px'}}>Cancel</Button>
                        <Button sx={{bgcolor:'#A217A3 !important',textTransform:'capitalize',ml:2,py:1.5,px:2,color:'#fff !important',borderRadius:'10px'}}>Cancel</Button>
                      </Box>
                    </Box>
                
                 




                  <Box>

                  </Box>
                </form>
              </Box>
            </Box>
          </Box> 
    </Box>
  )
}

export default SettingProfile
