import { Box, Typography,Button } from '@mui/material'
import React from 'react'
// import { styled } from '@mui/material/styles';
// import Table from '@mui/material/Table';
// import TableBody from '@mui/material/TableBody';
// import TableCell, { tableCellClasses } from '@mui/material/TableCell';
// import TableContainer from '@mui/material/TableContainer';
// import TableHead from '@mui/material/TableHead';
// import TableRow from '@mui/material/TableRow';
// import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import CheckIcon from '@mui/icons-material/Check';
import SettingCard from './SettingCard';

const packages = [
    {
        name: 'Package One',
        tokens: 40,
        designs: 40,
        price: 5,
        color: '#03857A',
        backgroundColor:'#03857A',
        plan:'Package One'

    },
    {
        name: 'Package Two',
        tokens: 100,
        designs: 100,
        price: 10,
        color: '#2997D9',
       plan:'Package two'
    },
    {
        name: 'Package Three',
        tokens: 200,
        designs: 200,
        price: 20,
        color: '#A217A3',
        backgroundColor:'#A217A3',
        plan:'Package Three'
    },
];


// const StyledTableCell = styled(TableCell)(({ theme }) => ({
//     [`&.${tableCellClasses.head}`]: {
//       backgroundColor: '#3C3C3C',
//       color: '#FFFFFF',
//     },
//     [`&.${tableCellClasses.body}`]: {
//       fontSize: 14,
//     },
//   }));
  
//   const StyledTableRow = styled(TableRow)(({ theme }) => ({
//     '&:nth-of-type(odd)': {
//       backgroundColor:'#171319',
//       color:'#FFFFFF'
//     },
//     // hide last border
//     '&:last-child td, &:last-child th': {
//       border: 0,
//     },
//   }));

  
//   function createData(name, calories, fat, carbs, protein) {
//     return { name, calories, fat, carbs, protein };
//   }
  
//   const rows = [
//     createData('Package One - 40 tokens',  5.00, 27),
//     createData('Package One - 40 tokens',  5.00, 27  ),
//     createData('Package One - 40 tokens', 5.00, 27 ),
//     createData('Package One - 40 tokens', 5.00, 27 ),
//     createData('Package One - 40 tokens', 5.00, 27 ),
//   ]

function createData(invoice, amount, date, status) {
    return { invoice, amount, date, status };
  }
const rows = [
    createData('Package One - 40 tokens', 'USD $5.00', 'Jul 27, 2024', 'Paid'),
    createData('Package One - 40 tokens', 'USD $5.00', 'Jul 27, 2024', 'Paid'),
    createData('Package One - 40 tokens', 'USD $5.00', 'Jul 27, 2024', 'Paid'),
    createData('Package One - 40 tokens', 'USD $5.00', 'Jul 27, 2024', 'Paid'),
  ];

function SettingBilling({}) {
   
  return (
    <Box sx={{padding:'20px'}}>
        <Box>

        <Typography  className="Jakarta" sx={{fontWeight:'700',fontSize:'20px',lineHeight:"25.2px",color:'#FFFFFF'}}>Plans and billing</Typography>
        <Typography className="Jakarta" sx={{fontWeight:'500',fontSize:'12px',lineHeight:"20px",color:'#D5C9D5',letter:"0.15px",mt:1}}>Supercharge your workflow and connect tools you and your teams uses every day.</Typography>
        </Box>
        <Box sx={{width:'100%',height:'354px',backgroundColor:'#29272C',borderRadius:'20px',mt:2.5}}>
 
            <Box sx={{display:'flex',flexDirection:'row',p:2,ml:1}}>
                
                <Typography>Current Plan:</Typography>
                <Typography>{packages.plan}</Typography>
              
</Box>
        <Box display="flex" justifyContent="center" alignItems="center"   >
          
                        {packages.map((pack) => (
                            <SettingCard 
                            key={pack.name}
                                name={pack.name}
                                tokens={pack.tokens}
                                designs={pack.designs}
                                price={pack.price}
                                color={pack.color}
                                backgroundColor={pack.backgroundColor}
                                plan={pack.plan}/>
                        ))}
                    </Box>
            </Box>
            <Box>
                <Typography className="Jakarta" sx={{fontWeight:'700',fontSize:'20px',lineHeight:"25.2px",color:'#FFFFFF',mt:3}} >Billing History</Typography>

<Box sx={{mt:2}}>
                {/* <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>Invoice</StyledTableCell>
            <StyledTableCell align="right"> Amount</StyledTableCell>
            <StyledTableCell align="right">Date</StyledTableCell>
            <StyledTableCell align="right">Status</StyledTableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <StyledTableRow key={row.name}>
              <StyledTableCell component="th" scope="row">
                {row.name}
              </StyledTableCell>
              <StyledTableCell align="right">{row.calories}</StyledTableCell>
              <StyledTableCell align="right">{row.fat}</StyledTableCell>
              <StyledTableCell align="right">{row.carbs}</StyledTableCell>
             
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer> */}
      <TableContainer component={Paper} >
      <Table sx={{ minWidth: 680 }} aria-label="simple table">
        <TableHead>
          <TableRow sx={{backgroundColor:'#3C3C3C' ,width:'700px'}}>
            <TableCell sx={{color:'#FFFFFF',fontWeight:'600',fontSize:'16px',lineHeight:'16.20px'}}>Invoice</TableCell>
            <TableCell align="right" sx={{color:'#FFFFFF',fontWeight:'600',fontSize:'16px',lineHeight:'16.20px'}}>Amount</TableCell>
            <TableCell align="right" sx={{color:'#FFFFFF',fontWeight:'600',fontSize:'16px',lineHeight:'16.20px'}}>Date</TableCell>
            <TableCell align="right" sx={{color:'#FFFFFF',fontWeight:'600',fontSize:'16px',lineHeight:'16.20px'}}>Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.invoice}
              sx={{bgcolor: '#171319', '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row" sx={{color:'#D5C9D5',fontWeight:'500',fontSize:'12px',lineHeight:'20px',letter:'0.15px',borderBottom:'0px !important'}} >
                {row.invoice}
              </TableCell>
              <TableCell align="right" sx={{color:'#D5C9D5',fontWeight:'500',fontSize:'12px',lineHeight:'20px',letter:'0.15px',borderBottom:'0px!important'}}>{row.amount}</TableCell>
              <TableCell align="right" sx={{color:'#D5C9D5',fontWeight:'500',fontSize:'12px',lineHeight:'20px',letter:'0.15px',borderBottom:'0px!important'}}>{row.date}</TableCell>
              <TableCell align="right" sx={{color:'#D5C9D5',fontWeight:'500',fontSize:'12px',lineHeight:'20px',letter:'0.15px',borderBottom:'0px!important'}}>  
                 <Button sx={{bgcolor:'#FFEBFF !important',textTransform:'capitalize',color:'#A217A3',fontSize:'12px',borderRadius:'10px',borderBottom:'0px!important'}} startIcon={< img src='/assets/image/true.svg' style={{width:'10px'}}/>}>{row.status}</Button>
             
              
              </TableCell>
              <TableCell align="right" sx={{color:'#D5C9D5',fontWeight:'500',fontSize:'12px',lineHeight:'20px',letter:'0.15px',borderBottom:'0px!important'}}>  
                 <img src="/assets/image/createdownload.svg" alt="" />
                  
             
              
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </Box>
            </Box>
    </Box>
  )
}

export default SettingBilling
