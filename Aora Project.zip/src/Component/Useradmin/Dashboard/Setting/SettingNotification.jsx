import { Typography,Box } from '@mui/material'
import React, {useState }from 'react'
import ToggleSwitch from './ToggleSwitch';

function SettingNotification() {
    const [emailNotification, setEmailNotification] = useState(false);
    const [appNotification,setAppNotification] = useState(false)
    const [weChatNotification,setWechatNotification] = useState(false)
    const [smsNotification,setsmsNotification] = useState(false)

    const handleEmailNotification = () => {
      setEmailNotification(!emailNotification);
    };
    const handleAppNotification = () => {
        setAppNotification(!appNotification);
       
      };
      const handleWechatNotification = () => {
        setWechatNotification(!weChatNotification);
      };
      const handleSmsNotification = () => {
        setsmsNotification(!smsNotification);
      };
  return (
   <Box sx={{padding:"20px"}}>
    <Box >
        <Typography className="Jakarta" sx={{fontWeight:'700',fontSize:'20px',lineHeight:"25.2px",color:'#FFFFFF'}}>Notifications</Typography>
        <Typography className="Jakarta" sx={{fontWeight:'500',fontSize:'12px',lineHeight:"20px",color:'#D5C9D5',letter:"0.15px",mt:1}}>Personalize your email alerts to ensure you stay informed and never miss important updates.</Typography>
    </Box> 
    <Box sx={{display:'flex',justifyContent:"space-between",mt:10}}>
        <Box>

        <Typography className="Jakarta" sx={{fontWeight:'700',fontSize:'16px',lineHeight:"20.16px",color:'#FFFFFF'}}>Email Notification</Typography>
        <Typography className="Jakarta" sx={{fontWeight:'500',fontSize:'12px',lineHeight:"20px",color:'#D5C9D5',letter:"0.15px",mt:1}}>Build custom automation and integration with other apps. </Typography>
        </Box>
      <ToggleSwitch isChecked={emailNotification} handleChange={handleEmailNotification} id="emailNotification"/>
     </Box>

        <Box sx={{display:'flex',justifyContent:"space-between",mt:5}}>
        <Box>
       <Typography className="Jakarta" sx={{fontWeight:'700',fontSize:'16px',lineHeight:"20.16px",color:'#FFFFFF'}}>App Notification</Typography>
        <Typography className="Jakarta" sx={{fontWeight:'500',fontSize:'12px',lineHeight:"20px",color:'#D5C9D5',letter:"0.15px",mt:1}}>A natural language processing tool driven that allows you to have human-like conversation </Typography>
        </Box>
       <ToggleSwitch isChecked={appNotification} handleChange={handleAppNotification} id="appNotification"/>
        

        </Box>
        <Box sx={{display:'flex',justifyContent:"space-between",mt:5}}>
        <Box>

        <Typography className="Jakarta" sx={{fontWeight:'700',fontSize:'16px',lineHeight:"20.16px",color:'#FFFFFF'}}>WeChat Notification</Typography>
        <Typography className="Jakarta" sx={{fontWeight:'500',fontSize:'12px',lineHeight:"20px",color:'#D5C9D5',letter:"0.15px",mt:1}}>Build custom automation and integration with other apps.</Typography>
        </Box>

     
     <ToggleSwitch isChecked={weChatNotification} handleChange={handleWechatNotification} id="weChatNotification"/>

        </Box>
        <Box sx={{display:'flex',justifyContent:"space-between",mt:5}}>
        <Box>

        <Typography className="Jakarta" sx={{fontWeight:'700',fontSize:'16px',lineHeight:"20.16px",color:'#FFFFFF'}}>SMS Notification</Typography>
        <Typography className="Jakarta" sx={{fontWeight:'500',fontSize:'12px',lineHeight:"20px",color:'#D5C9D5',letter:"0.15px",mt:1}}>Build custom automation and integration with other apps.  </Typography>
        </Box>


 
     
 <ToggleSwitch isChecked={smsNotification} handleChange={handleSmsNotification} id="smsNotification"/>

        </Box>
   </Box>
  )
}

export default SettingNotification
