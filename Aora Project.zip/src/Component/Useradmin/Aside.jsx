import { Box, Stack, Typography } from '@mui/material'
import React from 'react'
import { useUserProfile } from '../../contexts/UserProfileContext';
import { useHistory } from 'react-router-dom';



const menu = [
    { icon: "assets/icons/Home icon.svg", name: "Home",path:'/dashboard' },
    { icon: "assets/icons/indrastryicon.svg", name: "Industry Trends",path:'/industry'},
    { icon: "assets/icons/Brand.svg", name: "Brand Profiles" ,path:'/Brandprofile'},
    { icon: "assets/icons/Generate.svg", name: "Generate Content" ,path:'/generateContach'},
    { icon: "assets/icons/createicon.svg", name: "Create Fashion" ,path:'/CreateFashion'},
    { icon: "assets/icons/reporticon.svg", name: "Reports"},
    { icon: "assets/icons/Settings.svg", name: "Settings" ,path:'/setting'},
    { icon: "assets/icons/Community.svg", name: "Community" },
    { icon: "assets/icons/marketicon.svg", name: "Marketplace" ,path:'/marketplace' }
]


const Aside = () => {

    

    const MenuItem = ({ Icon, name,path ,className }) => {
    
        return (
            <Box className={className} sx={{ cursor: 'pointer' }}>
                <Stack direction='row' gap='16px' borderRadius='8px' sx={{p:'16px 14px'}}>
                    <img src={Icon} width="16px" height="16px" alt='hj' />
                    <Typography sx={{ fontSize: "14px", fontWeight: "600", lineHeight: "20px" }}>{name}</Typography>
                </Stack>
            </Box>
        )
    };


    // const { profileData, loading, error } =useUserProfile();

    const history = useHistory();
    
    // if (loading) {
    //     return <div>Loading...</div>;
    // }

    // if (error) {
    //     return <div>{error}</div>;
    // }
    const logout = () => {
        localStorage.removeItem('authToken'); 
        history.push('/');
    };

    const handleChangePath = (path)=>{
        history.push(path);
        
    }
    
    return (
        <Box sx={{ borderRadius: '20px', Width: '312px',display:"flex",flexDirection:"column",justifyContent:"space-between",p:2 }} className="bg-[#0F0D10] h-full overflow-hidden overflow-y-auto ">
            <Box >
                <Box className="p-6 border-b-2 border-[#131619]"><img src='/assets/image/loginlogo1.png' alt="" class="w-[50px] h-[50px] " /></Box>
                <Box className="py-8 pt-[10px]" >
                    <Typography className='text-[#686B6E]' sx={{ fontSize: "12px", p: "10px 24px 20px" }}>GENERAL</Typography>
                    
                    {menu.map((el, index) => (
                        <span onClick={()=>handleChangePath(el.path)}>
                            <MenuItem  Icon={el.icon} name={el.name} className='asideHover' /></span>
                    ))}
                </Box>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: "center", bgcolor: "transparent" }} >
                <Box sx={{ width: "296px", margin: "auto", display: "flex" }} className="black-gradint rounded-2xl h-[80px] p-4 flex start justify-between items-center">
                    <Box className="flex">
                        <img src='/assets/image/avtar1.png' alt="" class="w-[48px] h-[48px] rounded-sm" />
                        <Box className="ps-3 ">
                            <Typography className='text-base text-white Jakarta font-semibold'>trusha</Typography>
                            <Typography className='Jakarta text-xs font-medium text-white'>Standard</Typography>
                             <Box className="ps-3">
                            
                        </Box>
                        </Box>
                    </Box>
                    <Box className="flex flex-col justify-end items-end " >
                        <Box><img src="assets/icons/logout.svg" alt="" /></Box>
                        <Typography className='text-xs font-medium text-white'>Logout</Typography>
                    </Box>
                </Box>
            </Box>
        </Box>
    )
}

export default Aside

