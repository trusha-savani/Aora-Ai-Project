import React from 'react'
import Grid from '@mui/material/Grid';
import { TextField, Typography } from '@mui/material';
import Rating from '@mui/material/Rating';
import { useHistory } from 'react-router-dom';
import Divider from '@mui/material/Divider';
import { FcGoogle } from "react-icons/fc";
import Avatar from '@mui/material/Avatar';
import AvatarGroup from '@mui/material/AvatarGroup';
import { useState } from 'react';
import { Button, Box } from '@mui/material';
import { sendOtp } from '../../api/apiRequests';
import EmailOtpDialog from '../../dialogs/EmailOtpDialog';
import PhoneOtpDialog from '../../dialogs/PhoneOtpDialog';
import CreateButton from '../../api/Components/CreateButton';

function Signup() {
    const [open, setOpen] = useState(false);
    const [name, setname] = useState('');
    const [email, setEmail] = useState('');
    const [phonenumber, setphonenumber] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [nameError, setnameError] = useState(false);
    const [emailError, setEmailError] = useState(false);
    const [phonenumberError, setphonenumberError] = useState(false);
    const [passwordError, setPasswordError] = useState(false);

   const [isSubmitting, setIsSubmitting] = useState(false);

    const validateEmail = (emailValue) => {
       
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue);
    };
    const handleNameChange = (e) => {
        setname(e.target.value);
        setnameError(false); 
    };
    const handlephoneChange = (e) => {
        setphonenumber(e.target.value);
        setphonenumberError(false); 
    };

    const handleEmailChange = (e) => {
        setEmail(e.target.value);
        setEmailError(false); 
    };

    const handlePasswordChange = (e) => {
        setNewPassword(e.target.value);
        setPasswordError(false);
    };

    const handleSendOtp =()=>{
        setOpen(true)
    }

    // const handleSendOtp = async () => {
    //     // history.push('/signuppage'); 
    //     const isValidEmail = validateEmail(email);
    //     const isPasswordNotEmpty = newPassword !== '';
    //     const isnameisNotEmpaty = name !== '';
    //     const isphonenumberisNotEmpaty = phonenumber !== '';

    //     if (!isnameisNotEmpaty) {
    //         setnameError(true)
    //     }
    //     if (!isValidEmail) {
    //         setEmailError(true);
    //     }

    //     if (!isPasswordNotEmpty) {
    //         setPasswordError(true);
    //     }
    //     if (!isphonenumberisNotEmpaty) {
    //         setphonenumberError(true)
    //     }

    //     if (isValidEmail && isPasswordNotEmpty && isnameisNotEmpaty && isphonenumberisNotEmpaty) {
    //         setIsSubmitting(true);
    //         const signupData = {
    //             fullName: name,
    //             emailAddress: email,
    //             phoneNumber: phonenumber,
    //             password: newPassword,
    //         };
    //         localStorage.setItem('signupData', JSON.stringify(signupData));
    //         const data = {
    //             emailAddress:email
    //         }   
    //         try {
    //             await sendOtp(data);
    //             handleClickOpen();
    //         }
    //          catch (error) {
    //             console.error('Login failed:', error);
    //         } finally {
    //             setIsSubmitting(false);
    //         }
    //     }
    // };
    const handleSignUpNavigation = () => {
        history.push('/')
    };
    const history = useHistory();
    let handlewechatenavigation = () => {
        history.push('/Signupwechat')
    }
    const [phone, setphone] = useState(false);
    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    const handlephoneclickopen = () => {
         setphone(true);
    }
    const handlephoneclose = () => {
        setOpen(false)
    }
    return (
      <Box>

            <Box sx={{height:'100vh'}} className="signup-body">
                <Grid container sx={{ backgroundColor: 'grey',height:'100%' }}>
                    <Grid item xs={12} xl={5} lg={5} md={12} sm={12} sx={{ backgroundColor: 'black',height:'100%'  }}>
                        <Box sx={{ padding: {xl:'50px',lg:'50px',sm:'40px',xs:'40px'} ,height:'100%',width:'100%',overflowY:'scroll', scrollbarWidth:'none' }}>
                            <Box>
                                <img src="/assets/image/loginlogo1.png" alt="" />
                            </Box>
                            <Box >
                                <Typography className='Matemasie ' sx={{
                                    fontSize: {xl:'35px',sm:'24px',xs:'18px'}, fontWeight: '500', lineHeight: '44px', color: '#ffffff', marginTop: '30px'
                                }} >
                                    Create account
                                </Typography>
                                </Box>
                             <Box >
                                <Typography variant='body2' sx={{
                                    mt: 6, color: '#686B6E'
                                }} >Full name*</Typography>
                                <TextField
                                    onChange={handleNameChange}
                                    type='text'
                                    value={name}
                                    error={nameError}
                                    name='Enter your full name'
                                    helperText={emailError ? "Please enter a full name." : ""}
                                    placeholder='Enter your full name'
                                    fullWidth
                                    sx={{
                                        mt: 1,
                                        borderRadius: '10px',
                                        '& label': { color: 'red' },
                                        '& .MuiOutlinedInput-root': {
                                            backgroundColor: newPassword ? 'transparent' : 'transparent',  // Set background color to red if there's text
                                            '& fieldset': {
                                                borderColor: '#363A3D',
                                                // borderRadius: '10px'
                                            },
                                            '&:hover fieldset': {
                                                borderColor: '#363A3D'
                                            },
                                            '&.Mui-focused': {
                                                backgroundColor: newPassword ? 'transparent' : 'transparent',  // Keep red background if there's text
                                                '& fieldset': {
                                                    borderColor: '#A217A3',
                                                    // borderRadius: '10px'
                                                },
                                            },
                                        },
                                    }}
                                />
                            </Box>
                            <Box sx={{ mt: 1 }}>
                                <Typography variant='body2' sx={{ color: '#686B6E' }} >Email </Typography>
                                <TextField
                                    type='text'
                                    onChange={handleEmailChange}
                                    error={emailError}
                                    value={email}
                                    name='Enter your email '
                                    helperText={emailError ? "Please enter email." : ""}
                                    placeholder='Enter your email '
                                    fullWidth
                                    sx={{
                                        mt: 1,
                                        borderRadius: '10px',
                                        '& label': { color: 'red' },
                                        '& .MuiOutlinedInput-root': {
                                            backgroundColor: newPassword ? 'transparent' : 'transparent',  // Set background color to red if there's text
                                            '& fieldset': {
                                                borderColor: '#363A3D',
                                                // borderRadius: '10px'
                                            },
                                            '&:hover fieldset': {
                                                borderColor: '#363A3D'
                                            },
                                            '&.Mui-focused': {
                                                backgroundColor: newPassword ? 'transparent' : 'transparent',  // Keep red background if there's text
                                                '& fieldset': {
                                                    borderColor: '#A217A3',
                                                    // borderRadius: '10px'
                                                },
                                            },
                                        },
                                    }}

                                />
                            </Box>
                            <Box sx={{ mt: 1 }}>
                                <Typography variant='body2' sx={{ color: '#686B6E' }} > Phone number*</Typography>
                                <TextField
                                    onChange={handlephoneChange}
                                    error={phonenumberError}
                                    type='text'
                                    value={phonenumber}
                                    name='Enter  phone number'
                                    placeholder='Enter  phone number'
                                    helperText={emailError ? "Please enter a phone number." : ""}
                                    fullWidth
                                    sx={{
                                        mt: 1,
                                        borderRadius: '10px',
                                        '& label': { color: 'red' },
                                        '& .MuiOutlinedInput-root': {
                                            backgroundColor: newPassword ? 'transparent' : 'transparent',  // Set background color to red if there's text
                                            '& fieldset': {
                                                borderColor: '#363A3D',
                                                
                                            },
                                            '&:hover fieldset': {
                                                borderColor: '#363A3D'
                                            },
                                            '&.Mui-focused': {
                                                backgroundColor: newPassword ? 'transparent' : 'transparent',  // Keep red background if there's text
                                                '& fieldset': {
                                                    borderColor: '#A217A3',
                                                    
                                                },
                                            },
                                        },
                                    }}
                                   />
                            </Box>
                            <Box sx={{ mt: 1 }}>
                                <Typography variant='body2' sx={{ color: '#686B6E' }} >Password*</Typography>
                                <TextField
                                    type='text'
                                    onChange={handlePasswordChange}
                                    value={newPassword}
                                    error={passwordError}
                                    name='Create a password'
                                    placeholder='Create a password'
                                    fullWidth
                                    helperText={emailError ? "Please enter a password." : ""}
                                    sx={{
                                        mt: 1,
                                        borderRadius: '10px',
                                        '& label': { color: 'red' },
                                        '& .MuiOutlinedInput-root': {
                                            backgroundColor: newPassword ? 'transparent' : 'transparent',  // Set background color to red if there's text
                                            '& fieldset': {
                                                borderColor: '#363A3D',
                                                // borderRadius: '10px'
                                            },
                                            '&:hover fieldset': {
                                                borderColor: '#363A3D'
                                            },
                                            '&.Mui-focused': {
                                                backgroundColor: newPassword ? 'transparent' : 'transparent',  // Keep red background if there's text
                                                '& fieldset': {
                                                    borderColor: '#A217A3',
                                                    // borderRadius: '10px'
                                                },
                                            },
                                        },
                                    }}
                                />
                            </Box>


                            <Box sx={{ mt: 2}}>
                                <Typography sx={{ fontSize: '16px', lineHeight: '24px', fontWeight: '500', letterSpacing: '0.15px', color: '#ffffff' }}>Must be at least 8 characters</Typography>
                            </Box>


                            <CreateButton text={isSubmitting ? "Submitting..." : "Create Account"}
                                disabled={isSubmitting?true:false} handleCLick={handleSendOtp} loading={isSubmitting} />
                            {/* popoup bopx */}

                            <EmailOtpDialog open={open} handleClose={handleClose} onClick={handlephoneclickopen} />
                            <PhoneOtpDialog open={phone} onClose={handlephoneclose} />

                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', my: 2 }}>
                                <Divider sx={{ width:   { xs: '130px', sm: '150px', md: '200px', lg: '200px', xl: '300px' }, borderColor: '#363A3D' }} />
                                <Typography variant="body2" sx={{ whiteSpace: 'nowrap', fontSize: '12px', fontWeight: '500', lineHeight: '18px', color: '#686B6E' }}>or sign up with</Typography>
                                <Divider sx={{ width:   { xs: '120px', sm: '150px', md: '200px', lg: '200px', xl: '300px' }, borderColor: '#363A3D' }} />
                            </Box>
                            <Box>
                                <Button
                                    variant="contained"
                                    startIcon={<FcGoogle />}
                                    sx={{
                                        width: '48%', px: { xl: 2, lg: 2, md: 1, sm: 1, xs: 1 },
                                        py: { xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }, fontSize: {xl:'16px',lg:'16px',md:'16px',sm:'10px',xs:'10px'}, lineHeight: '24px', fontWeight: '600', color: '#686B6E', letterSpacing: '0.15px', textTransform: 'none !important', backgroundColor: '#1A1D21', '&:hover': { backgroundColor: '#1A1D21', }
                                    }}
                                >
                                    Google Account
                                </Button>
                                <Button

                                    onClick={handlewechatenavigation}

                                    variant="contained"
                                   
                                    sx={{ width: '48%', px: {xl:2,lg:2,md:1,sm:1,xs:1},
                                    py: {xl:1,lg:1,md:1,sm:1,xs:1}, ml: {xl:3,md:2,sm:2,xs:1}, color: '#686B6E', textTransform: 'none !important', fontSize: {xl:'16px',lg:'16px',md:'16px',sm:'16px',xs:'10px'}, lineHeight: '24px', fontWeight: '600', letterSpacing: '0.15px', backgroundColor: '#1A1D21', '&:hover': { backgroundColor: '#1A1D21' } }}
                                >
                                    <img
                                        src="/assets/image/wechatlogo.png" // Replace with your image path
                                        alt="WeChat Logo"
                                        style={{ width: '24px', height: '24px', marginRight: '8px' }} // Adjust size and margin as needed
                                    />
                                    WeChat
                                </Button>
                            </Box>
                            <Box sx={{ display: 'flex', mt: 12, alignItems: 'center' }}>
                                <Typography sx={{ color: '#686B6E', fontWeight: '600', fontSize: '16px', lineHeight: '24px' }}>Already have an account?  <span class="demo" onClick={handleSignUpNavigation}>sign in</span> </Typography>
                                
                            </Box>
                        </Box>

                    </Grid>
                    <Grid item  xs={8} xl={7} lg={7} md={12}  sm={12}   className='Loginpage_mobile_view'>
                        <Box>
                            <Box sx={{ position: 'relative' }}>
                                <img src="/assets/image/signupimage.png" style={{ height: '100vh', width: '100%' }} alt="" />
                                <Box sx={{ position: 'absolute', bottom: '2px', padding: '90px', color: '#FFFFFF' }}>
                                    <img src="/assets/image/loginstar.png" alt="...." />
                                    <Box sx={{ mt: 5 }}>

                                        <Typography sx={{ fontSize: '45px', lineHeight: '56.7px', fontWeight: '600' }}>Start turning your</Typography>
                                        <Typography sx={{ fontSize: '45px', lineHeight: '56.7px', fontWeight: '600' }}>    ideas into reality.</Typography>
                                    </Box>

                                    <Box sx={{ mt: 2 }}>
                                        <Typography sx={{ fontSize: '16px', lineHeight: '28px', fontWeight: '500', letter: '0.15px' }}> Create a free account and get full access to all features for 14-days.</Typography>
                                        <Typography sx={{ fontSize: '16px', lineHeight: '28px', fontWeight: '500', letter: '0.15px' }}> No credit card needed. Trusted by over 2,000 professionals.</Typography>
                                    </Box>
                                    <Box sx={{ display: 'flex', mt: 3 }}>
                                        <Box sx={{ display: 'flex', justifyContent: 'start' }}>
                                            <AvatarGroup max={3}>
                                                <Avatar alt="Remy Sharp" src="/assets/image/avtar1.png" />
                                                <Avatar alt="Travis Howard" src="/assets/image/avtar2.png" />
                                                <Avatar alt="Cindy Baker" src="/assets/image/avtar3.png" />

                                            </AvatarGroup>

                                        </Box>
                                        <Box sx={{ display: 'flex', flexDirection: 'column', ml: 2 }}>
                                            <Box>

                                                <Typography sx={{ fontSize: '14px', fontWeight: '700', lineHeight: '16.94px', textAlign: 'start' }}>Our Happy Users</Typography>
                                            </Box>
                                            <Box sx={{ display: 'flex', mt: 1 }}>
                                                <Rating name="half-rating" defaultValue={4.5} precision={0.5} sx={{ fontSize: '16px' }} />
                                                <Typography sx={{ fontSize: '14px', lineHeight: '16.94px', fontWeight: '700' }}>4.5</Typography>
                                                <Typography sx={{ fontSize: '14px', lineHeight: '14.52px', fontWeight: '400', color: '#FAFAFA' }}>(200+ reviews)</Typography>
                                            </Box>
                                        </Box>

                                    </Box>
                                </Box>
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </Box>
</Box>



       
    )
}

export default Signup;
