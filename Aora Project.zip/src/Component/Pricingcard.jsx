import { Box, Typography } from '@mui/material'
import React from 'react'
import Aside from './Useradmin/Aside'
import PackageCard from './PackageCard'

const packages = [
    {
        name: 'Package One',
        tokens: 40,
        designs: 40,
        price: 5,
        color: '#03857A',
        backgroundColor:'#03857A'

    },
    {
        name: 'Package Two',
        tokens: 100,
        designs: 100,
        price: 10,
        color: '#2997D9',
        backgroundColor:'#2997D9'
    },
    {
        name: 'Package Three',
        tokens: 200,
        designs: 200,
        price: 20,
        color: '#A217A3',
        backgroundColor:'#A217A3'
    },
];


const Pricingcard = () => {
   const QuickTools = ["Create Fashion", "My Designs", "My Brands", "Marketplace"]
    return (
        <Box sx={{ bgcolor: '#171319', width: '100%', display: 'flex', gap: "12px", p: "12px " }} >

            <Box sx={{ position: 'sticky', top: "12px", height: `calc(100vh - 24px)` }} >
                <Aside />
            </Box>
            <Box sx={{ width: "90%" }}>
                <Box sx={{ pb: "12px" }}>
                    <Box sx={{ width: '100%', height: '104px', bgcolor: "#0F0D10", borderRadius: '20px', p: "24px", display: "flex", justifyContent: 'space-between', alignItems: 'center   ' }}>
                        <Box>
                            <Typography sx={{ color: 'white', fontWeight: '700',fontSize:"20px",lineHeight:'32px'  }} className='Jakarta'>My Account </Typography>
                            <Typography sx={{ color: '#D5C9D5', fontWeight: '500',fontSize:"14px",lineHeight:'20px',letter:'0.15px'  }} className='Jakarta'>Lorem Ipsum sit dolor mat neu et </Typography>
                        </Box>
                        <Box>
                            <img src="assets/image/Actions.png" alt="" />
                        </Box>
                    </Box>
                </Box>
                <Box sx={{ width: '100%', backgroundColor: '#1C1A1E', mt: 4, borderRadius: '20px',height:'780px' }}>
                    <Box>
                        <Typography sx={{ fontWeight: '700', fontSize: '40px', lineHeight: '32px', textAlign: 'center', pt: 10 }}>Select a Package</Typography>
                    </Box>
                    <Box>
                        <Typography sx={{ fontWeight: '500', fontSize: '16px', lineHeight: '20px', textAlign: 'center', letter: '0.15px',pt:5 }}>10 free credits then you add credits from $5.00</Typography>
                    </Box>


                    <Box display="flex" justifyContent="center" alignItems="center" sx={{mt:15}}  >
                        {packages.map((pack) => (
                            <PackageCard
                                key={pack.name}
                                name={pack.name}
                                tokens={pack.tokens}
                                designs={pack.designs}
                                price={pack.price}
                                color={pack.color}
                                backgroundColor={pack.backgroundColor}
                            />
                        ))}
                    </Box>

                </Box>

              

            </Box>

        </Box>
    )
}

export default Pricingcard
