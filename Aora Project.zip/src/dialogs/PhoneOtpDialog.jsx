import { Button, Dialog, DialogContent, Box } from '@mui/material';
import { Typography } from '@mui/material';
import { useState } from 'react';
import OtpInput from 'react-otp-input';
import { userSignup } from '../api/apiRequests';
import { useHistory } from 'react-router-dom';
import { toast, ToastContainer, Bounce } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import ErrorIcon from '@mui/icons-material/Error';

const SuccessIcon = () => (
    <CheckCircleOutlineIcon sx={{ color: '#A217A3' }} />
);
const ErrorIcons = () => (
    <ErrorIcon />
);

toast('success!', {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "dark",
    transition: Bounce,
});

const customToastOptions = {
    transition: Bounce,
    toastClassName: 'custom-toast',
    icon: <SuccessIcon />
};
const customErrorToastOptions = {
    transition: Bounce,
    toastClassName: 'custom-toast',
    icon: <ErrorIcons />, 
};
function PhoneOtpDialog({ open, handlephoneclose, onClick }) {
    const [number, setnumber] = useState('')
    const [otpError, setOtpError] = useState(false);


    const history = useHistory();
    const handleSignup = async () => {
        if (number.length === 6) {
            const signupData = JSON.parse(localStorage.getItem('signupData')) || {};
            signupData.phoneOtp = number;
            const finalSignupData = { ...signupData };
            console.log(finalSignupData);

            try {
                const response = await userSignup(finalSignupData);
                console.log('Signup successful:', response);
                toast.success('Signup successful!', customToastOptions);
                localStorage.removeItem('signupData');
                handlephoneclose(); 
               
            } catch (error) {
                toast.error(error.response.data.message, customErrorToastOptions);

            }
        } else {
            setOtpError(true); 
            toast.error('Phone OTP is Invalid.', customErrorToastOptions);
        }
    };
    console.log("handlesignup");

    return (
        <div>
            <ToastContainer position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="light"
            />{

                <Dialog
                    open={open}
                    onClose={handlephoneclose}
                    fullScreen
                >
                    <DialogContent sx={{
                        backgroundColor: 'black',
                        color: 'white',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'center',
                        alignItems: 'center',
                        height: '100vh',

                        position: 'relative'
                    }} className="grediunt">

                        <Box sx={{ position: 'absolute', top: '2%', left: '3%' }}
                        >
                            <img src="/assets/image/loginlogo1.png" alt="" />
                        </Box>
                        <Box sx={{ m: 25 }}>
                            <Typography sx={{ fontWeight: '400', fontSize: '36px', lineHeight: '44px', textAlign: 'start', ml: 3 }}>Check your phone</Typography>
                            <Typography sx={{ fontWeight: '500', fontSize: '16px', lineHeight: '28px', textAlign: 'start', letter: 'o.15px', color: '#9B9C9E', mr: 5, ml: 3 }}>We sent a verification code to 1234 5670 124 </Typography>
                            <Box sx={{ width: '400px', display: 'flex', justifyContent: 'center', flexDirection: 'column', ml: 2 }}>

                                <OtpInput
                                    value={number}
                                    onChange={setnumber}
                                    numInputs={6}
                                    
                                    renderInput={(props) => <input {...props} style={{
                                        width: '50px',
                                        height: '50px',
                                        fontSize: '36px',
                                        textAlign: 'center',
                                        borderRadius: '15px',
                                        border: '1px solid #A217A3',
                                        backgroundColor: 'black',
                                        color: '#A217A3',
                                        marginLeft: '10px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        marginTop: '40px'

                                    }} />}
                                />
                                {otpError && (
                                    <Typography
                                        sx={{
                                            color: 'red',
                                            fontSize: '14px',
                                            textAlign: 'center',
                                            mt: 2
                                        }}
                                    >
                                        Please enter a valid 6-digit OTP.
                                    </Typography>
                                )}
                                  <Button sx={{ mt: 5, ml: 1, width: '90%', borderRadius: "10px" }} fullWidth variant="contained" color="secondary" onClick={handleSignup}  >
                                    Verify
                                </Button>
                                <Box sx={{ display: 'flex', ml: 1, mt: 4 }}>

                                    <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#686B6E' }} >Didn’t receive code? </Typography>
                                    <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#A217A3', ml: 1 }}>Click to resend</Typography>
                                </Box>
                                <Box sx={{ position: 'absolute', top: '30%', left: '65%' }}>
                                    <img src="/assets/image/emailshadow.png" alt="" />
                                </Box>

                            </Box>
                        </Box>
              </DialogContent>
                </Dialog>
            }
        </div>
    )
}

export default PhoneOtpDialog
