
import React, { useState } from 'react';
import { Box, Button, Dialog, DialogContent, DialogContentText,  Divider, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import OrderSuccessfulDialog from './OrderSuccessfulDialog';

function Marketdiolog({isOpen,handleClick}) {
    const [successful, setSuccessful] = useState(false);
    const handleSuccessfulOrder = () => {
      setSuccessful(!successful);
      };
     
  return (
    <div>
      <Dialog
        open={isOpen}
       
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        PaperProps={{
          sx: {
            position: 'absolute',
            bottom: 0,
            right: 0,
            margin: 2,
            maxWidth: '420px'
          }
        }}
      >
       <Box sx={{display:'flex',justifyContent:'space-between',p:2,}}>
        <Typography sx={{color:'#1C1C1C',fontSize:"16px",fontWeight:'700',lineHeight:'20.16px'}}>Order options</Typography>
        <img src="/assets/image/close.svg " alt="" onClick={handleClick}  style={{marginLeft:'230px'}}/>
        <CloseIcon sx={{color:'#1C1C1C'}} />
       </Box>
       <Divider />
       <Box sx={{p:4}}>

       <Typography sx={{color:'#686B6E',fontWeight:'400',fontSize:'36px',lineHeight:'44px',mt:5}} >500</Typography>
       <Typography sx={{color:'#9B9C9E',fontWeight:'500',fontSize:'16px',lineHeight:'28px',letter:'0.15px'}} >TOKEN BALANCE</Typography>
       <Typography sx={{color:'#686B6E',fontWeight:'400',fontSize:'24px',lineHeight:'44px',mt:2}} >Enter email, Phone or WeChat ID</Typography>
       <Typography sx={{color:'#9B9C9E',fontWeight:'500',fontSize:'16px',lineHeight:'28px',mt:1}}>Delivery for your selected service will be sent to your email, as well as other relevant communication.</Typography>
       <Box>
        <Typography sx={{color:'#9B9C9E',fontWeight:'500',fontSize:'14px',lineHeight:'20px',mt:3,letter:'0.15px'}} >Email</Typography>
        <input type="text" placeholder='xcbn zxnc' style={{ width: '100%',border:'1px solid #363A3D',borderRadius:'10px',padding:'5px',fontSize:'16px'}} />
       </Box>
       <Box>
        <Typography sx={{color:'#9B9C9E',fontWeight:'500',fontSize:'14px',lineHeight:'20px',mt:2,letter:'0.15px'}}>Phone number</Typography>
        <input type="text" name='email' placeholder='xcbn zxnc' style={{ width: '100%',border:'1px solid #363A3D',borderRadius:'10px',padding:'5px',fontSize:'16px',fontWeight:'500',lineHeight:'24px'}} />
       </Box>
       <Box>
        <Typography sx={{color:'#9B9C9E',fontWeight:'500',fontSize:'14px',lineHeight:'20px',mt:2,letter:'0.15px'}}>WeChat ID</Typography>
        <input type="text" placeholder='xcbn zxnc' style={{ width: '100%',border:'1px solid #363A3D',borderRadius:'10px',padding:'5px',fontSize:'16px'}} />
       </Box>
       <Button sx={{backgroundColor:"#A217A3 !important",width:"100%",mt:4,borderRadius:"20px",color:'#fff !important',textTransform:'capitalize'}} onClick={()=>{
        handleClick();
        handleSuccessfulOrder();
       }}>Proceed</Button>

       </Box>

        <DialogContent>
          <DialogContentText id="alert-dialog-description">
          {/* Enter email, Phone or WeChat ID */}
          </DialogContentText>
          
        </DialogContent>
      <Box>
        
      </Box>
      </Dialog>
 <OrderSuccessfulDialog isOpen={successful}  handleClick={handleSuccessfulOrder}/>

        
      
    </div>
  )
}

export default Marketdiolog
