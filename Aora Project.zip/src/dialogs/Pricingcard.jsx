import React from 'react'
import { Box, Dialog, DialogTitle, DialogContent, DialogActions, Button, Typography } from '@mui/material';
import Pricecarddiolog from './Pricecarddiolog';

function Pricingcard({open,handleClose}) {
  return (
    <Box>
 <Dialog open={open} onClose={handleClose} PaperProps={{
          sx: {
            width: '400px',
            height: '300px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 3,
            marginLeft:'200px',
            
          },
        }}>
      <DialogTitle>Confirm Purchase</DialogTitle>
        <DialogContent>
          <Typography sx={{color:'red'}}>Are you sure you want to add the package for.00?</Typography>
        </DialogContent>
        <DialogActions>
         <Pricecarddiolog />
        </DialogActions>
     
      </Dialog>
    </Box>
  )
}

export default Pricingcard
