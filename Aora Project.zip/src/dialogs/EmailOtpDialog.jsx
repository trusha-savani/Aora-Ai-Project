import React from 'react'
import { Button, Dialog, DialogContent, Box } from '@mui/material';
import { Typography } from '@mui/material';
import { useState, useEffect } from 'react';
import OtpInput from 'react-otp-input';

const EmailOtpDialog = ({ open, handleClose, onClick }) => {
   const [otp, setOtp] = useState('');
    const [otpError, setOtpError] = useState(false);

    useEffect(() => {
        const signupData = JSON.parse(localStorage.getItem('signupData')) || {};
        signupData.emailOtp = otp;
        localStorage.setItem('signupData', JSON.stringify(signupData));
    }, [otp]);

    const handleVerifyClick = () => {
        if (otp.length === 6) {

            setOtpError(false);
            onClick();
        } else {
            setOtpError(true);
        }
    };

    return (
        <div>
            <Dialog open={open} onClose={handleClose} fullScreen >
                <DialogContent sx={{
                    backgroundColor: 'black',
                    color: 'white',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: '100vh',
                    position: 'relative'
                }} className="grediunt">


                    <Box sx={{ position: 'absolute', top: '2%', left: '3%' }}>
                        <img src="/assets/image/loginlogo1.png" alt="" />
                    </Box>

                    <Box sx={{  m:20 }}>
                        <Typography sx={{ fontWeight: '400', fontSize: '36px', lineHeight: '44px', textAlign: 'start', ml: 2 }}>Check your email</Typography>
                        <Typography sx={{ fontWeight: '500', fontSize: '14px', lineHeight: '28px', textAlign: 'start', ml: 2, letter: 'o.15px', color: '#9B9C9E', mt: 1, display: 'flex', flexWrap: 'wrap' }}>We sent a verification code to example@gmail.com</Typography>
                    <Box sx={{ width: '400px', display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>

                        <OtpInput
                            value={otp}
                            onChange={setOtp}
                            numInputs={6}

                            renderInput={(props) => <input {...props} style={{
                                width: '50px',
                                height: '50px',
                                fontSize: '36px',
                                textAlign: 'center',
                                borderRadius: '15px',
                                border: '1px solid #A217A3',
                                backgroundColor: 'black',
                                color: '#A217A3',
                                marginLeft: '13px',
                                display: 'flex',
                                alignItems: 'center',
                                marginTop: '40px',
                            }} />}
                        />


                        {otpError && (
                            <Typography
                                sx={{
                                    color: 'red',
                                    fontSize: '14px',
                                    textAlign: 'center',
                                    mt: 2
                                }}
                            >
                                Please enter a valid OTP.
                            </Typography>
                        )}
                        <Button sx={{
                            mt: { xs: 3, sm: 4, md: 5, lg: 6, xl: 7 },
                            ml: { xs: 2, sm: 0.5, md: 1 ,xl:2},
                            padding: { xs: '8px 16px', sm: '10px 20px', md: '12px 24px' },
                            fontSize: { xs: '14px', sm: '16px', md: '18px' }, textTransform: 'none',width:'90%',borderRadius:"10px"
                        }}  variant="contained" color="secondary" onClick={handleVerifyClick} >
                            Verify
                        </Button>
                        <Box sx={{ display: 'flex', ml: 2, mt: {xl:4,md:5,sm:4,xs:5} }}>

                            <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#686B6E' }} >Didn’t receive code? </Typography>
                            <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#A217A3', ml: 1 }}>Click to resend</Typography>
                        </Box>
                        <Box sx={{ position: 'absolute', top: '30%', left: '65%' }}>
                            <img src="/assets/image/emailshadow.png" alt="" />
                        </Box>

                    </Box>
                    </Box>
              </DialogContent>
            </Dialog>
        </div>
    )
}

export default EmailOtpDialog
