import React from 'react'
import { Button, Dialog, DialogContent, Box, TextField, Typography, InputAdornment } from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import IconButton from '@mui/material/IconButton';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { forgotPassword } from '../api/apiRequests';
import { toast, Bounce } from 'react-toastify';
import ErrorIcon from '@mui/icons-material/Error';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import { useHistory } from 'react-router-dom';

function NewPassword({ open, handlepasswordclose }) {
    const [password, setPassword] = useState('')
    const [passwordError, setPasswordError] = useState(false);
    const [confirmedPassword, setConfirmedPassword] = useState('')
    const [confirmedPasswordError, setConfirmedPasswordError] = useState(false);
    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };
    const handleConfirmedPasswordChange = (event) => {
        setConfirmedPassword(event.target.value);
    };
    const history = useHistory();
    const SuccessIcon = () => (
        <CheckCircleOutlineIcon sx={{ color: '#A217A3' }} />
    );
    const ErrorIcons = () => (
        <ErrorIcon />
    );

    toast('success!', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
        transition: Bounce,
    });

    const customToastOptions = {
        transition: Bounce,
        toastClassName: 'custom-toast',
        icon: <SuccessIcon />
    };
    const customErrorToastOptions = {
        transition: Bounce,
        toastClassName: 'custom-toast',
        icon: <ErrorIcons />,  // Custom error icon
    };
    const handleforgotPassword = async () => {
        setPasswordError(false);
        setConfirmedPasswordError(false);

        if (password === '') {
            setPasswordError(true);
        }
        if (confirmedPassword === '') {
            setConfirmedPasswordError(true);
        }
        if (password !== confirmedPassword) {
            setPasswordError(true);
            setConfirmedPasswordError(true);
        }

        if (passwordError || confirmedPasswordError) {
            return;
        }
        const forgateData = JSON.parse(localStorage.getItem('forgateData')) || {};
        forgateData.newPassword = password;
        forgateData.entityType = "User"
        const finalData = { ...forgateData };
        console.log(finalData);

        try {
            const response = await forgotPassword(finalData);
            toast.success('Signup successful!', customToastOptions);
            localStorage.removeItem('forgateData');
            history.push('/login');
            console.log(response);
            
        } catch (error) {
            toast.error(error.response.data.message, customErrorToastOptions);
        }
    };

    return (
        <Box>
            <Dialog open={open} fullScreen >
                <DialogContent sx={{
                    backgroundColor: 'black',
                    color: 'white',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: '100vh',
                    position: 'relative'
                }}
                    className="grediunt">

                    <Box sx={{ position: 'absolute', top: '2%', left: '3%' }}>
                        <img src="/assets/image/loginlogo1.png" alt="" />
                    </Box>
                    <Box sx={{ position: 'absolute', top: '22%' }}>

                        <Typography sx={{ fontWeight: '400', fontSize: '36px', lineHeight: '44px', textAlign: 'start', ml: 4, }} onClick={handlepasswordclose}>Set new password</Typography>
                        <Typography sx={{ fontWeight: '500', fontSize: '16px', lineHeight: '28px', textAlign: 'start', ml: 4, letter: 'o.15px', color: '#9B9C9E', mt: 2 }}>Your previous password has been reset. Please set a new</Typography>
                        <Typography sx={{ fontWeight: '500', fontSize: '16px', lineHeight: '28px', textAlign: 'start', ml: 4, letter: 'o.15px', color: '#9B9C9E', mt: 1 }}>password for your account.</Typography>
                    </Box>

               <Box sx={{ width: '500px', height: '500px', display: 'flex', justifyContent: 'start', flexDirection: 'column' }}>

                  <Box sx={{ mt: 20, ml: 6 }}>
                            <Typography sx={{ fontWeight: '500', fontSize: '14px', lineHeight: '20px', letter: '015px', color: '#9B9C9E' }}>Create password</Typography>
                            <TextField
                                type='password'
                                name='enter code'
                                value={password}
                                onChange={handlePasswordChange}
                                error={passwordError}
                                helperText={passwordError ? 'Password is required' : ''}
                                fullWidth
                                sx={{
                                    borderRadius: '10px', marginTop: '20px', backgroundColor: '#363A3D', color: '#9B9C9E', '& .MuiInputBase-input::placeholder': {
                                        color: '#FFFFFF'
                                    },
                                }}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton>
                                                <VisibilityIcon style={{ color: '#9B9C9E' }} />
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                            />
                            <Typography sx={{ fontWeight: '500', fontSize: '14px', lineHeight: '20px', letter: '015px', color: '#9B9C9E', mt: 2 }}>Create password</Typography>
                            <TextField
                                type='password'
                                name='enter code'
                                value={confirmedPassword}
                                onChange={handleConfirmedPasswordChange}
                                error={confirmedPasswordError}
                                helperText={confirmedPasswordError ? 'Passwords do not match' : ''}
                                fullWidth
                                sx={{
                                    borderRadius: '10px', marginTop: '20px', backgroundColor: '#363A3D', color: '#9B9C9E', '& .MuiInputBase-input::placeholder': {
                                        color: '#FFFFFF'
                                    },
                                }}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton>
                                                <VisibilityIcon style={{ color: '#9B9C9E' }} />
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                            />
                       <Button sx={{ mt: 5, textTransform: 'none' }} fullWidth variant="contained" color="secondary" onClick={handleforgotPassword} >
                                <Link to="/">Create password </Link>
                            </Button>
                            <Box sx={{ display: 'flex', mt: 4 }}>

                                <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#686B6E' }} >Didn’t receive code? </Typography>
                                <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#A217A3', ml: 1 }}>Resend</Typography>
                            </Box>
                            <Box sx={{ position: 'absolute', top: '2%', left: '58%' }}>
                                <img src="/assets/image/emailshadow.png" alt="" />
                            </Box>

                        </Box>
                    </Box>
                </DialogContent>
            </Dialog>
        </Box>
    )
}

export default NewPassword
