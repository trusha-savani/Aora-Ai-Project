import React from 'react'
import {  Box,Typography,Dialog, DialogContent } from '@mui/material';
import Button from '@mui/material/Button';
import CloseIcon from '@mui/icons-material/Close';

function Pricecarddiolog({open,handleClose ,name, tokens, designs, price, color,backgroundColor}) {
  return (
    <div>
      <Dialog open={open}  PaperProps={{
          sx: {
            width: '450px',
           
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius:'10px',
            marginLeft:'370px',
            marginTop:'200px'
        
          },
        }}>
      <Box sx={{display:'flex',backgroundColor,width:'100%',justifyContent:'space-between',p:2}}>
          <Box>
            <Typography sx={{fontWeight:'800',fontSize:'20px',lineHeight:'20px',letter:'0.15px'}}>{name}</Typography>
            <Typography sx={{fontWeight:'600',fontSize:'16px',lineHeight:'20px',letter:'0.15px',mt:1}}>+ {tokens} tokens</Typography>
          </Box>
          <Box sx={{display:'flex',alignItems:'center'}}>
<CloseIcon sx={{color:'#F0F0F0',fontWeight:'700',cursor:'pointer'}}   onClick={handleClose}/>
          </Box>
        </Box>
        <Box>
          <Typography sx={{fontWeight:'700',fontSize:'18px',lineHeight:'22.68px',letter:'0.15px',color:'#1E1E1E',m:3}}>Add for ${price}.00 </Typography>
            </Box>
            <Box></Box>

            <Box sx={{display:'flex',border:'1px solid #017DFF',width:'400px',py:0.5,alignItems:'center',justifyContent:'center',borderRadius:'5px'}}>
                <img src="/assets/image/appliy.svg" alt="" style={{width:'24px'}} />
                <Typography sx={{color:'#017DFF',fontWeight:'600',fontSize:'14px',lineHeight:'20px',letter:'0.15px',ml:1.5}}>Alipay</Typography>
            </Box>
            <Box sx={{display:'flex',border:'1px solid #00447C',width:'400px',py:0.5,alignItems:'center',justifyContent:'center',mt:1,borderRadius:'5px'}}>
                <img src="/assets/image/pay.svg" alt="" style={{width:'24px',height:'24px'}} />
                <Typography sx={{color:'#00447C',fontWeight:'600',fontSize:'14px',lineHeight:'20px',letter:'0.15px',ml:1.5}}>Union pay</Typography>
            </Box>
            <Box sx={{display:'flex',border:'1px solid #257D25',width:'400px',py:0.5,alignItems:'center',justifyContent:'center',mt:1,borderRadius:'5px'}}>
                <img src="/assets/image/chat.svg" alt="" style={{width:'24px',height:'24px'}} />
                <Typography sx={{color:'#257D25',fontWeight:'600',fontSize:'14px',lineHeight:'20px',letter:'0.15px',ml:1.5}}>WeChat</Typography>
            </Box>
            <Box sx={{width:'90%',mt:2}}>

            <Button sx={{bgcolor:color,width:'100%',color:'#F0F0F0',py:1,textTransform:'capitalize','&:hover': {
            bgcolor: color,
          },}}>Credit or Debit Card</Button>
            </Box>
        <DialogContent>
        </DialogContent>
      </Dialog>   
    </div>
  )
}

export default Pricecarddiolog

