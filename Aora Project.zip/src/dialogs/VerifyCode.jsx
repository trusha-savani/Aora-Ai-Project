import React from 'react'
import { Button, Dialog, DialogContent, Box,TextField } from '@mui/material';
import { Typography } from '@mui/material';
import { useState, useEffect } from 'react';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';


function VerifyCode({open,handlevarifyclose,onClick}) {
  const [otp, setOtp] = useState('');
  const [otpError, setOtpError] = useState(false);

  useEffect(() => {
    const forgateData = JSON.parse(localStorage.getItem('forgateData')) || {};
    forgateData.otp = otp;
    localStorage.setItem('forgateData', JSON.stringify(forgateData));
}, [otp]);

    const handleVerifyClick = () => {
        if (otp.length !== 0) {
            setOtpError(false);
            onClick();
        } else {
            setOtpError(true);
        }
    };

    const handleOtpChange = (e) => {
      setOtp(e.target.value);
  };
return (
    <Box>
          <Dialog open={open} fullScreen >
                <DialogContent sx={{
                    backgroundColor: 'black',
                    color: 'white',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: '100vh',

                    position: 'relative'
                }}
                    className="grediunt">

                    <Box sx={{ position: 'absolute', top: '2%', left: '3%' }}>
                        <img src="/assets/image/loginlogo1.png" alt="" />
                    </Box>
                    <Box sx={{ position: 'absolute', top: '25%' }}>
                        <Box sx={{ display: 'flex', color: '#686B6E', }}>
                            <KeyboardArrowLeftIcon />
                            <Typography sx={{ fontWeight: '500', fontSize: '14px', lineHeight: '20px', letter: '015px' }} onClick={handlevarifyclose}>Back to login</Typography>
                        </Box>
                        <Typography sx={{ fontWeight: '400', fontSize: '36px', lineHeight: '44px', textAlign: 'start', ml: 1, mt: 2 }}>Verify code</Typography>
                        <Typography sx={{ fontWeight: '500', fontSize: '16px', lineHeight: '28px', textAlign: 'start', ml: 1, letter: 'o.15px', color: '#9B9C9E', mt: 3 }}>An authentication code has bee sent to your email</Typography>
                    </Box>

                  <Box sx={{ width: '500px', height: '500px', display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>

        <Box sx={{ mt: 20, ml: 9 }}>
                            <Typography sx={{ fontWeight: '500', fontSize: '14px', lineHeight: '20px', letter: '015px', color: '#9B9C9E' }}>Enter code</Typography>
                            <TextField
                                type='text'
                                name='enter code'
                                value={otp}
                                onChange={handleOtpChange}
                                fullWidth
                                sx={{
                                    borderRadius: '10px', marginTop: '20px', backgroundColor: '#363A3D', color: '#9B9C9E', '& .MuiInputBase-input::placeholder': {
                                        color: '#FFFFFF'
                                    },
                                }}
                            />
                            {otpError && (
                            <Typography
                                sx={{
                                    color: 'red',
                                    fontSize: '14px',
                                    textAlign: 'center',
                                    mt: 2
                                }}
                            >
                                Please enter a valid OTP.
                            </Typography>
                        )}

                 <Button sx={{ mt: 5, textTransform: 'none' }} fullWidth variant="contained" color="secondary" onClick={handleVerifyClick}>
                                Verify
                            </Button>
                            <Box sx={{ display: 'flex', mt: 4 }}>

                                <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#686B6E' }} >Didn’t receive code? </Typography>
                                <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#A217A3', ml: 1 }}>Resend</Typography>
                            </Box>
                            <Box sx={{ position: 'absolute', top: '2%', left: '58%' }}>
                                <img src="/assets/image/emailshadow.png" alt="" />
                            </Box>

                        </Box>
                    </Box>
                </DialogContent>
            </Dialog> 
    </Box>
  )
}

export default VerifyCode
