import { Button, Dialog, DialogContent, Box,TextField } from '@mui/material';
import { Typography } from '@mui/material';
import { useState, } from 'react';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import React from 'react'
import { sendOtp } from '../api/apiRequests'

function FrogatePassword({open,handleCloseDialog,onClick}) {
    const [email, setEmail] = useState(''); 
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(''); 
    const handleEmailChange = (event) => {
        setEmail(event.target.value);
    };
    const validateEmail = (email) => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    };
    const handleSubmit = async () => {
        if (!validateEmail(email)) {
            setError('Please enter a valid email address.');
            return;
        }
        setError('');
        setSuccess('');
      const forgateData = {
            emailAddress: email
        };
        localStorage.setItem('forgateData', JSON.stringify(forgateData));
        
        try {
            const response = await sendOtp(forgateData);
            console.log(response);
                 setSuccess('OTP sent successfully!');
                 onClick()
           
        } catch (error) {
            setError('An error occurred. Please try again.');
        } 
    };
    
    
  return (
    <Box>
        <Dialog open={open} fullScreen >
                <DialogContent sx={{
                    backgroundColor: 'black',
                    color: 'white',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: '100vh',

                    position: 'relative'
                }} className="grediunt">

                    <Box sx={{ position: 'absolute', top: '2%', left: '3%' }}>
                        <img src="/assets/image/loginlogo1.png" alt="" />
                    </Box>
                    <Box sx={{ position: 'absolute', top: '25%' }}>
                        <Box sx={{ display: 'flex', color: '#686B6E', ml: 3 }}>
                            <KeyboardArrowLeftIcon />
                            <Typography onClick={handleCloseDialog}>Back to login</Typography>
                        </Box>
                        <Typography sx={{ fontWeight: '400', fontSize: '36px', lineHeight: '44px', textAlign: 'start', ml: 4, mt: 3 }}>Forgot your password?</Typography>
                        <Typography sx={{ fontWeight: '500', fontSize: '16px', lineHeight: '28px', textAlign: 'start', ml: 4, letter: 'o.15px', color: '#9B9C9E', mt: 3 }}>Don’t worry, can happen to anyone. Enter your email </Typography>
                        <Typography sx={{ fontWeight: '500', fontSize: '16px', lineHeight: '28px', textAlign: 'start', ml: 4, letter: 'o.15px', color: '#9B9C9E', mt: 1 }}>below to recover your password.</Typography>
                    </Box>

                 <Box sx={{ width: '500px', height: '500px', display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
                          <Box sx={{ mt: 25, ml: 9 }}>
                            <Typography sx={{ fontWeight: '500', fontSize: '14px', lineHeight: '20px', letter: '015px', color: '#9B9C9E' }}>Email </Typography>
                            <TextField
                                type='text'
                                name='enter your email'
                                onChange={handleEmailChange} 
                               value={email}
                                placeholder='Enter your email'
                                fullWidth
                                sx={{
                                    borderRadius: '10px', marginTop: '20px', backgroundColor: '#363A3D', color: '#9B9C9E', '& .MuiInputBase-input::placeholder': {
                                        color: '#FFFFFF'
                                    },
                                }}
                            />
                          
                        {error && (
                                <Typography sx={{ color: 'red',fontSize: '14px',textAlign: 'center', mt: 2}}>
                                    {error}
                                </Typography>
                            )}
                            {success && (
                                <Typography sx={{ color: 'green',fontSize: '14px', textAlign: 'center', mt: 2}}>
                                    {success}
                                </Typography>
                            )}
                           <Button sx={{ mt: 5, textTransform: 'none' }} fullWidth variant="contained" color="secondary" onClick={handleSubmit} >
                                Submit
                            </Button>
                            <Box sx={{ display: 'flex', mt: 4 }}>

                                <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#686B6E' }} >Didn’t receive code? </Typography>
                                <Typography sx={{ fontWeight: '600', lineHeight: '24px', letter: '0.15px', fontSize: '16px', color: '#A217A3', ml: 1 }}>Click to resend</Typography>
                            </Box>
                            <Box sx={{ position: 'absolute', top: '28%', left: '58%' }}>
                                <img src="/assets/image/emailshadow.png" alt="" />
                            </Box>

                        </Box>
                    </Box>
                </DialogContent>
            </Dialog>
</Box>
  )
}

export default FrogatePassword
