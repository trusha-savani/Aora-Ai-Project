import React from 'react'
import { Box, Button, Dialog } from '@mui/material';
function OrderSuccessfulDialog ({isOpen,handleClick}) {
  return (
    <Box>
      <Dialog
        open={isOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        PaperProps={{
          sx: { width:'646px',height:'350px',padding:'200px, 100px, 90px, 100px',borderRadius:'20px'}
        }}
      >
     <Box sx={{padding:'90px, 100px, 90px, 100px'}}>

          <Box id="alert-dialog-description" sx={{textAlign:'center',fontWeight:'400',fontSize:'36px',lineHeight:'44px',color:'#686B6E',padding:"100px 100px 10px"}}>
          Successful Order
          </Box>
          <Box sx={{display:"flex",justifyContent:'center',mt:5}}>
          <Button onClick={handleClick} color="primary" sx={{backgroundColor :'#A217A3 !important',width:"40%",borderRadius:"20px",textTransform:'capitalize',py:1,color:'#D9D9D9'}}>
            Done
          </Button>
       </Box>

          </Box>
       
      </Dialog> 
    </Box>
  )
}

export default OrderSuccessfulDialog
