import React from 'react'
import  Dialog from '@mui/material/Dialog';
import { Box,Typography } from '@mui/material';


function NotificationDiolog({isOpen,handleClick}) {

    const notifications = [
        {
            icon: '/assets/image/createclose.svg',
          title: 'You have a bug that needs...',
          time: 'Just now',
          type: 'bug',
        },
        {
            icon: '/assets/image/createclose.svg',
          title: 'New user registered',
          time: '59 minutes ago',
          type: 'user',
        },
        {
            icon: '/assets/image/createclose.svg',
          title: 'You have a bug that needs...',
          time: '12 hours ago',
          type: 'bug',
        },
        {
            icon: '/assets/image/createclose.svg',
          title: 'Andi Lane subscribed to you',
          time: 'Today, 11:59 AM',
          type: 'subscribe',
        },
      
      ];
      const Activities =[
        {
            icon: '/assets/image/createclose.svg',
          title: 'You have a bug that needs...',
          time: 'Just now',
          type: 'bug',
        },
        {
            icon: '/assets/image/createclose.svg',
          title: 'New user registered',
          time: '59 minutes ago',
          type: 'user',
        },
        {
            icon: '/assets/image/createclose.svg',
          title: 'You have a bug that needs...',
          time: '12 hours ago',
          type: 'bug',
        },
        {
            icon: '/assets/image/createclose.svg',
          title: 'Andi Lane subscribed to you',
          time: 'Today, 11:59 AM',
          type: 'subscribe',
        },
      ]
  return (
    <Box >
       <Dialog
        open={isOpen}
        onClose={handleClick}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        sx={{display:'flex',justifyContent:'end',alignItems: 'start',
            '& .MuiDialog-paper': {
              backgroundColor: '#1C1A1E', 
              color: '#1C1A1E', 
              width:'300px',padding:"20px"
            },
        }}
      >
        <Box>
            <Box sx={{mb:2,fontWeight:'600',fontSize:'14px',lineHeight:'20px'}}>Notifications</Box>
        </Box>

        
         {notifications.map((notification, index) => (
                    <Box key={index} sx={{ display: 'flex', alignItems: 'center',color:'red'}}>
                       
                        <img
      src={notification.icon}
      alt="icon"
      style={{
        width: '30px', 
        height: '30px',
        objectFit: 'contain',
        backgroundColor:'#ffffff',
        borderRadius:'10px',
        
      }}
    />
                           
                      <Box sx={{ marginLeft: 1,padding:1 }}>
                        <Typography variant="body2" sx={{fontWeight:'400',fontSize:'14px',lineHeight:'20px'}}>
                          {notification.title}
                        </Typography>
                        <Typography variant="caption" color="text.secondary" sx={{fontWeight:'400',fontSize:'12px',lineHeight:'18px',color:'#FFF9FF'}}>
                          {notification.time}
                        </Typography>
                      </Box>
                    </Box>
                  ))}
    
          <Box>
            <Box sx={{mb:2,fontWeight:'600',fontSize:'14px',lineHeight:'20px',mt:2}}>Activities</Box>
        </Box>

        
         {Activities.map((Activities, index) => (
                    <Box key={index} sx={{ display: 'flex', alignItems: 'center',color:'red'}}>
                       
                        <img
      src={Activities.icon}
      alt="icon"
      style={{
        width: '30px', 
        height: '30px',
        objectFit: 'contain',
        backgroundColor:'#ffffff',
        borderRadius:'10px',
        
      }}
    />
                           
                      <Box sx={{ marginLeft: 1,padding:1 }}>
                        <Typography variant="body2" sx={{fontWeight:'400',fontSize:'14px',lineHeight:'20px'}}>
                          {Activities.title}
                        </Typography>
                        <Typography variant="caption" color="text.secondary" sx={{fontWeight:'400',fontSize:'12px',lineHeight:'18px',color:'#FFF9FF'}}>
                          {Activities.time}
                        </Typography>
                      </Box>
                    </Box>
                  ))}
                 
       
        
      </Dialog>
    </Box>
  )
}

export default NotificationDiolog
