// // src/api/axiosInstance.js

// import axios from 'axios';

// const axiosInstance = axios.create({
//     baseURL: 'https://api.example.com',
//     timeout: 10000,
//     headers: {
//         'Content-Type': 'application/json',
//     },
// });

// // You can add interceptors here if needed
// axiosInstance.interceptors.request.use(
//     config => {
//         // Modify config before request is sent
//         return config;
//     },
//     error => {
//         return Promise.reject(error);
//     }
// );

// axiosInstance.interceptors.response.use(
//     response => response,
//     error => {
//         // Handle errors
//         return Promise.reject(error);
//     }
// );

// export default axiosInstance;
