
// const API_BASE_URL = 'https://aora-ai-backend.vercel.app/';

// export const ENDPOINTS = {
//     SENDOTP: `${API_BASE_URL}api/otp/sendOtp`,
//     USERSIGNUP:`${API_BASE_URL}api/user/auth/signup`,
//     USERLOGIN:`${API_BASE_URL}api/user/auth/login`,
//     USERPROFILE:`${API_BASE_URL}api/user/profile`,
//     FORGOTPASSWORD:`${API_BASE_URL}api/password/forgot`,
// };
