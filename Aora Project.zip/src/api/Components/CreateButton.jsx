import React from 'react'
import Button from '@mui/material/Button';
import CircularProgress from '@mui/material/CircularProgress';

import { styled } from '@mui/material/styles';

const LoadingButton = styled(Button)(({ theme }) => ({
  position: 'relative',
  '& .MuiCircularProgress-root': {
    position: 'absolute',
    left: '50%',
    top: '50%',
    marginLeft: '-12px',
    marginTop: '-12px',
  },
}));
function CreateButton({ text, disabled, handleCLick, loading }) {

  return (
    <div>
      <LoadingButton onClick={handleCLick}  variant="contained" disabled={disabled}
        sx={{marginTop:'10px',fontSize:'16px',lineHeight:'24px',letterSpacing: '0.15px',fontWeight:'600',textTransform:'none',width:'100%',py: 1,height: '48px',
            backgroundColor: loading ? '#A217A3' : '#A217A3','&:hover': { backgroundColor: loading ? '#A217A3' : '#A217A3' }}}
      >
        {loading ? <CircularProgress size={24} /> : text}
      </LoadingButton>
   </div>
  )
}

export default CreateButton
