// // src/api/apiRequests.js

// import axiosInstance from './axiosInstance';
// import { ENDPOINTS } from './endpoints';

// const getToken = () => {
//     return localStorage.getItem('authToken'); 
// };

// const getAuthHeaders = () => {
//     const token = getToken();
//     return {
//         Authorization: `Bearer ${token}`,
//     };
// };

// export const sendOtp = async (data) => {
//     try {
//         const response = await axiosInstance.post(ENDPOINTS.SENDOTP, data);
//         return response.data;
//     } catch (error) {
//         throw error;
//     }
// };

// export const userSignup = async (data) => {
//     try {
//         const response = await axiosInstance.post(ENDPOINTS.USERSIGNUP, data);
//         return response.data;
//     } catch (error) {
//         throw error;
//     }
// };
// export const userlogin = async (data) => {
//     try {
//         const response = await axiosInstance.post(ENDPOINTS.USERLOGIN, data);
//         return response.data;
//     } catch (error) {
//         throw error;
//     }
// };
// export const getUserData = async () => {
//     try {
//         const response = await axiosInstance.get(ENDPOINTS.USERPROFILE, {
//             headers: getAuthHeaders(),
//         });
//         return response.data;
//     } catch (error) {
//         throw error;
//     }
// };
// export const forgotPassword = async (data) => {
//     try {
//         const response = await axiosInstance.post(ENDPOINTS.FORGOTPASSWORD, data);
//         return response.data;
//     } catch (error) {
//         throw error;
//     }
// };