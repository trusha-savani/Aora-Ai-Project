import React from 'react';

const HomeIcon = (props) => (
    <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g filter="url(#filter0_dd_1020_4756)">
            <path d="M19.3333 15.1667H22.6667M26 18.5H16C14.6193 18.5 13.5 17.3807 13.5 16V11C13.5 10.337 13.7634 9.70107 14.2322 9.23223L19.2322 4.23223C20.2085 3.25592 21.7915 3.25592 22.7678 4.23223L27.7678 9.23223C28.2366 9.70107 28.5 10.337 28.5 11V16C28.5 17.3807 27.3807 18.5 26 18.5Z" stroke="red" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </g>
        <defs>
            <filter id="filter0_dd_1020_4756" x="-1" y="-1" width="44" height="44" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                <feMorphology radius="4" operator="erode" in="SourceAlpha" result="effect1_dropShadow_1020_4756" />
                <feOffset dy="4" />
                <feGaussianBlur stdDeviation="3" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.635294 0 0 0 0 0.0901961 0 0 0 0 0.639216 0 0 0 0.16 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_1020_4756" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                <feMorphology radius="3" operator="erode" in="SourceAlpha" result="effect2_dropShadow_1020_4756" />
                <feOffset dy="10" />
                <feGaussianBlur stdDeviation="7.5" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.635294 0 0 0 0 0.0901961 0 0 0 0 0.639216 0 0 0 0.16 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_1020_4756" result="effect2_dropShadow_1020_4756" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_1020_4756" result="shape" />
            </filter>
        </defs>
    </svg>

)
export default HomeIcon